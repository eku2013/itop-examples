package com.huins.android.sensorviewsample;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.huins.android.widget.SensorView;

public class MainActivity extends Activity {
	
	private int mValue = 7;
	private SensorView mSampleSensorView;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mSampleSensorView = (SensorView) findViewById(R.id.SampleSensorView);
        mSampleSensorView.setXUnit("sec");
        mSampleSensorView.setYUnit("khz");
        mSampleSensorView.setValue(mValue);
        
        Button upButton = (Button) findViewById(R.id.UpButton);
        upButton.setOnClickListener(new UpButtonOnClickListener());
        
        Button downButton = (Button) findViewById(R.id.DownButton);
        downButton.setOnClickListener(new DownButtonOnClickListener());    
    }
    
    private class UpButtonOnClickListener implements OnClickListener {

		public void onClick(View v) {
			// TODO Auto-generated method stub
			mValue++;
			mSampleSensorView.setValue(mValue);	
		}    	
    }
    
    private class DownButtonOnClickListener implements OnClickListener {

		public void onClick(View v) {
			// TODO Auto-generated method stub
			mValue--;
			mSampleSensorView.setValue(mValue);
		}    	
    } 
    
}