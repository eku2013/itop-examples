package com.huins.android.widget;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class SensorView extends SurfaceView {
	
	private int mDelay = 1000;
	private int mRow = 20;
	private int mColumn = 18;
	private String mXUnit = "sec";
	private String mYUnit = "khz";
	
	private Thread mUpdateThread;
	private SurfaceHolder mSurfaceHolder;

	private int mWidth;
	private int mHeight;
	private int mGraphWidth;
	private int mGraphHeight;
	private int mGraphPaddingLeft;
	private int mGraphPaddingTop;
	private int mGraphXDivision;
	private int mGraphYDivision;
	private int mValue;
	private Queue<Integer> mValues;
	private boolean mIsSurface;
	
	

	public SensorView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		initialize();
	}

	public SensorView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
		// TODO Auto-generated constructor stub
	}

	public SensorView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
		initialize();
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// TODO Auto-generated method stub
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		mWidth = MeasureSpec.getSize(widthMeasureSpec);
		mHeight = MeasureSpec.getSize(heightMeasureSpec);	
				
		mGraphWidth = mWidth - mWidth / 10;
		mGraphWidth = (mGraphWidth / mColumn) * mColumn;
		mGraphHeight = mHeight - mHeight / 8;
		mGraphHeight = (mGraphHeight / mRow) * mRow;
		
		mGraphPaddingLeft = (int) ((mWidth - mGraphWidth) * 0.8);
		mGraphPaddingTop = (int) ((mHeight - mGraphHeight) / 3);
		
		mGraphXDivision = mGraphWidth / mColumn;
		mGraphYDivision = mGraphHeight / mRow;
	}
	
	private void initialize()
	{
		mValues = new LinkedList<Integer>();
		mSurfaceHolder = getHolder();
		mSurfaceHolder.addCallback(new SensorViewHolderCallback());
	}
	
	public void setValue(int value)
	{
		mValue = mRow - value;
	}
	
	public void setXUnit(String xUnit)
	{
		mXUnit = xUnit;
	}
	
	public void setYUnit(String yUnit)
	{
		mYUnit = yUnit;
	}
	
	private Bitmap drawBackground()
	{
		Bitmap backgroundBitmap = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(backgroundBitmap);
		Paint paint = new Paint();
		
		paint.setColor(Color.BLACK);		
		
		canvas.drawRect(0, 0, mWidth, mHeight, paint);

		paint.setTextSize(mGraphPaddingTop - 2);
		
		paint.setTextAlign(Paint.Align.CENTER);
		
		for(int i = 0; i < mColumn; i++)
		{
			if(i % 5 == 0)
			{				
				paint.setColor(Color.YELLOW);
				canvas.drawText(String.valueOf(i), i * mGraphXDivision + mGraphPaddingLeft, mGraphHeight + mGraphPaddingTop + paint.getTextSize(), paint);
			}
			else
			{				
				paint.setColor(Color.GRAY);
			}
			
			canvas.drawLine(i * mGraphXDivision + mGraphPaddingLeft, 0 + mGraphPaddingTop, i * mGraphXDivision + mGraphPaddingLeft, mGraphHeight + mGraphPaddingTop, paint);
		}
		
		
		
		paint.setTextAlign(Paint.Align.RIGHT);
		
		for(int i = 0; i < mRow; i++)
		{
			int y = mRow - i;
			
			if(i % 5 == 0)
			{
				paint.setColor(Color.WHITE);
				canvas.drawText(String.valueOf(i), mGraphPaddingLeft - 1, y * mGraphYDivision + mGraphPaddingTop, paint);
			}
			else
			{
				paint.setColor(Color.GRAY);
			}
			
			canvas.drawLine(0 + mGraphPaddingLeft, y * mGraphYDivision + mGraphPaddingTop, mGraphWidth + mGraphPaddingLeft, y * mGraphYDivision + mGraphPaddingTop, paint);
		}
		
		paint.setStyle(Paint.Style.STROKE);
		paint.setColor(Color.CYAN);
		canvas.drawRect(0 + mGraphPaddingLeft, 0 + mGraphPaddingTop, mGraphWidth + mGraphPaddingLeft, mGraphHeight + mGraphPaddingTop, paint);

		// Draw X Unit
		paint.setTextAlign(Paint.Align.RIGHT);
		paint.setColor(Color.YELLOW);
		canvas.drawText(mXUnit, mWidth - 1, mGraphPaddingTop + mGraphHeight + paint.getTextSize() * 2, paint);

		// Draw Y Unit
		paint.setTextAlign(Paint.Align.RIGHT);
		paint.setColor(Color.WHITE);
		canvas.drawText(mYUnit, mGraphPaddingLeft - 1, paint.getTextSize(), paint);
		
	
		return backgroundBitmap;
	}
	
	private void dispatchDraw(Bitmap backgroundBitmap)
	{
		Canvas canvas = mSurfaceHolder.lockCanvas();
		canvas.drawBitmap(backgroundBitmap, 0, 0, null);

		Iterator<Integer> iterator = mValues.iterator();
				
		if(iterator.hasNext())
		{			
			int nextValue = iterator.next();
			int preValue = nextValue;

			Paint paint = new Paint();
			paint.setColor(Color.RED);
			//paint.setStrokeWidth(3);
			
			for(int i = 0; iterator.hasNext(); i++)
			{	
				int x = mColumn - 1 - i;
				nextValue = iterator.next();
				canvas.drawLine(x * mGraphXDivision + mGraphPaddingLeft, nextValue * mGraphYDivision + mGraphPaddingTop, (x + 1) * mGraphXDivision + mGraphPaddingLeft, preValue * mGraphYDivision + mGraphPaddingTop, paint);
				
				preValue = nextValue;
			}
		}	
		mSurfaceHolder.unlockCanvasAndPost(canvas);
	}
	
	private class SensorViewHolderCallback implements SurfaceHolder.Callback {

		public void surfaceCreated(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			
			mIsSurface = true;
			mUpdateThread = new Thread(new UpdateThreadRunnable());			
			mUpdateThread.start();
		
		}

		public void surfaceChanged(SurfaceHolder holder, int format, int width,
				int height) {
			// TODO Auto-generated method stub
			Bitmap backgroundBitmap = drawBackground();
			dispatchDraw(backgroundBitmap);
		}

		public void surfaceDestroyed(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			mIsSurface = false;
		}
		
	}
	
	private class UpdateThreadRunnable implements Runnable {

		public void run() {
			// TODO Auto-generated method stub		
			
			for(int i = 0; i < mColumn; i++)
			{
				mValues.offer(mValue);
			}
			
			Bitmap backgroundBitmap = drawBackground();
			
			while(mIsSurface)
			{
				if(mValues.size() > mColumn)
				{
					mValues.poll();
				}
				
				mValues.offer(mValue);

				dispatchDraw(backgroundBitmap);
				Log.d("luibel", "Run Value : " + mValue);

				try {
					Thread.sleep(mDelay);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		}
		
	}

}
