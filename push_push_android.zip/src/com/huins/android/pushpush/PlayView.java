package com.huins.android.pushpush;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

public class PlayView extends View {
	
	private int[][] mMap;
	private Bitmap wallBitmap;
	private Bitmap goalBitmap;
	private Bitmap boxBitmap;
	private Bitmap playerBitmap;
	private Bitmap goalInBoxBitmap;
	private Bitmap goalInPlayerBitmap;

	public PlayView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		
		wallBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.wall);
		goalBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.goal);
		boxBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.box);
		playerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.player);
		goalInBoxBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.goal_in_box);
		goalInPlayerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.goal_in_player);
		
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		
		Bitmap bitmap = null;
		
		for(int i = 0; i < mMap.length; i++)
		{
			for(int j = 0; j < mMap[i].length; j++)
			{
				switch(mMap[i][j])
				{
				case MapData.NUL :
					bitmap = null;
					break;
				case MapData.WAL :
					bitmap = wallBitmap;
					break;
				case MapData.GOA :
					bitmap = goalBitmap;
					break;
				case MapData.BOX :
					bitmap = boxBitmap;
					break;
				case MapData.PLA :
					bitmap = playerBitmap;
					break;
				case MapData.GIB :
					bitmap = goalInBoxBitmap;
					break;
				case MapData.GIP :
					bitmap = goalInPlayerBitmap;
					break;
				}
				
				if(bitmap != null)
				{
					canvas.drawBitmap(bitmap, bitmap.getWidth() * j, bitmap.getHeight() * i, null);
				}
			}
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// TODO Auto-generated method stub
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		int specWidthMode = MeasureSpec.getMode(widthMeasureSpec);
		int specHeightMode = MeasureSpec.getMode(heightMeasureSpec);				
		
		int specWidthSize = MeasureSpec.getSize(widthMeasureSpec);
		int spectHeightSize = MeasureSpec.getSize(heightMeasureSpec);
		
		int measuredWidth = specWidthSize;
		int measuredHeight = spectHeightSize;
		
		
		if(specWidthMode == MeasureSpec.AT_MOST)
		{
			measuredWidth = Math.min(specWidthSize, spectHeightSize);			
		}
		
		if(specHeightMode == MeasureSpec.AT_MOST)
		{
			measuredHeight = Math.min(specWidthSize, spectHeightSize);
		}
		
        setMeasuredDimension(measuredWidth,	measuredHeight);
	}
	
	public void setMap(int[][] map)
	{
		mMap = map;
	}
}
