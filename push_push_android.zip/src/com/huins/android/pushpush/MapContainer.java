package com.huins.android.pushpush;

public class MapContainer {
	
	private int[][][] mMapData;
	private int mStageCount;;
	
	public MapContainer()
	{
		MapData mapData = new MapData();
		mMapData = mapData.data;
		mStageCount = mMapData.length;
	}
	
	public int getStageCount()
	{
		return mStageCount;		
	}
	
	public int[][] getMap(int stageIndex)
	{
		int[][] map = new int[mMapData[0].length][mMapData[0][0].length];
		
		for(int i = 0; i < mMapData[stageIndex].length; i++)
		{
			for(int j = 0; j < mMapData[stageIndex][i].length; j++)
			{
				map[i][j] = mMapData[stageIndex][i][j];
			}
		}
		return map;
	}
}
