package com.huins.android.pushpush;

public interface OnPlayControl {
	
	public void clearPlay();

}
