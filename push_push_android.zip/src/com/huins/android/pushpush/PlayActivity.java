package com.huins.android.pushpush;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class PlayActivity extends Activity implements OnPlayControl, DialogInterface.OnClickListener, OnClickListener {
	
	private static final int MENU_RESTART = 1;
	private static final int MENU_QUIT = MENU_RESTART + 1;
	
	private MapContainer mMapContainer;
	private PlayView mPlayView;
	private PlayControl mPlayControl;
	private int[][] mMap;
	private int mStageIndex;
	private int mMovesCount;
	
	private TextView mLevelValueTextView;
	private TextView mMovesValueTextView;
	private AlertDialog.Builder mAlertDialog;
	private Button mUpButton;
	private Button mDownButton;
	private Button mLeftButton;
	private Button mRightButton;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play);
        
        mMapContainer = new MapContainer();
        mPlayView = (PlayView) findViewById(R.id.PlayView);
        mPlayControl = new PlayControl();
        mPlayControl.setOnPlayControl(this);
        
        mLevelValueTextView = (TextView) findViewById(R.id.LevelValue);
        mMovesValueTextView = (TextView) findViewById(R.id.MovesValue);
        
        mAlertDialog = new AlertDialog.Builder(this);
        mAlertDialog.setPositiveButton(R.string.OK, this);     
        mAlertDialog.setMessage(R.string.Stage_Clear);
        
        mUpButton = (Button) findViewById(R.id.UpButton);
        mUpButton.setOnClickListener(this);
        mDownButton = (Button) findViewById(R.id.DownButton);
        mDownButton.setOnClickListener(this);
        mLeftButton = (Button) findViewById(R.id.LeftButton);
        mLeftButton.setOnClickListener(this);
        mRightButton = (Button) findViewById(R.id.RightButton);
        mRightButton.setOnClickListener(this);
        
        startGame();
    }

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		
		boolean isMoved = false;
		
		switch(keyCode)
		{
		case KeyEvent.KEYCODE_DPAD_UP :
			isMoved = mPlayControl.moveUp();
			break;
		case KeyEvent.KEYCODE_DPAD_DOWN :
			isMoved = mPlayControl.moveDown();
			break;
		case KeyEvent.KEYCODE_DPAD_LEFT :
			isMoved = mPlayControl.moveLeft();
			break;
		case KeyEvent.KEYCODE_DPAD_RIGHT :
			isMoved = mPlayControl.moveRight();
			break;	
		}	
		
		if(isMoved == true)
		{
			mPlayView.invalidate();
			mMovesCount++;
			mMovesValueTextView.setText(String.valueOf(mMovesCount));
		}
		
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		
        menu.add(0, MENU_RESTART, 0, R.string.Restart);
        menu.add(0, MENU_QUIT, 0, R.string.Quit);
		
        return super.onCreateOptionsMenu(menu);
	}
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) 
        {
            case MENU_RESTART :
            	startGame();
                return true;
            case MENU_QUIT :
            	finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
    
	@Override
	public void clearPlay() {
		// TODO Auto-generated method stub		
		mAlertDialog.show();
	}
	
	private void startGame()
	{		
		mLevelValueTextView.setText(String.valueOf(mStageIndex + 1));
		mMovesCount = 0;
		mMovesValueTextView.setText(String.valueOf(mMovesCount));
		
		if(mStageIndex < mMapContainer.getStageCount())
		{
			mMap = mMapContainer.getMap(mStageIndex);
			mPlayView.setMap(mMap);
			mPlayControl.setMap(mMap);
			mPlayView.invalidate();
		}		
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		mStageIndex++;
		startGame();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		boolean isMoved = false;
		
		if(v == mUpButton)
		{
			isMoved = mPlayControl.moveUp();
		}
		else if(v == mDownButton)
		{
			isMoved = mPlayControl.moveDown();
		}
		else if(v == mLeftButton)
		{
			isMoved = mPlayControl.moveLeft();
		}
		else if(v == mRightButton)
		{
			isMoved = mPlayControl.moveRight();
		}

		if(isMoved == true)
		{
			mPlayView.invalidate();
			mMovesCount++;
			mMovesValueTextView.setText(String.valueOf(mMovesCount));
		}
	}

}
