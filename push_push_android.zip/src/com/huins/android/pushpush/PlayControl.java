package com.huins.android.pushpush;

public class PlayControl {
	
	private final int UP = 1;
	private final int DOWN = 2;
	private final int LEFT = 3;
	private final int RIGHT = 4;
	private Position mPosition;
	private int mGoalCount;
	
	private OnPlayControl mOnPlayControl;
	private int[][] mMap;
	
	public PlayControl()
	{		
		
	}
	
	public void setMap(int[][] map)
	{		
		mPosition = new Position();
		mGoalCount = 0;
		
		for(int i = 0; i < map.length; i++)
		{
			for(int j = 0; j < map[i].length; j++)
			{
				switch(map[i][j])
				{
				case MapData.PLA :
					mPosition.setPosition(i, j);
					break;
				case MapData.GOA :					
					mGoalCount++;
					break;
				}
			}
		}
		mMap = map;
	}
	
	public void setOnPlayControl(OnPlayControl onPlayControl)
	{
		mOnPlayControl = onPlayControl;
	}
	
	public boolean moveUp()
	{
		return moveDirection(UP);
	}
	
	public boolean moveDown()
	{
		return moveDirection(DOWN);
	}
	
	public boolean moveLeft()
	{
		return moveDirection(LEFT);
	}
	
	public boolean moveRight()
	{
		return moveDirection(RIGHT);
	}
	
	private boolean moveDirection(int direction)
	{
		if(push(direction, mPosition, 1) == true)
		{
			if(mGoalCount == 0)
			{
				mOnPlayControl.clearPlay();	
			}
			return true;
		}	
		return false;
	}
	
	private boolean push(int direction, Position position, int nPushBoxes)
	{
		Position nextPosition = new Position(position);
		int nextBackground = MapData.NUL;
		
		switch(direction)
		{
		case UP :
			nextPosition.mRow--;
			break;
		case DOWN :
			nextPosition.mRow++;
			break;
		case LEFT :
			nextPosition.mColumn--;
			break;
		case RIGHT :
			nextPosition.mColumn++;
			break;			
		}
		
		switch(mMap[nextPosition.mRow][nextPosition.mColumn])
		{
		case MapData.WAL :
			return false;
		case MapData.GOA :
			nextBackground = MapData.GOA;
			break;
		case MapData.GIB :
			nextBackground = MapData.GOA;
		case MapData.BOX :	
			if(nPushBoxes  == 0)
			{
				return false;
			}
			nPushBoxes--;
			
			if(push(direction, new Position(nextPosition), nPushBoxes) == false)
			{
				return false;
			}
		case MapData.NUL :
		default :
			break;
		}
		
		if(mMap[position.mRow][position.mColumn] == MapData.BOX && mMap[nextPosition.mRow][nextPosition.mColumn] == MapData.GOA)
		{
			mGoalCount--;
		}
		else if(mMap[position.mRow][position.mColumn] == MapData.GIB && mMap[nextPosition.mRow][nextPosition.mColumn] == MapData.NUL)
		{
			mGoalCount++;
		}
		
		int background = mMap[position.mRow][position.mColumn] & MapData.GOA;
		int foreground = mMap[position.mRow][position.mColumn] - background;
		
		mMap[nextPosition.mRow][nextPosition.mColumn] = foreground + nextBackground;
		mMap[position.mRow][position.mColumn] = background;
		position.setPosition(nextPosition);
		
		return true;
	}
	
	private class Position
	{
		public int mRow;
		public int mColumn;
		
		public Position()
		{
			mRow = 0;
			mColumn = 0;
		}

		public Position(int row, int column)
		{
			mRow = row;
			mColumn = column;
		}
		
		public Position(Position position)
		{
			mRow = position.mRow;
			mColumn = position.mColumn;			
		}
		
		public void setPosition(int row, int column)
		{
			mRow = row;
			mColumn = column;		
		}
		
		public void setPosition(Position position)
		{
			mRow = position.mRow;
			mColumn = position.mColumn;			
		}		
	}
}
