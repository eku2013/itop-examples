/****************************************************************************
** Meta object code from reading C++ file 'controlpanel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../doubanfm-qt/controlpanel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlpanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ControlPanel_t {
    QByteArrayData data[19];
    char stringdata0[281];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ControlPanel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ControlPanel_t qt_meta_stringdata_ControlPanel = {
    {
QT_MOC_LITERAL(0, 0, 12), // "ControlPanel"
QT_MOC_LITERAL(1, 13, 16), // "openChannelPanel"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 17), // "closeChannelPanel"
QT_MOC_LITERAL(4, 49, 14), // "openLyricPanel"
QT_MOC_LITERAL(5, 64, 15), // "closeLyricPanel"
QT_MOC_LITERAL(6, 80, 5), // "pause"
QT_MOC_LITERAL(7, 86, 4), // "play"
QT_MOC_LITERAL(8, 91, 21), // "on_nextButton_clicked"
QT_MOC_LITERAL(9, 113, 22), // "on_pauseButton_clicked"
QT_MOC_LITERAL(10, 136, 21), // "on_likeButton_clicked"
QT_MOC_LITERAL(11, 158, 22), // "on_trashButton_clicked"
QT_MOC_LITERAL(12, 181, 11), // "setSongName"
QT_MOC_LITERAL(13, 193, 4), // "name"
QT_MOC_LITERAL(14, 198, 13), // "setArtistName"
QT_MOC_LITERAL(15, 212, 12), // "setAlbumName"
QT_MOC_LITERAL(16, 225, 24), // "on_settingButton_clicked"
QT_MOC_LITERAL(17, 250, 22), // "on_lyricButton_clicked"
QT_MOC_LITERAL(18, 273, 7) // "checked"

    },
    "ControlPanel\0openChannelPanel\0\0"
    "closeChannelPanel\0openLyricPanel\0"
    "closeLyricPanel\0pause\0play\0"
    "on_nextButton_clicked\0on_pauseButton_clicked\0"
    "on_likeButton_clicked\0on_trashButton_clicked\0"
    "setSongName\0name\0setArtistName\0"
    "setAlbumName\0on_settingButton_clicked\0"
    "on_lyricButton_clicked\0checked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ControlPanel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x06 /* Public */,
       3,    0,   90,    2, 0x06 /* Public */,
       4,    0,   91,    2, 0x06 /* Public */,
       5,    0,   92,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,   93,    2, 0x0a /* Public */,
       7,    0,   94,    2, 0x0a /* Public */,
       8,    0,   95,    2, 0x0a /* Public */,
       9,    0,   96,    2, 0x0a /* Public */,
      10,    0,   97,    2, 0x0a /* Public */,
      11,    0,   98,    2, 0x0a /* Public */,
      12,    1,   99,    2, 0x08 /* Private */,
      14,    1,  102,    2, 0x08 /* Private */,
      15,    1,  105,    2, 0x08 /* Private */,
      16,    0,  108,    2, 0x08 /* Private */,
      17,    1,  109,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   18,

       0        // eod
};

void ControlPanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ControlPanel *_t = static_cast<ControlPanel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->openChannelPanel(); break;
        case 1: _t->closeChannelPanel(); break;
        case 2: _t->openLyricPanel(); break;
        case 3: _t->closeLyricPanel(); break;
        case 4: _t->pause(); break;
        case 5: _t->play(); break;
        case 6: _t->on_nextButton_clicked(); break;
        case 7: _t->on_pauseButton_clicked(); break;
        case 8: _t->on_likeButton_clicked(); break;
        case 9: _t->on_trashButton_clicked(); break;
        case 10: _t->setSongName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->setArtistName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->setAlbumName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->on_settingButton_clicked(); break;
        case 14: _t->on_lyricButton_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::openChannelPanel)) {
                *result = 0;
            }
        }
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::closeChannelPanel)) {
                *result = 1;
            }
        }
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::openLyricPanel)) {
                *result = 2;
            }
        }
        {
            typedef void (ControlPanel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ControlPanel::closeLyricPanel)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject ControlPanel::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ControlPanel.data,
      qt_meta_data_ControlPanel,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ControlPanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ControlPanel::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ControlPanel.stringdata0))
        return static_cast<void*>(const_cast< ControlPanel*>(this));
    return QWidget::qt_metacast(_clname);
}

int ControlPanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void ControlPanel::openChannelPanel()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void ControlPanel::closeChannelPanel()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void ControlPanel::openLyricPanel()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void ControlPanel::closeLyricPanel()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
