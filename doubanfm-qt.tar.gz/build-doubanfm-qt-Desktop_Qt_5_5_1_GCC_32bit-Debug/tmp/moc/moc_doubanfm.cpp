/****************************************************************************
** Meta object code from reading C++ file 'doubanfm.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../doubanfm-qt/libs/doubanfm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'doubanfm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_DoubanFM_t {
    QByteArrayData data[31];
    char stringdata0[448];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DoubanFM_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DoubanFM_t qt_meta_stringdata_DoubanFM = {
    {
QT_MOC_LITERAL(0, 0, 8), // "DoubanFM"
QT_MOC_LITERAL(1, 9, 15), // "receivedNewList"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 19), // "QList<DoubanFMSong>"
QT_MOC_LITERAL(4, 46, 5), // "songs"
QT_MOC_LITERAL(5, 52, 19), // "receivedPlayingList"
QT_MOC_LITERAL(6, 72, 16), // "receivedRateSong"
QT_MOC_LITERAL(7, 89, 7), // "succeed"
QT_MOC_LITERAL(8, 97, 16), // "receivedSkipSong"
QT_MOC_LITERAL(9, 114, 18), // "receivedCurrentEnd"
QT_MOC_LITERAL(10, 133, 15), // "receivedByeSong"
QT_MOC_LITERAL(11, 149, 16), // "receivedChannels"
QT_MOC_LITERAL(12, 166, 20), // "QList<DoubanChannel>"
QT_MOC_LITERAL(13, 187, 8), // "channels"
QT_MOC_LITERAL(14, 196, 12), // "loginSucceed"
QT_MOC_LITERAL(15, 209, 10), // "DoubanUser"
QT_MOC_LITERAL(16, 220, 4), // "user"
QT_MOC_LITERAL(17, 225, 11), // "loginFailed"
QT_MOC_LITERAL(18, 237, 6), // "errmsg"
QT_MOC_LITERAL(19, 244, 13), // "logoffSucceed"
QT_MOC_LITERAL(20, 258, 14), // "onReceivedAuth"
QT_MOC_LITERAL(21, 273, 14), // "QNetworkReply*"
QT_MOC_LITERAL(22, 288, 5), // "reply"
QT_MOC_LITERAL(23, 294, 17), // "onReceivedRelogin"
QT_MOC_LITERAL(24, 312, 17), // "onReceivedNewList"
QT_MOC_LITERAL(25, 330, 21), // "onReceivedPlayingList"
QT_MOC_LITERAL(26, 352, 18), // "onReceivedRateSong"
QT_MOC_LITERAL(27, 371, 18), // "onReceivedSkipSong"
QT_MOC_LITERAL(28, 390, 20), // "onReceivedCurrentEnd"
QT_MOC_LITERAL(29, 411, 17), // "onReceivedByeSong"
QT_MOC_LITERAL(30, 429, 18) // "onReceivedChannels"

    },
    "DoubanFM\0receivedNewList\0\0QList<DoubanFMSong>\0"
    "songs\0receivedPlayingList\0receivedRateSong\0"
    "succeed\0receivedSkipSong\0receivedCurrentEnd\0"
    "receivedByeSong\0receivedChannels\0"
    "QList<DoubanChannel>\0channels\0"
    "loginSucceed\0DoubanUser\0user\0loginFailed\0"
    "errmsg\0logoffSucceed\0onReceivedAuth\0"
    "QNetworkReply*\0reply\0onReceivedRelogin\0"
    "onReceivedNewList\0onReceivedPlayingList\0"
    "onReceivedRateSong\0onReceivedSkipSong\0"
    "onReceivedCurrentEnd\0onReceivedByeSong\0"
    "onReceivedChannels"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DoubanFM[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  109,    2, 0x06 /* Public */,
       5,    1,  112,    2, 0x06 /* Public */,
       6,    1,  115,    2, 0x06 /* Public */,
       8,    1,  118,    2, 0x06 /* Public */,
       9,    1,  121,    2, 0x06 /* Public */,
      10,    1,  124,    2, 0x06 /* Public */,
      11,    1,  127,    2, 0x06 /* Public */,
      14,    1,  130,    2, 0x06 /* Public */,
      17,    1,  133,    2, 0x06 /* Public */,
      19,    0,  136,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      20,    1,  137,    2, 0x08 /* Private */,
      23,    1,  140,    2, 0x08 /* Private */,
      24,    1,  143,    2, 0x08 /* Private */,
      25,    1,  146,    2, 0x08 /* Private */,
      26,    1,  149,    2, 0x08 /* Private */,
      27,    1,  152,    2, 0x08 /* Private */,
      28,    1,  155,    2, 0x08 /* Private */,
      29,    1,  158,    2, 0x08 /* Private */,
      30,    1,  161,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 21,   22,

       0        // eod
};

void DoubanFM::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DoubanFM *_t = static_cast<DoubanFM *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->receivedNewList((*reinterpret_cast< const QList<DoubanFMSong>(*)>(_a[1]))); break;
        case 1: _t->receivedPlayingList((*reinterpret_cast< const QList<DoubanFMSong>(*)>(_a[1]))); break;
        case 2: _t->receivedRateSong((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->receivedSkipSong((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->receivedCurrentEnd((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->receivedByeSong((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->receivedChannels((*reinterpret_cast< const QList<DoubanChannel>(*)>(_a[1]))); break;
        case 7: _t->loginSucceed((*reinterpret_cast< const DoubanUser(*)>(_a[1]))); break;
        case 8: _t->loginFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->logoffSucceed(); break;
        case 10: _t->onReceivedAuth((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 11: _t->onReceivedRelogin((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 12: _t->onReceivedNewList((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 13: _t->onReceivedPlayingList((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 14: _t->onReceivedRateSong((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 15: _t->onReceivedSkipSong((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 16: _t->onReceivedCurrentEnd((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 17: _t->onReceivedByeSong((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 18: _t->onReceivedChannels((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (DoubanFM::*_t)(const QList<DoubanFMSong> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedNewList)) {
                *result = 0;
            }
        }
        {
            typedef void (DoubanFM::*_t)(const QList<DoubanFMSong> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedPlayingList)) {
                *result = 1;
            }
        }
        {
            typedef void (DoubanFM::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedRateSong)) {
                *result = 2;
            }
        }
        {
            typedef void (DoubanFM::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedSkipSong)) {
                *result = 3;
            }
        }
        {
            typedef void (DoubanFM::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedCurrentEnd)) {
                *result = 4;
            }
        }
        {
            typedef void (DoubanFM::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedByeSong)) {
                *result = 5;
            }
        }
        {
            typedef void (DoubanFM::*_t)(const QList<DoubanChannel> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::receivedChannels)) {
                *result = 6;
            }
        }
        {
            typedef void (DoubanFM::*_t)(const DoubanUser & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::loginSucceed)) {
                *result = 7;
            }
        }
        {
            typedef void (DoubanFM::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::loginFailed)) {
                *result = 8;
            }
        }
        {
            typedef void (DoubanFM::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DoubanFM::logoffSucceed)) {
                *result = 9;
            }
        }
    }
}

const QMetaObject DoubanFM::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_DoubanFM.data,
      qt_meta_data_DoubanFM,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *DoubanFM::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DoubanFM::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_DoubanFM.stringdata0))
        return static_cast<void*>(const_cast< DoubanFM*>(this));
    return QObject::qt_metacast(_clname);
}

int DoubanFM::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void DoubanFM::receivedNewList(const QList<DoubanFMSong> & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DoubanFM::receivedPlayingList(const QList<DoubanFMSong> & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void DoubanFM::receivedRateSong(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DoubanFM::receivedSkipSong(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void DoubanFM::receivedCurrentEnd(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void DoubanFM::receivedByeSong(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void DoubanFM::receivedChannels(const QList<DoubanChannel> & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void DoubanFM::loginSucceed(const DoubanUser & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void DoubanFM::loginFailed(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void DoubanFM::logoffSucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 9, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
