/****************************************************************************
** Meta object code from reading C++ file 'mprisplayeradapter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../doubanfm-qt/plugins/mpris/mprisplayeradapter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mprisplayeradapter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MprisPlayerAdapter_t {
    QByteArrayData data[19];
    char stringdata0[1037];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MprisPlayerAdapter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MprisPlayerAdapter_t qt_meta_stringdata_MprisPlayerAdapter = {
    {
QT_MOC_LITERAL(0, 0, 18), // "MprisPlayerAdapter"
QT_MOC_LITERAL(1, 19, 15), // "D-Bus Interface"
QT_MOC_LITERAL(2, 35, 29), // "org.mpris.MediaPlayer2.Player"
QT_MOC_LITERAL(3, 65, 19), // "D-Bus Introspection"
QT_MOC_LITERAL(4, 85, 834), // "  <interface name=\"org.mpris..."
QT_MOC_LITERAL(5, 839, 4), // "Next"
QT_MOC_LITERAL(6, 844, 0), // ""
QT_MOC_LITERAL(7, 845, 5), // "Pause"
QT_MOC_LITERAL(8, 851, 4), // "Play"
QT_MOC_LITERAL(9, 856, 9), // "PlayPause"
QT_MOC_LITERAL(10, 866, 4), // "Stop"
QT_MOC_LITERAL(11, 871, 10), // "CanControl"
QT_MOC_LITERAL(12, 882, 9), // "CanGoNext"
QT_MOC_LITERAL(13, 892, 13), // "CanGoPrevious"
QT_MOC_LITERAL(14, 906, 8), // "CanPause"
QT_MOC_LITERAL(15, 915, 7), // "CanSeek"
QT_MOC_LITERAL(16, 923, 8), // "Metadata"
QT_MOC_LITERAL(17, 932, 14), // "PlaybackStatus"
QT_MOC_LITERAL(18, 947, 8) // "Position"

    },
    "MprisPlayerAdapter\0D-Bus Interface\0"
    "org.mpris.MediaPlayer2.Player\0"
    "D-Bus Introspection\0"
    "  <interface name=\"org.mpris.MediaPlayer2.Player\">\n    <property ac"
    "cess=\"read\" type=\"b\" name=\"CanControl\"/>\n    <property access=\""
    "read\" type=\"b\" name=\"CanGoNext\"/>\n    <property access=\"read\" "
    "type=\"b\" name=\"CanGoPrevious\"/>\n    <property access=\"read\" typ"
    "e=\"b\" name=\"CanPause\"/>\n    <property access=\"read\" type=\"b\" "
    "name=\"CanSeek\"/>\n    <property access=\"read\" type=\"x\" name=\"Po"
    "sition\"/>\n    <property access=\"read\" type=\"a{sv}\" name=\"Metada"
    "ta\">\n      <annotation value=\"QVariantMap\" name=\"org.qtproject.Qt"
    "DBus.QtTypeName\"/>\n    </property>\n    <property access=\"read\" ty"
    "pe=\"s\" name=\"PlaybackStatus\"/>\n    <method name=\"Next\"/>\n    <"
    "method name=\"Pause\"/>\n    <method name=\"PlayPause\"/>\n    <method"
    " name=\"Play\"/>\n    <method name=\"Stop\"/>\n  </interface>\n\0"
    "Next\0\0Pause\0Play\0PlayPause\0Stop\0"
    "CanControl\0CanGoNext\0CanGoPrevious\0"
    "CanPause\0CanSeek\0Metadata\0PlaybackStatus\0"
    "Position"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MprisPlayerAdapter[] = {

 // content:
       7,       // revision
       0,       // classname
       2,   14, // classinfo
       5,   18, // methods
       8,   48, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,

 // slots: name, argc, parameters, tag, flags
       5,    0,   43,    6, 0x0a /* Public */,
       7,    0,   44,    6, 0x0a /* Public */,
       8,    0,   45,    6, 0x0a /* Public */,
       9,    0,   46,    6, 0x0a /* Public */,
      10,    0,   47,    6, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      11, QMetaType::Bool, 0x00095001,
      12, QMetaType::Bool, 0x00095001,
      13, QMetaType::Bool, 0x00095001,
      14, QMetaType::Bool, 0x00095001,
      15, QMetaType::Bool, 0x00095001,
      16, QMetaType::QVariantMap, 0x00095001,
      17, QMetaType::QString, 0x00095001,
      18, QMetaType::LongLong, 0x00095001,

       0        // eod
};

void MprisPlayerAdapter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MprisPlayerAdapter *_t = static_cast<MprisPlayerAdapter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Next(); break;
        case 1: _t->Pause(); break;
        case 2: _t->Play(); break;
        case 3: _t->PlayPause(); break;
        case 4: _t->Stop(); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        MprisPlayerAdapter *_t = static_cast<MprisPlayerAdapter *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->canControl(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->canGoNext(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->canGoPrevious(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->canPause(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->canSeek(); break;
        case 5: *reinterpret_cast< QVariantMap*>(_v) = _t->metadata(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->playbackStatus(); break;
        case 7: *reinterpret_cast< qlonglong*>(_v) = _t->position(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

const QMetaObject MprisPlayerAdapter::staticMetaObject = {
    { &QDBusAbstractAdaptor::staticMetaObject, qt_meta_stringdata_MprisPlayerAdapter.data,
      qt_meta_data_MprisPlayerAdapter,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MprisPlayerAdapter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MprisPlayerAdapter::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MprisPlayerAdapter.stringdata0))
        return static_cast<void*>(const_cast< MprisPlayerAdapter*>(this));
    return QDBusAbstractAdaptor::qt_metacast(_clname);
}

int MprisPlayerAdapter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDBusAbstractAdaptor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
