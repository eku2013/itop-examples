/****************************************************************************
** Meta object code from reading C++ file 'doubanmprisplugin.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../doubanfm-qt/plugins/mpris/doubanmprisplugin.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'doubanmprisplugin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_DoubanMprisPlugin_t {
    QByteArrayData data[21];
    char stringdata0[185];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DoubanMprisPlugin_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DoubanMprisPlugin_t qt_meta_stringdata_DoubanMprisPlugin = {
    {
QT_MOC_LITERAL(0, 0, 17), // "DoubanMprisPlugin"
QT_MOC_LITERAL(1, 18, 4), // "Next"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 5), // "Pause"
QT_MOC_LITERAL(4, 30, 4), // "Play"
QT_MOC_LITERAL(5, 35, 9), // "PlayPause"
QT_MOC_LITERAL(6, 45, 4), // "Stop"
QT_MOC_LITERAL(7, 50, 4), // "Quit"
QT_MOC_LITERAL(8, 55, 5), // "Raise"
QT_MOC_LITERAL(9, 61, 10), // "CanControl"
QT_MOC_LITERAL(10, 72, 9), // "CanGoNext"
QT_MOC_LITERAL(11, 82, 13), // "CanGoPrevious"
QT_MOC_LITERAL(12, 96, 8), // "CanPause"
QT_MOC_LITERAL(13, 105, 7), // "CanSeek"
QT_MOC_LITERAL(14, 113, 8), // "Position"
QT_MOC_LITERAL(15, 122, 8), // "Metadata"
QT_MOC_LITERAL(16, 131, 14), // "PlaybackStatus"
QT_MOC_LITERAL(17, 146, 7), // "CanQuit"
QT_MOC_LITERAL(18, 154, 8), // "CanRaise"
QT_MOC_LITERAL(19, 163, 12), // "DesktopEntry"
QT_MOC_LITERAL(20, 176, 8) // "Identity"

    },
    "DoubanMprisPlugin\0Next\0\0Pause\0Play\0"
    "PlayPause\0Stop\0Quit\0Raise\0CanControl\0"
    "CanGoNext\0CanGoPrevious\0CanPause\0"
    "CanSeek\0Position\0Metadata\0PlaybackStatus\0"
    "CanQuit\0CanRaise\0DesktopEntry\0Identity"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DoubanMprisPlugin[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
      12,   56, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x0a /* Public */,
       3,    0,   50,    2, 0x0a /* Public */,
       4,    0,   51,    2, 0x0a /* Public */,
       5,    0,   52,    2, 0x0a /* Public */,
       6,    0,   53,    2, 0x0a /* Public */,
       7,    0,   54,    2, 0x0a /* Public */,
       8,    0,   55,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
       9, QMetaType::Bool, 0x00095001,
      10, QMetaType::Bool, 0x00095001,
      11, QMetaType::Bool, 0x00095001,
      12, QMetaType::Bool, 0x00095001,
      13, QMetaType::Bool, 0x00095001,
      14, QMetaType::LongLong, 0x00095001,
      15, QMetaType::QVariantMap, 0x00095001,
      16, QMetaType::QString, 0x00095001,
      17, QMetaType::Bool, 0x00095001,
      18, QMetaType::Bool, 0x00095001,
      19, QMetaType::QString, 0x00095001,
      20, QMetaType::QString, 0x00095001,

       0        // eod
};

void DoubanMprisPlugin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DoubanMprisPlugin *_t = static_cast<DoubanMprisPlugin *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Next(); break;
        case 1: _t->Pause(); break;
        case 2: _t->Play(); break;
        case 3: _t->PlayPause(); break;
        case 4: _t->Stop(); break;
        case 5: _t->Quit(); break;
        case 6: _t->Raise(); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        DoubanMprisPlugin *_t = static_cast<DoubanMprisPlugin *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->CanControl(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->CanGoNext(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->CanGoPrevious(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->CanPause(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->CanSeek(); break;
        case 5: *reinterpret_cast< qlonglong*>(_v) = _t->Position(); break;
        case 6: *reinterpret_cast< QVariantMap*>(_v) = _t->Metadata(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->PlaybackStatus(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->CanQuit(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->CanRaise(); break;
        case 10: *reinterpret_cast< QString*>(_v) = _t->DesktopEntry(); break;
        case 11: *reinterpret_cast< QString*>(_v) = _t->Identity(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

const QMetaObject DoubanMprisPlugin::staticMetaObject = {
    { &DoubanFMPlugin::staticMetaObject, qt_meta_stringdata_DoubanMprisPlugin.data,
      qt_meta_data_DoubanMprisPlugin,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *DoubanMprisPlugin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DoubanMprisPlugin::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_DoubanMprisPlugin.stringdata0))
        return static_cast<void*>(const_cast< DoubanMprisPlugin*>(this));
    return DoubanFMPlugin::qt_metacast(_clname);
}

int DoubanMprisPlugin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = DoubanFMPlugin::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 12;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
