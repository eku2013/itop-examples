/****************************************************************************
** Meta object code from reading C++ file 'mprisadapter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../doubanfm-qt/plugins/mpris/mprisadapter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mprisadapter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MprisAdapter_t {
    QByteArrayData data[12];
    char stringdata0[497];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MprisAdapter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MprisAdapter_t qt_meta_stringdata_MprisAdapter = {
    {
QT_MOC_LITERAL(0, 0, 12), // "MprisAdapter"
QT_MOC_LITERAL(1, 13, 15), // "D-Bus Interface"
QT_MOC_LITERAL(2, 29, 22), // "org.mpris.MediaPlayer2"
QT_MOC_LITERAL(3, 52, 19), // "D-Bus Introspection"
QT_MOC_LITERAL(4, 72, 373), // "  <interface name=\"org.mpris..."
QT_MOC_LITERAL(5, 408, 4), // "Quit"
QT_MOC_LITERAL(6, 413, 0), // ""
QT_MOC_LITERAL(7, 414, 5), // "Raise"
QT_MOC_LITERAL(8, 420, 7), // "CanQuit"
QT_MOC_LITERAL(9, 428, 8), // "CanRaise"
QT_MOC_LITERAL(10, 437, 12), // "DesktopEntry"
QT_MOC_LITERAL(11, 450, 8) // "Identity"

    },
    "MprisAdapter\0D-Bus Interface\0"
    "org.mpris.MediaPlayer2\0D-Bus Introspection\0"
    "  <interface name=\"org.mpris.MediaPlayer2\">\n    <method name=\"Quit"
    "\"/>\n    <method name=\"Raise\"/>\n    <property access=\"read\" type"
    "=\"b\" name=\"CanQuit\"/>\n    <property access=\"read\" type=\"b\" na"
    "me=\"CanRaise\"/>\n    <property access=\"read\" type=\"s\" name=\"Ide"
    "ntity\"/>\n    <property access=\"read\" type=\"s\" name=\"DesktopEntr"
    "y\"/>\n  </interface>\n\0"
    "Quit\0\0Raise\0CanQuit\0CanRaise\0DesktopEntry\0"
    "Identity"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MprisAdapter[] = {

 // content:
       7,       // revision
       0,       // classname
       2,   14, // classinfo
       2,   18, // methods
       4,   30, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,

 // slots: name, argc, parameters, tag, flags
       5,    0,   28,    6, 0x0a /* Public */,
       7,    0,   29,    6, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
       8, QMetaType::Bool, 0x00095001,
       9, QMetaType::Bool, 0x00095001,
      10, QMetaType::QString, 0x00095001,
      11, QMetaType::QString, 0x00095001,

       0        // eod
};

void MprisAdapter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MprisAdapter *_t = static_cast<MprisAdapter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Quit(); break;
        case 1: _t->Raise(); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        MprisAdapter *_t = static_cast<MprisAdapter *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->canQuit(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->canRaise(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->desktopEntry(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->identity(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

const QMetaObject MprisAdapter::staticMetaObject = {
    { &QDBusAbstractAdaptor::staticMetaObject, qt_meta_stringdata_MprisAdapter.data,
      qt_meta_data_MprisAdapter,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MprisAdapter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MprisAdapter::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MprisAdapter.stringdata0))
        return static_cast<void*>(const_cast< MprisAdapter*>(this));
    return QDBusAbstractAdaptor::qt_metacast(_clname);
}

int MprisAdapter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDBusAbstractAdaptor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
