/********************************************************************************
** Form generated from reading UI file 'albumwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALBUMWIDGET_H
#define UI_ALBUMWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "albumimage.h"

QT_BEGIN_NAMESPACE

class Ui_AlbumWidget
{
public:
    AlbumImage *albimImage;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *AlbumWidget)
    {
        if (AlbumWidget->objectName().isEmpty())
            AlbumWidget->setObjectName(QStringLiteral("AlbumWidget"));
        AlbumWidget->resize(200, 200);
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        AlbumWidget->setFont(font);
        albimImage = new AlbumImage(AlbumWidget);
        albimImage->setObjectName(QStringLiteral("albimImage"));
        albimImage->setGeometry(QRect(0, 0, 200, 200));
        widget = new QWidget(AlbumWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 5, 201, 191));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);
        label->setStyleSheet(QLatin1String("background: rgba(0,0,0,80);\n"
"border-radius: 2px;"));
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(AlbumWidget);

        QMetaObject::connectSlotsByName(AlbumWidget);
    } // setupUi

    void retranslateUi(QWidget *AlbumWidget)
    {
        AlbumWidget->setWindowTitle(QApplication::translate("AlbumWidget", "Form", 0));
        albimImage->setText(QString());
        label->setText(QApplication::translate("AlbumWidget", "<font color=\"white\">&nbsp;&nbsp;\346\237\245\347\234\213\344\270\223\350\276\221\344\277\241\346\201\257&nbsp;&nbsp;</font>", 0));
    } // retranslateUi

};

namespace Ui {
    class AlbumWidget: public Ui_AlbumWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALBUMWIDGET_H
