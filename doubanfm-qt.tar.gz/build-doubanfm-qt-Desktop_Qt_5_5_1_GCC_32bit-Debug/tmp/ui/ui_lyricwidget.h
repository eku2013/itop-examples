/********************************************************************************
** Form generated from reading UI file 'lyricwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LYRICWIDGET_H
#define UI_LYRICWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LyricWidget
{
public:
    QLabel *bg;
    QLabel *border;

    void setupUi(QWidget *LyricWidget)
    {
        if (LyricWidget->objectName().isEmpty())
            LyricWidget->setObjectName(QStringLiteral("LyricWidget"));
        LyricWidget->resize(544, 151);
        bg = new QLabel(LyricWidget);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(0, 0, 544, 151));
        bg->setMinimumSize(QSize(544, 151));
        bg->setMaximumSize(QSize(544, 151));
        bg->setPixmap(QPixmap(QString::fromUtf8(":/img/apple-ios-linen-texture.jpg")));
        bg->setScaledContents(false);
        border = new QLabel(LyricWidget);
        border->setObjectName(QStringLiteral("border"));
        border->setGeometry(QRect(0, 0, 544, 151));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        font.setPointSize(10);
        border->setFont(font);
        border->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 10px;\n"
"border-top-color: rgba(0,0,0,0);\n"
"border-bottom-color: qlineargradient(x1: 0, y1: 1, x2: 0, y2: 0, stop: 0 rgba(0,0,0,80), stop: 1 rgba(0,0,0,0));\n"
"border-left-color: rgba(0,0,0,0);\n"
"border-right-color: rgba(0,0,0,0);"));
        border->setAlignment(Qt::AlignCenter);

        retranslateUi(LyricWidget);

        QMetaObject::connectSlotsByName(LyricWidget);
    } // setupUi

    void retranslateUi(QWidget *LyricWidget)
    {
        LyricWidget->setWindowTitle(QApplication::translate("LyricWidget", "Form", 0));
        bg->setText(QString());
        border->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class LyricWidget: public Ui_LyricWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LYRICWIDGET_H
