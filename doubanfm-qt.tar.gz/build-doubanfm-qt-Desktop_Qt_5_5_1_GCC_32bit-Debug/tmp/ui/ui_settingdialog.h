/********************************************************************************
** Form generated from reading UI file 'settingdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGDIALOG_H
#define UI_SETTINGDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SettingDialog
{
public:
    QVBoxLayout *verticalLayout_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *kbpsGroupBox;
    QVBoxLayout *verticalLayout_5;
    QGridLayout *gridLayout;
    QRadioButton *kbps64;
    QRadioButton *kbps128;
    QRadioButton *kbps192;
    QLabel *kbpsWarning;
    QSpacerItem *verticalSpacer_2;
    QWidget *loginTab;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QLabel *userIcon;
    QLabel *usernameLabel;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *email;
    QLineEdit *password;
    QPushButton *loginButton;
    QSpacerItem *verticalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SettingDialog)
    {
        if (SettingDialog->objectName().isEmpty())
            SettingDialog->setObjectName(QStringLiteral("SettingDialog"));
        SettingDialog->resize(278, 329);
        SettingDialog->setModal(true);
        verticalLayout_2 = new QVBoxLayout(SettingDialog);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        tabWidget = new QTabWidget(SettingDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        tabWidget->setFont(font);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout_4 = new QVBoxLayout(tab);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        kbpsGroupBox = new QGroupBox(tab);
        kbpsGroupBox->setObjectName(QStringLiteral("kbpsGroupBox"));
        kbpsGroupBox->setFont(font);
        verticalLayout_5 = new QVBoxLayout(kbpsGroupBox);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, -1, 0, -1);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        kbps64 = new QRadioButton(kbpsGroupBox);
        kbps64->setObjectName(QStringLiteral("kbps64"));
        kbps64->setChecked(true);

        gridLayout->addWidget(kbps64, 0, 0, 1, 1);

        kbps128 = new QRadioButton(kbpsGroupBox);
        kbps128->setObjectName(QStringLiteral("kbps128"));

        gridLayout->addWidget(kbps128, 0, 1, 1, 1);

        kbps192 = new QRadioButton(kbpsGroupBox);
        kbps192->setObjectName(QStringLiteral("kbps192"));

        gridLayout->addWidget(kbps192, 1, 0, 1, 1);


        verticalLayout_5->addLayout(gridLayout);

        kbpsWarning = new QLabel(kbpsGroupBox);
        kbpsWarning->setObjectName(QStringLiteral("kbpsWarning"));
        kbpsWarning->setFont(font);

        verticalLayout_5->addWidget(kbpsWarning);


        verticalLayout_4->addWidget(kbpsGroupBox);

        verticalSpacer_2 = new QSpacerItem(20, 107, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);

        tabWidget->addTab(tab, QString());
        loginTab = new QWidget();
        loginTab->setObjectName(QStringLiteral("loginTab"));
        verticalLayout_3 = new QVBoxLayout(loginTab);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        userIcon = new QLabel(loginTab);
        userIcon->setObjectName(QStringLiteral("userIcon"));
        userIcon->setMinimumSize(QSize(90, 90));
        userIcon->setMaximumSize(QSize(90, 90));
        userIcon->setPixmap(QPixmap(QString::fromUtf8(":/img/user_man_circle.png")));
        userIcon->setScaledContents(true);

        verticalLayout->addWidget(userIcon);

        usernameLabel = new QLabel(loginTab);
        usernameLabel->setObjectName(QStringLiteral("usernameLabel"));
        usernameLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(usernameLabel);


        horizontalLayout->addLayout(verticalLayout);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout);

        email = new QLineEdit(loginTab);
        email->setObjectName(QStringLiteral("email"));
        email->setInputMethodHints(Qt::ImhEmailCharactersOnly);

        verticalLayout_3->addWidget(email);

        password = new QLineEdit(loginTab);
        password->setObjectName(QStringLiteral("password"));
        password->setEchoMode(QLineEdit::Password);

        verticalLayout_3->addWidget(password);

        loginButton = new QPushButton(loginTab);
        loginButton->setObjectName(QStringLiteral("loginButton"));

        verticalLayout_3->addWidget(loginButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        tabWidget->addTab(loginTab, QString());

        verticalLayout_2->addWidget(tabWidget);

        buttonBox = new QDialogButtonBox(SettingDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        QFont font1;
        font1.setFamily(QStringLiteral("Sans"));
        buttonBox->setFont(font1);
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);

        verticalLayout_2->addWidget(buttonBox);


        retranslateUi(SettingDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), SettingDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), SettingDialog, SLOT(reject()));

        tabWidget->setCurrentIndex(1);
        loginButton->setDefault(true);


        QMetaObject::connectSlotsByName(SettingDialog);
    } // setupUi

    void retranslateUi(QDialog *SettingDialog)
    {
        SettingDialog->setWindowTitle(QApplication::translate("SettingDialog", "\350\256\276\347\275\256", 0));
        kbpsGroupBox->setTitle(QApplication::translate("SettingDialog", "\347\240\201\347\216\207", 0));
        kbps64->setText(QApplication::translate("SettingDialog", "64Kbps", 0));
        kbps128->setText(QApplication::translate("SettingDialog", "128Kbps", 0));
        kbps192->setText(QApplication::translate("SettingDialog", "192Kbps", 0));
        kbpsWarning->setText(QApplication::translate("SettingDialog", "\346\263\250\346\204\217\357\274\232\351\235\236Pro\347\224\250\346\210\267\350\256\276\347\275\256\345\260\206\346\227\240\346\225\210", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("SettingDialog", "\345\237\272\346\234\254", 0));
        userIcon->setText(QString());
        usernameLabel->setText(QApplication::translate("SettingDialog", "\346\234\252\347\231\273\345\275\225", 0));
        email->setPlaceholderText(QApplication::translate("SettingDialog", "\351\202\256\347\256\261", 0));
        password->setPlaceholderText(QApplication::translate("SettingDialog", "\345\257\206\347\240\201", 0));
        loginButton->setText(QApplication::translate("SettingDialog", "\347\231\273\345\275\225", 0));
        tabWidget->setTabText(tabWidget->indexOf(loginTab), QApplication::translate("SettingDialog", "\347\224\250\346\210\267", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingDialog: public Ui_SettingDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGDIALOG_H
