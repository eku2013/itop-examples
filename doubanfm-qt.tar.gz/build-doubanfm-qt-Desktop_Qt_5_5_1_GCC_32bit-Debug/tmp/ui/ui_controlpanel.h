/********************************************************************************
** Form generated from reading UI file 'controlpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONTROLPANEL_H
#define UI_CONTROLPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>
#include "albumwidget.h"
#include "channelwidgettrigger.h"
#include "volumetimepanel.h"

QT_BEGIN_NAMESPACE

class Ui_ControlPanel
{
public:
    QLabel *bg;
    QLabel *artist;
    QLabel *songName;
    QToolButton *pauseButton;
    QSlider *seeker;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QToolButton *likeButton;
    QSpacerItem *horizontalSpacer;
    QToolButton *trashButton;
    QSpacerItem *horizontalSpacer_2;
    QToolButton *nextButton;
    VolumeTimePanel *volumeTime;
    QLabel *album;
    ChannelWidgetTrigger *channelWidgetTrigger;
    QLabel *channelWidgetTrigger_bg;
    QLabel *channelWidgetTrigger_text;
    AlbumWidget *albumImg;
    QPushButton *lyricButton;
    QPushButton *settingButton;

    void setupUi(QWidget *ControlPanel)
    {
        if (ControlPanel->objectName().isEmpty())
            ControlPanel->setObjectName(QStringLiteral("ControlPanel"));
        ControlPanel->resize(544, 200);
        ControlPanel->setMinimumSize(QSize(544, 200));
        ControlPanel->setMaximumSize(QSize(544, 200));
        bg = new QLabel(ControlPanel);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(0, 0, 544, 200));
        bg->setMinimumSize(QSize(544, 200));
        bg->setMaximumSize(QSize(544, 200));
        bg->setStyleSheet(QStringLiteral("background: #e8edea"));
        bg->setScaledContents(true);
        artist = new QLabel(ControlPanel);
        artist->setObjectName(QStringLiteral("artist"));
        artist->setGeometry(QRect(217, 24, 261, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        font.setPointSize(16);
        font.setBold(false);
        font.setWeight(50);
        artist->setFont(font);
        songName = new QLabel(ControlPanel);
        songName->setObjectName(QStringLiteral("songName"));
        songName->setGeometry(QRect(217, 69, 261, 20));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setWeight(50);
        songName->setFont(font1);
        pauseButton = new QToolButton(ControlPanel);
        pauseButton->setObjectName(QStringLiteral("pauseButton"));
        pauseButton->setGeometry(QRect(492, 32, 13, 14));
        pauseButton->setMinimumSize(QSize(13, 14));
        pauseButton->setMaximumSize(QSize(13, 14));
        pauseButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/pause_normal.png);}\n"
"QToolButton:hover{border-image: url(:/img/pause_clicked.png);}"));
        seeker = new QSlider(ControlPanel);
        seeker->setObjectName(QStringLiteral("seeker"));
        seeker->setEnabled(false);
        seeker->setGeometry(QRect(217, 90, 291, 18));
        seeker->setMaximum(1000000);
        seeker->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(ControlPanel);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(325, 130, 181, 42));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        likeButton = new QToolButton(layoutWidget);
        likeButton->setObjectName(QStringLiteral("likeButton"));
        likeButton->setMinimumSize(QSize(37, 32));
        likeButton->setMaximumSize(QSize(37, 32));
        likeButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/like.png);}\n"
"QToolButton:hover{border-image: url(:/img/unlike.png);}\n"
"QToolButton:clicked{border-image: url(:/img/like_disabled.png);}\n"
"QToolButton:disabled{border-image: url(:/img/like_disabled.png);}"));

        horizontalLayout->addWidget(likeButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        trashButton = new QToolButton(layoutWidget);
        trashButton->setObjectName(QStringLiteral("trashButton"));
        trashButton->setMinimumSize(QSize(32, 40));
        trashButton->setMaximumSize(QSize(32, 40));
        trashButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/trash_can_normal.png);}\n"
"QToolButton:hover{border-image: url(:/img/trash_can_clicked.png);}\n"
"QToolButton:disabled{border-image: url(:/img/trash_can_clicked.png);}\n"
"QToolButton:clicked{border-image: url(:/img/trash_can_normal.png);}"));

        horizontalLayout->addWidget(trashButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        nextButton = new QToolButton(layoutWidget);
        nextButton->setObjectName(QStringLiteral("nextButton"));
        nextButton->setMinimumSize(QSize(40, 24));
        nextButton->setMaximumSize(QSize(40, 24));
        nextButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/next_normal.png);}\n"
"QToolButton:hover{border-image: url(:/img/next_clicked.png);}\n"
"QToolButton:disabled{border-image: url(:/img/next_clicked.png);}\n"
"QToolButton:clicked{border-image: url(:/img/next_normal.png);}"));

        horizontalLayout->addWidget(nextButton);

        volumeTime = new VolumeTimePanel(ControlPanel);
        volumeTime->setObjectName(QStringLiteral("volumeTime"));
        volumeTime->setGeometry(QRect(420, 107, 85, 16));
        volumeTime->setMinimumSize(QSize(85, 16));
        volumeTime->setMaximumSize(QSize(85, 16));
        album = new QLabel(ControlPanel);
        album->setObjectName(QStringLiteral("album"));
        album->setGeometry(QRect(218, 47, 291, 20));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        font2.setPointSize(9);
        album->setFont(font2);
        channelWidgetTrigger = new ChannelWidgetTrigger(ControlPanel);
        channelWidgetTrigger->setObjectName(QStringLiteral("channelWidgetTrigger"));
        channelWidgetTrigger->setGeometry(QRect(384, 0, 131, 16));
        channelWidgetTrigger->setMinimumSize(QSize(0, 0));
        channelWidgetTrigger->setMaximumSize(QSize(16777215, 16777215));
        channelWidgetTrigger_bg = new QLabel(channelWidgetTrigger);
        channelWidgetTrigger_bg->setObjectName(QStringLiteral("channelWidgetTrigger_bg"));
        channelWidgetTrigger_bg->setGeometry(QRect(0, 0, 131, 16));
        channelWidgetTrigger_bg->setPixmap(QPixmap(QString::fromUtf8(":/img/channel_handler.png")));
        channelWidgetTrigger_bg->setScaledContents(true);
        channelWidgetTrigger_text = new QLabel(channelWidgetTrigger);
        channelWidgetTrigger_text->setObjectName(QStringLiteral("channelWidgetTrigger_text"));
        channelWidgetTrigger_text->setGeometry(QRect(0, 0, 131, 16));
        channelWidgetTrigger_text->setFont(font2);
        channelWidgetTrigger_text->setAlignment(Qt::AlignCenter);
        albumImg = new AlbumWidget(ControlPanel);
        albumImg->setObjectName(QStringLiteral("albumImg"));
        albumImg->setGeometry(QRect(0, 0, 200, 200));
        albumImg->setMinimumSize(QSize(200, 200));
        albumImg->setMaximumSize(QSize(200, 200));
        lyricButton = new QPushButton(ControlPanel);
        lyricButton->setObjectName(QStringLiteral("lyricButton"));
        lyricButton->setGeometry(QRect(384, 184, 131, 16));
        lyricButton->setFont(font2);
        lyricButton->setFocusPolicy(Qt::NoFocus);
        lyricButton->setStyleSheet(QLatin1String("QPushButton {\n"
"    border-image: url(:/img/lyric_handler_normal.png);\n"
"    color: #ffffff;\n"
"}\n"
"QPushButton:pressed {\n"
"    border-image: url(:/img/lyric_handler_pressed.png);\n"
"    color: #ffffff;\n"
"}\n"
"QPushButton:checked {\n"
"    border-image: url(:/img/lyric_handler_pressed.png);\n"
"    color: #ffffff;\n"
"}"));
        lyricButton->setIconSize(QSize(16, 16));
        lyricButton->setCheckable(true);
        lyricButton->setFlat(true);
        settingButton = new QPushButton(ControlPanel);
        settingButton->setObjectName(QStringLiteral("settingButton"));
        settingButton->setGeometry(QRect(480, 60, 31, 27));
        settingButton->setFocusPolicy(Qt::NoFocus);
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/setting-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        settingButton->setIcon(icon);
        settingButton->setIconSize(QSize(20, 20));
        settingButton->setFlat(true);

        retranslateUi(ControlPanel);

        QMetaObject::connectSlotsByName(ControlPanel);
    } // setupUi

    void retranslateUi(QWidget *ControlPanel)
    {
        ControlPanel->setWindowTitle(QApplication::translate("ControlPanel", "Form", 0));
        bg->setText(QString());
        artist->setText(QApplication::translate("ControlPanel", "<html><head/><body><p><br/></p></body></html>", 0));
        songName->setText(QApplication::translate("ControlPanel", "<html><head/><body><p><br/></p></body></html>", 0));
        pauseButton->setText(QString());
        likeButton->setText(QString());
        trashButton->setText(QString());
        nextButton->setText(QString());
        album->setText(QString());
        channelWidgetTrigger_bg->setText(QString());
        channelWidgetTrigger_text->setText(QApplication::translate("ControlPanel", "<font color=white>\351\242\221&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\351\201\223</font>", 0));
        lyricButton->setText(QApplication::translate("ControlPanel", "\346\255\214     \350\257\215", 0));
        settingButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ControlPanel: public Ui_ControlPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONTROLPANEL_H
