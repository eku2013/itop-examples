/********************************************************************************
** Form generated from reading UI file 'pausemask.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAUSEMASK_H
#define UI_PAUSEMASK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PauseMask
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;

    void setupUi(QWidget *PauseMask)
    {
        if (PauseMask->objectName().isEmpty())
            PauseMask->setObjectName(QStringLiteral("PauseMask"));
        PauseMask->resize(544, 200);
        PauseMask->setMinimumSize(QSize(544, 200));
        PauseMask->setMaximumSize(QSize(544, 16777215));
        verticalLayout = new QVBoxLayout(PauseMask);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(PauseMask);
        label->setObjectName(QStringLiteral("label"));
        label->setMinimumSize(QSize(544, 200));
        label->setMaximumSize(QSize(544, 16777215));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\346\263\211\351\251\277\345\276\256\347\261\263\351\273\221"));
        label->setFont(font);
        label->setStyleSheet(QLatin1String("QLabel {\n"
"	background: rgba(255, 255, 255, 230);\n"
"}"));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);


        retranslateUi(PauseMask);

        QMetaObject::connectSlotsByName(PauseMask);
    } // setupUi

    void retranslateUi(QWidget *PauseMask)
    {
        PauseMask->setWindowTitle(QApplication::translate("PauseMask", "Form", 0));
        label->setText(QApplication::translate("PauseMask", "\347\273\247\347\273\255\346\222\255\346\224\276 >", 0));
    } // retranslateUi

};

namespace Ui {
    class PauseMask: public Ui_PauseMask {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAUSEMASK_H
