/********************************************************************************
** Form generated from reading UI file 'volumetimepanel.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VOLUMETIMEPANEL_H
#define UI_VOLUMETIMEPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VolumeTimePanel
{
public:
    QLabel *tick;
    QLabel *volumeImg;
    QSlider *volume;

    void setupUi(QWidget *VolumeTimePanel)
    {
        if (VolumeTimePanel->objectName().isEmpty())
            VolumeTimePanel->setObjectName(QStringLiteral("VolumeTimePanel"));
        VolumeTimePanel->resize(85, 16);
        VolumeTimePanel->setMinimumSize(QSize(85, 16));
        VolumeTimePanel->setMaximumSize(QSize(85, 16));
        tick = new QLabel(VolumeTimePanel);
        tick->setObjectName(QStringLiteral("tick"));
        tick->setGeometry(QRect(32, 1, 32, 16));
        tick->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setPointSize(9);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        tick->setFont(font);
        tick->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        volumeImg = new QLabel(VolumeTimePanel);
        volumeImg->setObjectName(QStringLiteral("volumeImg"));
        volumeImg->setGeometry(QRect(71, 3, 14, 12));
        volumeImg->setPixmap(QPixmap(QString::fromUtf8(":/img/volume_clicked.png")));
        volumeImg->setScaledContents(true);
        volume = new QSlider(VolumeTimePanel);
        volume->setObjectName(QStringLiteral("volume"));
        volume->setGeometry(QRect(20, 5, 61, 7));
        volume->setStyleSheet(QLatin1String("QSlider::groove:horizontal {\n"
"\n"
"background: #727982;\n"
"height: 5px;\n"
"border-radius: 4px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal {\n"
"background: qlineargradient(x1: 0, y1: 0,    x2: 0, y2: 1,\n"
"    stop: 0 #66e, stop: 1 #bbf);\n"
"background: qlineargradient(x1: 0, y1: 0.2, x2: 1, y2: 1,\n"
"    stop: 0 #bbf, stop: 1 #55f);\n"
"border: 1px solid #777;\n"
"height: 5px;\n"
"border-radius: 4px;\n"
"}\n"
"\n"
"QSlider::add-page:horizontal {\n"
"background: #fff;\n"
"border: 1px solid #777;\n"
"height: 5px;\n"
"border-radius: 4px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"width:10px\n"
"}\n"
"\n"
"QSlider::handle:horizontal:hover {\n"
"width: 10px\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal:disabled {\n"
"background: #94ad6b;\n"
"border-color: #999;\n"
"}\n"
"\n"
"QSlider::add-page:horizontal:disabled {\n"
"background: #eee;\n"
"border-color: #999;\n"
"}\n"
"\n"
"QSlider::handle:horizontal:disabled {\n"
"width: 0px\n"
"}"));
        volume->setOrientation(Qt::Horizontal);

        retranslateUi(VolumeTimePanel);

        QMetaObject::connectSlotsByName(VolumeTimePanel);
    } // setupUi

    void retranslateUi(QWidget *VolumeTimePanel)
    {
        VolumeTimePanel->setWindowTitle(QApplication::translate("VolumeTimePanel", "Form", 0));
        tick->setText(QApplication::translate("VolumeTimePanel", "0:00", 0));
        volumeImg->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class VolumeTimePanel: public Ui_VolumeTimePanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VOLUMETIMEPANEL_H
