/********************************************************************************
** Form generated from reading UI file 'channelwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANNELWIDGET_H
#define UI_CHANNELWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>
#include "horizontalslider.h"

QT_BEGIN_NAMESPACE

class Ui_ChannelWidget
{
public:
    QLabel *bg;
    QToolButton *prevButton;
    QToolButton *nextButton;
    HorizontalSlider *slider;
    QLabel *border;

    void setupUi(QWidget *ChannelWidget)
    {
        if (ChannelWidget->objectName().isEmpty())
            ChannelWidget->setObjectName(QStringLiteral("ChannelWidget"));
        ChannelWidget->resize(544, 56);
        ChannelWidget->setMinimumSize(QSize(544, 56));
        ChannelWidget->setMaximumSize(QSize(544, 56));
        bg = new QLabel(ChannelWidget);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(0, 0, 544, 58));
        bg->setMinimumSize(QSize(544, 58));
        bg->setMaximumSize(QSize(544, 58));
        bg->setPixmap(QPixmap(QString::fromUtf8(":/img/apple-ios-linen-texture.jpg")));
        prevButton = new QToolButton(ChannelWidget);
        prevButton->setObjectName(QStringLiteral("prevButton"));
        prevButton->setGeometry(QRect(32, 16, 16, 24));
        prevButton->setMinimumSize(QSize(16, 24));
        prevButton->setMaximumSize(QSize(16, 24));
        prevButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/arrow_left.png);}\n"
"QToolButton:pressed{border-image: url(:/img/arrow_left_clicked.png);}"));
        nextButton = new QToolButton(ChannelWidget);
        nextButton->setObjectName(QStringLiteral("nextButton"));
        nextButton->setGeometry(QRect(490, 16, 16, 24));
        nextButton->setMinimumSize(QSize(16, 24));
        nextButton->setMaximumSize(QSize(16, 24));
        nextButton->setStyleSheet(QLatin1String("QToolButton{border-image: url(:/img/arrow_right.png);}\n"
"QToolButton:pressed{border-image: url(:/img/arrow_right_clicked.png);}"));
        slider = new HorizontalSlider(ChannelWidget);
        slider->setObjectName(QStringLiteral("slider"));
        slider->setGeometry(QRect(60, 0, 421, 56));
        slider->setMinimumSize(QSize(0, 56));
        slider->setMaximumSize(QSize(521, 54));
        border = new QLabel(ChannelWidget);
        border->setObjectName(QStringLiteral("border"));
        border->setGeometry(QRect(0, 0, 544, 56));
        border->setStyleSheet(QLatin1String("border-style: solid;\n"
"border-width: 5px;\n"
"border-top-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 rgba(0,0,0,80), stop: 1 rgba(0,0,0,0));\n"
"border-bottom-color: rgba(0,0,0,0);\n"
"border-left-color: rgba(0,0,0,0);\n"
"border-right-color: rgba(0,0,0,0);"));

        retranslateUi(ChannelWidget);

        QMetaObject::connectSlotsByName(ChannelWidget);
    } // setupUi

    void retranslateUi(QWidget *ChannelWidget)
    {
        ChannelWidget->setWindowTitle(QApplication::translate("ChannelWidget", "Form", 0));
        bg->setText(QString());
        prevButton->setText(QString());
        nextButton->setText(QString());
        border->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ChannelWidget: public Ui_ChannelWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANNELWIDGET_H
