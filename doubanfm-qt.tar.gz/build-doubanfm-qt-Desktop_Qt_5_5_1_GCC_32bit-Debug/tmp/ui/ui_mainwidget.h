/********************************************************************************
** Form generated from reading UI file 'mainwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIDGET_H
#define UI_MAINWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>
#include "channelwidget.h"
#include "controlpanel.h"
#include "lyricwidget.h"
#include "pausemask.h"

QT_BEGIN_NAMESPACE

class Ui_MainWidget
{
public:
    ChannelWidget *channelWidget;
    ControlPanel *controlWidget;
    PauseMask *pauseWidget;
    LyricWidget *lyricWidget;

    void setupUi(QWidget *MainWidget)
    {
        if (MainWidget->objectName().isEmpty())
            MainWidget->setObjectName(QStringLiteral("MainWidget"));
        MainWidget->resize(544, 200);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWidget->sizePolicy().hasHeightForWidth());
        MainWidget->setSizePolicy(sizePolicy);
        MainWidget->setMinimumSize(QSize(544, 200));
        MainWidget->setMaximumSize(QSize(544, 200));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWidget->setWindowIcon(icon);
        channelWidget = new ChannelWidget(MainWidget);
        channelWidget->setObjectName(QStringLiteral("channelWidget"));
        channelWidget->setGeometry(QRect(0, 0, 544, 56));
        channelWidget->setMinimumSize(QSize(544, 56));
        channelWidget->setMaximumSize(QSize(544, 56));
        controlWidget = new ControlPanel(MainWidget);
        controlWidget->setObjectName(QStringLiteral("controlWidget"));
        controlWidget->setGeometry(QRect(0, 0, 544, 200));
        controlWidget->setMinimumSize(QSize(544, 200));
        controlWidget->setMaximumSize(QSize(544, 200));
        pauseWidget = new PauseMask(MainWidget);
        pauseWidget->setObjectName(QStringLiteral("pauseWidget"));
        pauseWidget->setGeometry(QRect(0, 0, 544, 200));
        lyricWidget = new LyricWidget(MainWidget);
        lyricWidget->setObjectName(QStringLiteral("lyricWidget"));
        lyricWidget->setGeometry(QRect(0, 50, 544, 151));
        lyricWidget->setMinimumSize(QSize(544, 151));
        lyricWidget->setMaximumSize(QSize(544, 151));

        retranslateUi(MainWidget);

        QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {
        MainWidget->setWindowTitle(QApplication::translate("MainWidget", "douban.fm", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIDGET_H
