/********************************************************************************
** Form generated from reading UI file 'myinputpanelform.ui'
**
** Created: Tue Aug 14 22:19:14 2018
**      by: Qt User Interface Compiler version 4.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYINPUTPANELFORM_H
#define UI_MYINPUTPANELFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyInputPanel
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout_2;
    QPushButton *panelButton_g;
    QPushButton *panelButton_t;
    QPushButton *panelButton_z;
    QPushButton *panelButton_u;
    QPushButton *panelButton_p;
    QPushButton *panelButton_q;
    QPushButton *panelButton_h;
    QPushButton *panelButton_j;
    QPushButton *panelButton_a;
    QPushButton *panelButton_x;
    QPushButton *panelButton_Caps;
    QPushButton *panelButton_b;
    QPushButton *panelButton_pun;
    QPushButton *panelButton_o;
    QPushButton *panelButton_d;
    QPushButton *panelButton_i;
    QPushButton *panelButton_k;
    QPushButton *panelButton_f;
    QPushButton *panelButton_w;
    QPushButton *panelButton_n;
    QPushButton *panelButton_BS;
    QPushButton *panelButton_Enter;
    QPushButton *panelButton_c;
    QPushButton *panelButton_r;
    QPushButton *panelButton_v;
    QPushButton *panelButton_s;
    QPushButton *panelButton_y;
    QPushButton *panelButton_l;
    QPushButton *panelButton_Space;
    QPushButton *panelButton_m;
    QPushButton *panelButton_e;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QPushButton *panelButton_9;
    QPushButton *panelButton_4;
    QPushButton *panelButton_5;
    QPushButton *panelButton_6;
    QPushButton *panelButton_2;
    QPushButton *panelButton_3;
    QPushButton *panelButton_1;
    QPushButton *panelButton_7;
    QPushButton *panelButton_8;
    QHBoxLayout *horizontalLayout;
    QPushButton *panelButton_0;
    QSpacerItem *horizontalSpacer;
    QPushButton *closeBtn;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *MyInputPanel)
    {
        if (MyInputPanel->objectName().isEmpty())
            MyInputPanel->setObjectName(QString::fromUtf8("MyInputPanel"));
        MyInputPanel->resize(412, 170);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MyInputPanel->sizePolicy().hasHeightForWidth());
        MyInputPanel->setSizePolicy(sizePolicy);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        QBrush brush1(QColor(255, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
        MyInputPanel->setPalette(palette);
        layoutWidget = new QWidget(MyInputPanel);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(2, 0, 290, 161));
        gridLayout_2 = new QGridLayout(layoutWidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        panelButton_g = new QPushButton(layoutWidget);
        panelButton_g->setObjectName(QString::fromUtf8("panelButton_g"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(panelButton_g->sizePolicy().hasHeightForWidth());
        panelButton_g->setSizePolicy(sizePolicy1);
        panelButton_g->setMinimumSize(QSize(0, 0));
        QPalette palette1;
        QBrush brush2(QColor(131, 150, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Button, brush2);
        QBrush brush3(QColor(170, 85, 0, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_g->setPalette(palette1);
        panelButton_g->setFocusPolicy(Qt::NoFocus);
        panelButton_g->setProperty("lylbuttonValue", QVariant(103));

        gridLayout_2->addWidget(panelButton_g, 1, 0, 1, 1);

        panelButton_t = new QPushButton(layoutWidget);
        panelButton_t->setObjectName(QString::fromUtf8("panelButton_t"));
        sizePolicy1.setHeightForWidth(panelButton_t->sizePolicy().hasHeightForWidth());
        panelButton_t->setSizePolicy(sizePolicy1);
        panelButton_t->setMinimumSize(QSize(0, 0));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette2.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette2.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette2.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_t->setPalette(palette2);
        panelButton_t->setFocusPolicy(Qt::NoFocus);
        panelButton_t->setProperty("lylbuttonValue", QVariant(116));

        gridLayout_2->addWidget(panelButton_t, 3, 1, 1, 1);

        panelButton_z = new QPushButton(layoutWidget);
        panelButton_z->setObjectName(QString::fromUtf8("panelButton_z"));
        sizePolicy1.setHeightForWidth(panelButton_z->sizePolicy().hasHeightForWidth());
        panelButton_z->setSizePolicy(sizePolicy1);
        panelButton_z->setMinimumSize(QSize(0, 0));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette3.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette3.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette3.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette3.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette3.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_z->setPalette(palette3);
        panelButton_z->setFocusPolicy(Qt::NoFocus);
        panelButton_z->setProperty("lylbuttonValue", QVariant(122));

        gridLayout_2->addWidget(panelButton_z, 4, 1, 1, 1);

        panelButton_u = new QPushButton(layoutWidget);
        panelButton_u->setObjectName(QString::fromUtf8("panelButton_u"));
        sizePolicy1.setHeightForWidth(panelButton_u->sizePolicy().hasHeightForWidth());
        panelButton_u->setSizePolicy(sizePolicy1);
        panelButton_u->setMinimumSize(QSize(0, 0));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette4.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette4.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette4.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette4.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette4.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_u->setPalette(palette4);
        panelButton_u->setFocusPolicy(Qt::NoFocus);
        panelButton_u->setProperty("lylbuttonValue", QVariant(117));

        gridLayout_2->addWidget(panelButton_u, 3, 2, 1, 1);

        panelButton_p = new QPushButton(layoutWidget);
        panelButton_p->setObjectName(QString::fromUtf8("panelButton_p"));
        sizePolicy1.setHeightForWidth(panelButton_p->sizePolicy().hasHeightForWidth());
        panelButton_p->setSizePolicy(sizePolicy1);
        panelButton_p->setMinimumSize(QSize(0, 0));
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette5.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette5.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette5.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette5.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette5.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_p->setPalette(palette5);
        panelButton_p->setFocusPolicy(Qt::NoFocus);
        panelButton_p->setProperty("lylbuttonValue", QVariant(112));

        gridLayout_2->addWidget(panelButton_p, 2, 3, 1, 1);

        panelButton_q = new QPushButton(layoutWidget);
        panelButton_q->setObjectName(QString::fromUtf8("panelButton_q"));
        sizePolicy1.setHeightForWidth(panelButton_q->sizePolicy().hasHeightForWidth());
        panelButton_q->setSizePolicy(sizePolicy1);
        panelButton_q->setMinimumSize(QSize(0, 0));
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette6.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette6.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette6.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette6.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette6.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_q->setPalette(palette6);
        panelButton_q->setFocusPolicy(Qt::NoFocus);
        panelButton_q->setProperty("lylbuttonValue", QVariant(113));

        gridLayout_2->addWidget(panelButton_q, 2, 4, 1, 1);

        panelButton_h = new QPushButton(layoutWidget);
        panelButton_h->setObjectName(QString::fromUtf8("panelButton_h"));
        sizePolicy1.setHeightForWidth(panelButton_h->sizePolicy().hasHeightForWidth());
        panelButton_h->setSizePolicy(sizePolicy1);
        panelButton_h->setMinimumSize(QSize(0, 0));
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette7.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette7.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette7.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette7.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette7.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_h->setPalette(palette7);
        panelButton_h->setFocusPolicy(Qt::NoFocus);
        panelButton_h->setProperty("lylbuttonValue", QVariant(104));

        gridLayout_2->addWidget(panelButton_h, 1, 1, 1, 1);

        panelButton_j = new QPushButton(layoutWidget);
        panelButton_j->setObjectName(QString::fromUtf8("panelButton_j"));
        sizePolicy1.setHeightForWidth(panelButton_j->sizePolicy().hasHeightForWidth());
        panelButton_j->setSizePolicy(sizePolicy1);
        panelButton_j->setMinimumSize(QSize(0, 0));
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette8.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette8.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette8.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette8.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette8.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_j->setPalette(palette8);
        panelButton_j->setFocusPolicy(Qt::NoFocus);
        panelButton_j->setProperty("lylbuttonValue", QVariant(106));

        gridLayout_2->addWidget(panelButton_j, 1, 3, 1, 1);

        panelButton_a = new QPushButton(layoutWidget);
        panelButton_a->setObjectName(QString::fromUtf8("panelButton_a"));
        sizePolicy1.setHeightForWidth(panelButton_a->sizePolicy().hasHeightForWidth());
        panelButton_a->setSizePolicy(sizePolicy1);
        panelButton_a->setMinimumSize(QSize(0, 0));
        QPalette palette9;
        QBrush brush4(QColor(85, 170, 255, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette9.setBrush(QPalette::Active, QPalette::Button, brush4);
        palette9.setBrush(QPalette::Active, QPalette::Shadow, brush1);
        palette9.setBrush(QPalette::Inactive, QPalette::Button, brush4);
        palette9.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
        palette9.setBrush(QPalette::Disabled, QPalette::Button, brush4);
        palette9.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
        panelButton_a->setPalette(palette9);
        panelButton_a->setFocusPolicy(Qt::NoFocus);
        panelButton_a->setProperty("lylbuttonValue", QVariant(97));

        gridLayout_2->addWidget(panelButton_a, 0, 0, 1, 1);

        panelButton_x = new QPushButton(layoutWidget);
        panelButton_x->setObjectName(QString::fromUtf8("panelButton_x"));
        sizePolicy1.setHeightForWidth(panelButton_x->sizePolicy().hasHeightForWidth());
        panelButton_x->setSizePolicy(sizePolicy1);
        panelButton_x->setMinimumSize(QSize(0, 0));
        QPalette palette10;
        palette10.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette10.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette10.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette10.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette10.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette10.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_x->setPalette(palette10);
        panelButton_x->setFocusPolicy(Qt::NoFocus);
        panelButton_x->setProperty("lylbuttonValue", QVariant(120));

        gridLayout_2->addWidget(panelButton_x, 3, 5, 1, 1);

        panelButton_Caps = new QPushButton(layoutWidget);
        panelButton_Caps->setObjectName(QString::fromUtf8("panelButton_Caps"));
        sizePolicy1.setHeightForWidth(panelButton_Caps->sizePolicy().hasHeightForWidth());
        panelButton_Caps->setSizePolicy(sizePolicy1);
        panelButton_Caps->setMinimumSize(QSize(0, 0));
        QPalette palette11;
        palette11.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette11.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette11.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette11.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette11.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette11.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_Caps->setPalette(palette11);
        panelButton_Caps->setFocusPolicy(Qt::NoFocus);
        panelButton_Caps->setProperty("lylbuttonValue", QVariant(20));

        gridLayout_2->addWidget(panelButton_Caps, 2, 6, 1, 1);

        panelButton_b = new QPushButton(layoutWidget);
        panelButton_b->setObjectName(QString::fromUtf8("panelButton_b"));
        sizePolicy1.setHeightForWidth(panelButton_b->sizePolicy().hasHeightForWidth());
        panelButton_b->setSizePolicy(sizePolicy1);
        panelButton_b->setMinimumSize(QSize(0, 0));
        QPalette palette12;
        palette12.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette12.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette12.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette12.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette12.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette12.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_b->setPalette(palette12);
        panelButton_b->setFocusPolicy(Qt::NoFocus);
        panelButton_b->setProperty("lylbuttonValue", QVariant(98));

        gridLayout_2->addWidget(panelButton_b, 0, 1, 1, 1);

        panelButton_pun = new QPushButton(layoutWidget);
        panelButton_pun->setObjectName(QString::fromUtf8("panelButton_pun"));
        sizePolicy1.setHeightForWidth(panelButton_pun->sizePolicy().hasHeightForWidth());
        panelButton_pun->setSizePolicy(sizePolicy1);
        panelButton_pun->setMinimumSize(QSize(0, 0));
        QPalette palette13;
        palette13.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette13.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette13.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette13.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette13.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette13.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_pun->setPalette(palette13);
        panelButton_pun->setFocusPolicy(Qt::NoFocus);
        panelButton_pun->setProperty("lylbuttonValue", QVariant(19));

        gridLayout_2->addWidget(panelButton_pun, 3, 6, 1, 1);

        panelButton_o = new QPushButton(layoutWidget);
        panelButton_o->setObjectName(QString::fromUtf8("panelButton_o"));
        sizePolicy1.setHeightForWidth(panelButton_o->sizePolicy().hasHeightForWidth());
        panelButton_o->setSizePolicy(sizePolicy1);
        panelButton_o->setMinimumSize(QSize(0, 0));
        QPalette palette14;
        palette14.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette14.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette14.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette14.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette14.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette14.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_o->setPalette(palette14);
        panelButton_o->setFocusPolicy(Qt::NoFocus);
        panelButton_o->setProperty("lylbuttonValue", QVariant(111));

        gridLayout_2->addWidget(panelButton_o, 2, 2, 1, 1);

        panelButton_d = new QPushButton(layoutWidget);
        panelButton_d->setObjectName(QString::fromUtf8("panelButton_d"));
        sizePolicy1.setHeightForWidth(panelButton_d->sizePolicy().hasHeightForWidth());
        panelButton_d->setSizePolicy(sizePolicy1);
        panelButton_d->setMinimumSize(QSize(0, 0));
        QPalette palette15;
        palette15.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette15.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette15.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette15.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette15.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette15.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_d->setPalette(palette15);
        panelButton_d->setFocusPolicy(Qt::NoFocus);
        panelButton_d->setProperty("lylbuttonValue", QVariant(100));

        gridLayout_2->addWidget(panelButton_d, 0, 3, 1, 1);

        panelButton_i = new QPushButton(layoutWidget);
        panelButton_i->setObjectName(QString::fromUtf8("panelButton_i"));
        sizePolicy1.setHeightForWidth(panelButton_i->sizePolicy().hasHeightForWidth());
        panelButton_i->setSizePolicy(sizePolicy1);
        panelButton_i->setMinimumSize(QSize(0, 0));
        QPalette palette16;
        palette16.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette16.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette16.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette16.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette16.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette16.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_i->setPalette(palette16);
        panelButton_i->setFocusPolicy(Qt::NoFocus);
        panelButton_i->setProperty("lylbuttonValue", QVariant(105));

        gridLayout_2->addWidget(panelButton_i, 1, 2, 1, 1);

        panelButton_k = new QPushButton(layoutWidget);
        panelButton_k->setObjectName(QString::fromUtf8("panelButton_k"));
        sizePolicy1.setHeightForWidth(panelButton_k->sizePolicy().hasHeightForWidth());
        panelButton_k->setSizePolicy(sizePolicy1);
        panelButton_k->setMinimumSize(QSize(0, 0));
        QPalette palette17;
        palette17.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette17.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette17.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette17.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette17.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette17.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_k->setPalette(palette17);
        panelButton_k->setFocusPolicy(Qt::NoFocus);
        panelButton_k->setProperty("lylbuttonValue", QVariant(107));

        gridLayout_2->addWidget(panelButton_k, 1, 4, 1, 1);

        panelButton_f = new QPushButton(layoutWidget);
        panelButton_f->setObjectName(QString::fromUtf8("panelButton_f"));
        sizePolicy1.setHeightForWidth(panelButton_f->sizePolicy().hasHeightForWidth());
        panelButton_f->setSizePolicy(sizePolicy1);
        panelButton_f->setMinimumSize(QSize(0, 0));
        QPalette palette18;
        palette18.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette18.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette18.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette18.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette18.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette18.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_f->setPalette(palette18);
        panelButton_f->setFocusPolicy(Qt::NoFocus);
        panelButton_f->setProperty("lylbuttonValue", QVariant(102));

        gridLayout_2->addWidget(panelButton_f, 0, 5, 1, 1);

        panelButton_w = new QPushButton(layoutWidget);
        panelButton_w->setObjectName(QString::fromUtf8("panelButton_w"));
        sizePolicy1.setHeightForWidth(panelButton_w->sizePolicy().hasHeightForWidth());
        panelButton_w->setSizePolicy(sizePolicy1);
        panelButton_w->setMinimumSize(QSize(0, 0));
        QPalette palette19;
        palette19.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette19.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette19.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette19.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette19.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette19.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_w->setPalette(palette19);
        panelButton_w->setFocusPolicy(Qt::NoFocus);
        panelButton_w->setProperty("lylbuttonValue", QVariant(119));

        gridLayout_2->addWidget(panelButton_w, 3, 4, 1, 1);

        panelButton_n = new QPushButton(layoutWidget);
        panelButton_n->setObjectName(QString::fromUtf8("panelButton_n"));
        sizePolicy1.setHeightForWidth(panelButton_n->sizePolicy().hasHeightForWidth());
        panelButton_n->setSizePolicy(sizePolicy1);
        panelButton_n->setMinimumSize(QSize(0, 0));
        QPalette palette20;
        palette20.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette20.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette20.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette20.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette20.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette20.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_n->setPalette(palette20);
        panelButton_n->setFocusPolicy(Qt::NoFocus);
        panelButton_n->setProperty("lylbuttonValue", QVariant(110));

        gridLayout_2->addWidget(panelButton_n, 2, 1, 1, 1);

        panelButton_BS = new QPushButton(layoutWidget);
        panelButton_BS->setObjectName(QString::fromUtf8("panelButton_BS"));
        sizePolicy1.setHeightForWidth(panelButton_BS->sizePolicy().hasHeightForWidth());
        panelButton_BS->setSizePolicy(sizePolicy1);
        panelButton_BS->setMinimumSize(QSize(0, 0));
        QPalette palette21;
        palette21.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette21.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette21.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette21.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette21.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette21.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_BS->setPalette(palette21);
        panelButton_BS->setFocusPolicy(Qt::NoFocus);
        panelButton_BS->setProperty("lylbuttonValue", QVariant(8));

        gridLayout_2->addWidget(panelButton_BS, 0, 6, 1, 1);

        panelButton_Enter = new QPushButton(layoutWidget);
        panelButton_Enter->setObjectName(QString::fromUtf8("panelButton_Enter"));
        sizePolicy1.setHeightForWidth(panelButton_Enter->sizePolicy().hasHeightForWidth());
        panelButton_Enter->setSizePolicy(sizePolicy1);
        panelButton_Enter->setMinimumSize(QSize(0, 0));
        QPalette palette22;
        palette22.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette22.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette22.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette22.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette22.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette22.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_Enter->setPalette(palette22);
        panelButton_Enter->setFocusPolicy(Qt::NoFocus);
        panelButton_Enter->setProperty("lylbuttonValue", QVariant(13));

        gridLayout_2->addWidget(panelButton_Enter, 1, 6, 1, 1);

        panelButton_c = new QPushButton(layoutWidget);
        panelButton_c->setObjectName(QString::fromUtf8("panelButton_c"));
        sizePolicy1.setHeightForWidth(panelButton_c->sizePolicy().hasHeightForWidth());
        panelButton_c->setSizePolicy(sizePolicy1);
        panelButton_c->setMinimumSize(QSize(0, 0));
        QPalette palette23;
        palette23.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette23.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette23.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette23.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette23.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette23.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_c->setPalette(palette23);
        panelButton_c->setFocusPolicy(Qt::NoFocus);
        panelButton_c->setProperty("lylbuttonValue", QVariant(99));

        gridLayout_2->addWidget(panelButton_c, 0, 2, 1, 1);

        panelButton_r = new QPushButton(layoutWidget);
        panelButton_r->setObjectName(QString::fromUtf8("panelButton_r"));
        sizePolicy1.setHeightForWidth(panelButton_r->sizePolicy().hasHeightForWidth());
        panelButton_r->setSizePolicy(sizePolicy1);
        panelButton_r->setMinimumSize(QSize(0, 0));
        QPalette palette24;
        palette24.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette24.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette24.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette24.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette24.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette24.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_r->setPalette(palette24);
        panelButton_r->setFocusPolicy(Qt::NoFocus);
        panelButton_r->setProperty("lylbuttonValue", QVariant(114));

        gridLayout_2->addWidget(panelButton_r, 2, 5, 1, 1);

        panelButton_v = new QPushButton(layoutWidget);
        panelButton_v->setObjectName(QString::fromUtf8("panelButton_v"));
        sizePolicy1.setHeightForWidth(panelButton_v->sizePolicy().hasHeightForWidth());
        panelButton_v->setSizePolicy(sizePolicy1);
        panelButton_v->setMinimumSize(QSize(0, 0));
        QPalette palette25;
        palette25.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette25.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette25.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette25.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette25.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette25.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_v->setPalette(palette25);
        panelButton_v->setFocusPolicy(Qt::NoFocus);
        panelButton_v->setProperty("lylbuttonValue", QVariant(118));

        gridLayout_2->addWidget(panelButton_v, 3, 3, 1, 1);

        panelButton_s = new QPushButton(layoutWidget);
        panelButton_s->setObjectName(QString::fromUtf8("panelButton_s"));
        sizePolicy1.setHeightForWidth(panelButton_s->sizePolicy().hasHeightForWidth());
        panelButton_s->setSizePolicy(sizePolicy1);
        panelButton_s->setMinimumSize(QSize(0, 0));
        QPalette palette26;
        palette26.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette26.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette26.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette26.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette26.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette26.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_s->setPalette(palette26);
        panelButton_s->setFocusPolicy(Qt::NoFocus);
        panelButton_s->setProperty("lylbuttonValue", QVariant(115));

        gridLayout_2->addWidget(panelButton_s, 3, 0, 1, 1);

        panelButton_y = new QPushButton(layoutWidget);
        panelButton_y->setObjectName(QString::fromUtf8("panelButton_y"));
        sizePolicy1.setHeightForWidth(panelButton_y->sizePolicy().hasHeightForWidth());
        panelButton_y->setSizePolicy(sizePolicy1);
        panelButton_y->setMinimumSize(QSize(0, 0));
        QPalette palette27;
        palette27.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette27.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette27.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette27.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette27.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette27.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_y->setPalette(palette27);
        panelButton_y->setFocusPolicy(Qt::NoFocus);
        panelButton_y->setProperty("lylbuttonValue", QVariant(121));

        gridLayout_2->addWidget(panelButton_y, 4, 0, 1, 1);

        panelButton_l = new QPushButton(layoutWidget);
        panelButton_l->setObjectName(QString::fromUtf8("panelButton_l"));
        sizePolicy1.setHeightForWidth(panelButton_l->sizePolicy().hasHeightForWidth());
        panelButton_l->setSizePolicy(sizePolicy1);
        panelButton_l->setMinimumSize(QSize(0, 0));
        QPalette palette28;
        palette28.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette28.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette28.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette28.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette28.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette28.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_l->setPalette(palette28);
        panelButton_l->setFocusPolicy(Qt::NoFocus);
        panelButton_l->setProperty("lylbuttonValue", QVariant(108));

        gridLayout_2->addWidget(panelButton_l, 1, 5, 1, 1);

        panelButton_Space = new QPushButton(layoutWidget);
        panelButton_Space->setObjectName(QString::fromUtf8("panelButton_Space"));
        sizePolicy1.setHeightForWidth(panelButton_Space->sizePolicy().hasHeightForWidth());
        panelButton_Space->setSizePolicy(sizePolicy1);
        panelButton_Space->setMinimumSize(QSize(0, 0));
        QPalette palette29;
        palette29.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette29.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette29.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette29.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette29.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette29.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_Space->setPalette(palette29);
        panelButton_Space->setFocusPolicy(Qt::NoFocus);
        panelButton_Space->setProperty("lylbuttonValue", QVariant(32));

        gridLayout_2->addWidget(panelButton_Space, 4, 2, 1, 4);

        panelButton_m = new QPushButton(layoutWidget);
        panelButton_m->setObjectName(QString::fromUtf8("panelButton_m"));
        sizePolicy1.setHeightForWidth(panelButton_m->sizePolicy().hasHeightForWidth());
        panelButton_m->setSizePolicy(sizePolicy1);
        panelButton_m->setMinimumSize(QSize(0, 0));
        QPalette palette30;
        palette30.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette30.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette30.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette30.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette30.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette30.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_m->setPalette(palette30);
        panelButton_m->setFocusPolicy(Qt::NoFocus);
        panelButton_m->setProperty("lylbuttonValue", QVariant(109));

        gridLayout_2->addWidget(panelButton_m, 2, 0, 1, 1);

        panelButton_e = new QPushButton(layoutWidget);
        panelButton_e->setObjectName(QString::fromUtf8("panelButton_e"));
        sizePolicy1.setHeightForWidth(panelButton_e->sizePolicy().hasHeightForWidth());
        panelButton_e->setSizePolicy(sizePolicy1);
        panelButton_e->setMinimumSize(QSize(0, 0));
        QPalette palette31;
        palette31.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette31.setBrush(QPalette::Active, QPalette::Shadow, brush3);
        palette31.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette31.setBrush(QPalette::Inactive, QPalette::Shadow, brush3);
        palette31.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette31.setBrush(QPalette::Disabled, QPalette::Shadow, brush3);
        panelButton_e->setPalette(palette31);
        panelButton_e->setFocusPolicy(Qt::NoFocus);
        panelButton_e->setProperty("lylbuttonValue", QVariant(101));

        gridLayout_2->addWidget(panelButton_e, 0, 4, 1, 1);

        layoutWidget1 = new QWidget(MyInputPanel);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(293, 0, 111, 161));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        panelButton_9 = new QPushButton(layoutWidget1);
        panelButton_9->setObjectName(QString::fromUtf8("panelButton_9"));
        sizePolicy1.setHeightForWidth(panelButton_9->sizePolicy().hasHeightForWidth());
        panelButton_9->setSizePolicy(sizePolicy1);
        panelButton_9->setMinimumSize(QSize(0, 0));
        QPalette palette32;
        palette32.setBrush(QPalette::Active, QPalette::Button, brush2);
        QBrush brush5(QColor(170, 2, 4, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette32.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette32.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette32.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette32.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette32.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_9->setPalette(palette32);
        panelButton_9->setFocusPolicy(Qt::NoFocus);
        panelButton_9->setCheckable(false);
        panelButton_9->setProperty("lylbuttonValue", QVariant(57));

        gridLayout->addWidget(panelButton_9, 2, 2, 1, 1);

        panelButton_4 = new QPushButton(layoutWidget1);
        panelButton_4->setObjectName(QString::fromUtf8("panelButton_4"));
        sizePolicy1.setHeightForWidth(panelButton_4->sizePolicy().hasHeightForWidth());
        panelButton_4->setSizePolicy(sizePolicy1);
        panelButton_4->setMinimumSize(QSize(0, 0));
        QPalette palette33;
        palette33.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette33.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette33.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette33.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette33.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette33.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_4->setPalette(palette33);
        panelButton_4->setFocusPolicy(Qt::NoFocus);
        panelButton_4->setCheckable(false);
        panelButton_4->setProperty("lylbuttonValue", QVariant(52));

        gridLayout->addWidget(panelButton_4, 1, 0, 1, 1);

        panelButton_5 = new QPushButton(layoutWidget1);
        panelButton_5->setObjectName(QString::fromUtf8("panelButton_5"));
        sizePolicy1.setHeightForWidth(panelButton_5->sizePolicy().hasHeightForWidth());
        panelButton_5->setSizePolicy(sizePolicy1);
        panelButton_5->setMinimumSize(QSize(0, 0));
        QPalette palette34;
        palette34.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette34.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette34.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette34.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette34.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette34.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_5->setPalette(palette34);
        panelButton_5->setFocusPolicy(Qt::NoFocus);
        panelButton_5->setCheckable(false);
        panelButton_5->setProperty("lylbuttonValue", QVariant(53));

        gridLayout->addWidget(panelButton_5, 1, 1, 1, 1);

        panelButton_6 = new QPushButton(layoutWidget1);
        panelButton_6->setObjectName(QString::fromUtf8("panelButton_6"));
        sizePolicy1.setHeightForWidth(panelButton_6->sizePolicy().hasHeightForWidth());
        panelButton_6->setSizePolicy(sizePolicy1);
        panelButton_6->setMinimumSize(QSize(0, 0));
        QPalette palette35;
        palette35.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette35.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette35.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette35.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette35.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette35.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_6->setPalette(palette35);
        panelButton_6->setFocusPolicy(Qt::NoFocus);
        panelButton_6->setCheckable(false);
        panelButton_6->setProperty("lylbuttonValue", QVariant(54));

        gridLayout->addWidget(panelButton_6, 1, 2, 1, 1);

        panelButton_2 = new QPushButton(layoutWidget1);
        panelButton_2->setObjectName(QString::fromUtf8("panelButton_2"));
        sizePolicy1.setHeightForWidth(panelButton_2->sizePolicy().hasHeightForWidth());
        panelButton_2->setSizePolicy(sizePolicy1);
        panelButton_2->setMinimumSize(QSize(0, 0));
        QPalette palette36;
        palette36.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette36.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette36.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette36.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette36.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette36.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_2->setPalette(palette36);
        panelButton_2->setFocusPolicy(Qt::NoFocus);
        panelButton_2->setCheckable(false);
        panelButton_2->setProperty("lylbuttonValue", QVariant(50));

        gridLayout->addWidget(panelButton_2, 0, 1, 1, 1);

        panelButton_3 = new QPushButton(layoutWidget1);
        panelButton_3->setObjectName(QString::fromUtf8("panelButton_3"));
        sizePolicy1.setHeightForWidth(panelButton_3->sizePolicy().hasHeightForWidth());
        panelButton_3->setSizePolicy(sizePolicy1);
        panelButton_3->setMinimumSize(QSize(0, 0));
        QPalette palette37;
        palette37.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette37.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette37.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette37.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette37.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette37.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_3->setPalette(palette37);
        panelButton_3->setFocusPolicy(Qt::NoFocus);
        panelButton_3->setCheckable(false);
        panelButton_3->setProperty("lylbuttonValue", QVariant(51));

        gridLayout->addWidget(panelButton_3, 0, 2, 1, 1);

        panelButton_1 = new QPushButton(layoutWidget1);
        panelButton_1->setObjectName(QString::fromUtf8("panelButton_1"));
        sizePolicy1.setHeightForWidth(panelButton_1->sizePolicy().hasHeightForWidth());
        panelButton_1->setSizePolicy(sizePolicy1);
        panelButton_1->setMinimumSize(QSize(0, 0));
        QPalette palette38;
        palette38.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette38.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette38.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette38.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette38.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette38.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_1->setPalette(palette38);
        panelButton_1->setFocusPolicy(Qt::NoFocus);
        panelButton_1->setCheckable(false);
        panelButton_1->setProperty("lylbuttonValue", QVariant(49));

        gridLayout->addWidget(panelButton_1, 0, 0, 1, 1);

        panelButton_7 = new QPushButton(layoutWidget1);
        panelButton_7->setObjectName(QString::fromUtf8("panelButton_7"));
        sizePolicy1.setHeightForWidth(panelButton_7->sizePolicy().hasHeightForWidth());
        panelButton_7->setSizePolicy(sizePolicy1);
        panelButton_7->setMinimumSize(QSize(0, 0));
        QPalette palette39;
        palette39.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette39.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette39.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette39.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette39.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette39.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_7->setPalette(palette39);
        panelButton_7->setFocusPolicy(Qt::NoFocus);
        panelButton_7->setCheckable(false);
        panelButton_7->setProperty("lylbuttonValue", QVariant(55));

        gridLayout->addWidget(panelButton_7, 2, 0, 1, 1);

        panelButton_8 = new QPushButton(layoutWidget1);
        panelButton_8->setObjectName(QString::fromUtf8("panelButton_8"));
        sizePolicy1.setHeightForWidth(panelButton_8->sizePolicy().hasHeightForWidth());
        panelButton_8->setSizePolicy(sizePolicy1);
        panelButton_8->setMinimumSize(QSize(0, 0));
        QPalette palette40;
        palette40.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette40.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette40.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette40.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette40.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette40.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_8->setPalette(palette40);
        panelButton_8->setFocusPolicy(Qt::NoFocus);
        panelButton_8->setCheckable(false);
        panelButton_8->setProperty("lylbuttonValue", QVariant(56));

        gridLayout->addWidget(panelButton_8, 2, 1, 1, 1);


        verticalLayout->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        panelButton_0 = new QPushButton(layoutWidget1);
        panelButton_0->setObjectName(QString::fromUtf8("panelButton_0"));
        sizePolicy1.setHeightForWidth(panelButton_0->sizePolicy().hasHeightForWidth());
        panelButton_0->setSizePolicy(sizePolicy1);
        panelButton_0->setMinimumSize(QSize(0, 0));
        QPalette palette41;
        palette41.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette41.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette41.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette41.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette41.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette41.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        panelButton_0->setPalette(palette41);
        panelButton_0->setFocusPolicy(Qt::NoFocus);
        panelButton_0->setCheckable(false);
        panelButton_0->setProperty("lylbuttonValue", QVariant(48));

        horizontalLayout->addWidget(panelButton_0);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        closeBtn = new QPushButton(layoutWidget1);
        closeBtn->setObjectName(QString::fromUtf8("closeBtn"));
        sizePolicy1.setHeightForWidth(closeBtn->sizePolicy().hasHeightForWidth());
        closeBtn->setSizePolicy(sizePolicy1);
        closeBtn->setMinimumSize(QSize(0, 0));
        QPalette palette42;
        palette42.setBrush(QPalette::Active, QPalette::Button, brush2);
        palette42.setBrush(QPalette::Active, QPalette::Shadow, brush5);
        palette42.setBrush(QPalette::Inactive, QPalette::Button, brush2);
        palette42.setBrush(QPalette::Inactive, QPalette::Shadow, brush5);
        palette42.setBrush(QPalette::Disabled, QPalette::Button, brush2);
        palette42.setBrush(QPalette::Disabled, QPalette::Shadow, brush5);
        closeBtn->setPalette(palette42);
        closeBtn->setFocusPolicy(Qt::NoFocus);
        closeBtn->setCheckable(false);
        closeBtn->setProperty("lylbuttonValue", QVariant(QChar(48)));

        horizontalLayout->addWidget(closeBtn);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        retranslateUi(MyInputPanel);
        QObject::connect(closeBtn, SIGNAL(clicked()), MyInputPanel, SLOT(hide()));

        QMetaObject::connectSlotsByName(MyInputPanel);
    } // setupUi

    void retranslateUi(QWidget *MyInputPanel)
    {
        MyInputPanel->setWindowTitle(QApplication::translate("MyInputPanel", "Soft_keyboard", 0, QApplication::UnicodeUTF8));
        panelButton_g->setText(QApplication::translate("MyInputPanel", "g", 0, QApplication::UnicodeUTF8));
        panelButton_t->setText(QApplication::translate("MyInputPanel", "t", 0, QApplication::UnicodeUTF8));
        panelButton_z->setText(QApplication::translate("MyInputPanel", "z", 0, QApplication::UnicodeUTF8));
        panelButton_u->setText(QApplication::translate("MyInputPanel", "u", 0, QApplication::UnicodeUTF8));
        panelButton_p->setText(QApplication::translate("MyInputPanel", "p", 0, QApplication::UnicodeUTF8));
        panelButton_q->setText(QApplication::translate("MyInputPanel", "q", 0, QApplication::UnicodeUTF8));
        panelButton_h->setText(QApplication::translate("MyInputPanel", "h", 0, QApplication::UnicodeUTF8));
        panelButton_j->setText(QApplication::translate("MyInputPanel", "j", 0, QApplication::UnicodeUTF8));
        panelButton_a->setText(QApplication::translate("MyInputPanel", "a", 0, QApplication::UnicodeUTF8));
        panelButton_x->setText(QApplication::translate("MyInputPanel", "x", 0, QApplication::UnicodeUTF8));
        panelButton_Caps->setText(QApplication::translate("MyInputPanel", "Caps", 0, QApplication::UnicodeUTF8));
        panelButton_b->setText(QApplication::translate("MyInputPanel", "b", 0, QApplication::UnicodeUTF8));
        panelButton_pun->setText(QApplication::translate("MyInputPanel", ".?123", 0, QApplication::UnicodeUTF8));
        panelButton_o->setText(QApplication::translate("MyInputPanel", "o", 0, QApplication::UnicodeUTF8));
        panelButton_d->setText(QApplication::translate("MyInputPanel", "d", 0, QApplication::UnicodeUTF8));
        panelButton_i->setText(QApplication::translate("MyInputPanel", "i", 0, QApplication::UnicodeUTF8));
        panelButton_k->setText(QApplication::translate("MyInputPanel", "k", 0, QApplication::UnicodeUTF8));
        panelButton_f->setText(QApplication::translate("MyInputPanel", "f", 0, QApplication::UnicodeUTF8));
        panelButton_w->setText(QApplication::translate("MyInputPanel", "w", 0, QApplication::UnicodeUTF8));
        panelButton_n->setText(QApplication::translate("MyInputPanel", "n", 0, QApplication::UnicodeUTF8));
        panelButton_BS->setText(QApplication::translate("MyInputPanel", "BS", 0, QApplication::UnicodeUTF8));
        panelButton_Enter->setText(QApplication::translate("MyInputPanel", "Enter", 0, QApplication::UnicodeUTF8));
        panelButton_c->setText(QApplication::translate("MyInputPanel", "c", 0, QApplication::UnicodeUTF8));
        panelButton_r->setText(QApplication::translate("MyInputPanel", "r", 0, QApplication::UnicodeUTF8));
        panelButton_v->setText(QApplication::translate("MyInputPanel", "v", 0, QApplication::UnicodeUTF8));
        panelButton_s->setText(QApplication::translate("MyInputPanel", "s", 0, QApplication::UnicodeUTF8));
        panelButton_y->setText(QApplication::translate("MyInputPanel", "y", 0, QApplication::UnicodeUTF8));
        panelButton_l->setText(QApplication::translate("MyInputPanel", "l", 0, QApplication::UnicodeUTF8));
        panelButton_Space->setText(QApplication::translate("MyInputPanel", "Space", 0, QApplication::UnicodeUTF8));
        panelButton_m->setText(QApplication::translate("MyInputPanel", "m", 0, QApplication::UnicodeUTF8));
        panelButton_e->setText(QApplication::translate("MyInputPanel", "e", 0, QApplication::UnicodeUTF8));
        panelButton_9->setText(QApplication::translate("MyInputPanel", "9", 0, QApplication::UnicodeUTF8));
        panelButton_4->setText(QApplication::translate("MyInputPanel", "4", 0, QApplication::UnicodeUTF8));
        panelButton_5->setText(QApplication::translate("MyInputPanel", "5", 0, QApplication::UnicodeUTF8));
        panelButton_6->setText(QApplication::translate("MyInputPanel", "6", 0, QApplication::UnicodeUTF8));
        panelButton_2->setText(QApplication::translate("MyInputPanel", "2", 0, QApplication::UnicodeUTF8));
        panelButton_3->setText(QApplication::translate("MyInputPanel", "3", 0, QApplication::UnicodeUTF8));
        panelButton_1->setText(QApplication::translate("MyInputPanel", "1", 0, QApplication::UnicodeUTF8));
        panelButton_7->setText(QApplication::translate("MyInputPanel", "7", 0, QApplication::UnicodeUTF8));
        panelButton_8->setText(QApplication::translate("MyInputPanel", "8", 0, QApplication::UnicodeUTF8));
        panelButton_0->setText(QApplication::translate("MyInputPanel", "0", 0, QApplication::UnicodeUTF8));
        closeBtn->setText(QApplication::translate("MyInputPanel", "close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MyInputPanel: public Ui_MyInputPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYINPUTPANELFORM_H
