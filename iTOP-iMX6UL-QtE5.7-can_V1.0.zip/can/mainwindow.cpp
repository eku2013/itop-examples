#include <sys/ioctl.h>
#include <fcntl.h>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    startcan(0);

}

MainWindow::~MainWindow()
{
    delete ui;
    stopcan(btg->checkedId());
}

void MainWindow::msg(QString str)
{
    ui->label->append(str);
}

void MainWindow::on_send_clicked()
{
    struct can_frame frame;
    memset(&frame,0,sizeof(struct can_frame));
    std::string  str=ui->edit->text().toStdString();

    if(str.length() > 8)
    {
        QMessageBox::about(this,"error","length of send string must less than 8 bytes");
        return;
    }



    frame.can_id = 0x123;
    strcpy((char*)frame.data,str.c_str());
    frame.can_dlc = str.length();

    sendto(socket,&frame,sizeof(struct can_frame),0,(struct sockaddr*)&addr,sizeof(addr));
    return;
}

void MainWindow::moveEvent(QMoveEvent *)
{
    this->move(QPoint(0,0));
}

void MainWindow::resizeEvent(QResizeEvent *)
{
    this->showMaximized();
}

void MainWindow::closeEvent(QCloseEvent *)
{
     destroy();
    exit(0);
}

void MainWindow::startcan(int v)
{
   int ret = 0;
    if(v == 0)
    {
        system("ifconfig can0 down");
        system("canconfig can0 bitrate 50000 ctrlmode triple-sampling on");
        system("ifconfig can0 up");
    }
    else
    {
        system("ifconfig can1 down");
        system("canconfig can0 bitrate 50000 ctrlmode triple-sampling on");
        system("ifconfig can1 up");
    }

    socket =  ::socket(PF_CAN,SOCK_RAW,CAN_RAW);

    struct ifreq ifr;
    strcpy((char *)(ifr.ifr_name),v == 0 ? "can0" : "can1");
    ioctl(socket,SIOCGIFINDEX,&ifr);

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    ret = bind(socket,(struct sockaddr*)&addr,sizeof(addr));
    if (ret < 0)
     {
     QMessageBox::about(this,"error","in bind error");
     exit(1);
     }

    t = NULL;

    t = new Thread(socket);

    connect(t,SIGNAL(msg(QString)),this,SLOT(msg(QString)));

    t->start();
}

void MainWindow::stopcan(int v)
{
    if(t)
    {
        t->stop();
        t->deleteLater();
    }

    //::close(socket);

    if(v == 0)
        system("ifconfig can0 down");
    else
        system("ifconfig can1 down");
}

void MainWindow::on_can0_toggled(bool checked)
{
    if(checked)
    {
        stopcan(1);
        startcan(0);
    }
}

void MainWindow::on_can1_toggled(bool checked)
{
    if(checked)
    {
        stopcan(0);
        startcan(1);
    }
}
