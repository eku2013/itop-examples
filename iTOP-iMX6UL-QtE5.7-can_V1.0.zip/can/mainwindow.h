#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProcess>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/can.h>
#include "thread.h"
#include <QButtonGroup>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
protected:
    void moveEvent(QMoveEvent *);
    void resizeEvent(QResizeEvent *);
    void closeEvent(QCloseEvent *);
private slots:
    void on_send_clicked();
    void msg(QString str);
    void stopcan(int v);
    void startcan(int v);
    void on_can0_toggled(bool checked);
    void on_can1_toggled(bool checked);

private:
    Ui::MainWindow *ui;
    int socket;
    struct sockaddr_can addr;
    Thread *t;
    QButtonGroup* btg;
};

#endif // MAINWINDOW_H
