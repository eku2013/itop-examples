/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio;

import java.lang.reflect.Method;
import java.util.ArrayList;
import com.borqs.fmradio.list.FMListAdapter;
import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.borqs.fmradio.xml.XmlConst;
import com.ti.fm.FmRadio;
import com.ti.fm.FmRadioIntent;


import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnCancelListener;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RelativeLayout;
import android.graphics.drawable.Drawable;

public class AllActivity extends Activity implements OnItemClickListener{
    
    private static final String TAG = AllActivity.class.getSimpleName();
    private ListView mListView = null;
    private FMListAdapter mAdapter = null;
    private ChannelHolder mChannelHolder = null;
    private ImageButton mTitleBtn = null;
    private AlertDialog mScanDialog = null;
    private ProgressDialog cancelScanDialog = null;
    private Dialog mAddChannelDialog = null;
    private Drawable mAddChannelIconLight;
    private Drawable mAddChannelIconDark;
    
	private EditText mAddNameField;
	private EditText mAddChannelField;
	private boolean mAllSelected = false;
    private AlertDialog mDialog = null;
    private static final int MENU_SCAN_ALL = Menu.FIRST;
    private static final int EVENT_REFRESH_DATA = 1;
    private static final int EVENT_DISABLE_FM = 2;
    private static final int EVENT_CANCEL_SCAN = 3;
    
    BroadcastReceiver receiver = new BroadcastReceiver(){

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if (Intent.ACTION_HEADSET_PLUG.equals(intent.getAction())) {
				int state = intent.getIntExtra("state", 0);
				if (state != 0) {
					if (null != mDialog) {
						mDialog.dismiss();
					}
				} else {
					mDialog = new AlertDialog.Builder(AllActivity.this)
					.setTitle(R.string.no_headset)
					.setIcon(R.drawable.art_dialog_notice)
					.setMessage(R.string.no_headset)
					.setNegativeButton(R.string.cancel,
							new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog,
								int which) {
							// TODO Auto-generated method stub
							noHeadsetDisableFM();
						}
					}).setOnCancelListener(new OnCancelListener() {
						public void onCancel(DialogInterface dialog) {
							noHeadsetDisableFM();
						}
					}).show();
				}
			} else if (FmRadioIntent.FM_DISABLED_ACTION.equals(intent.getAction())){
			     Message result = Message.obtain(mHandler,EVENT_DISABLE_FM);
				 mHandler.sendMessageDelayed(result, 2000);
			} else {
				if (null != mDialog) {
					mDialog.dismiss();
				}
			}
			
		}
    	
    };

    private BroadcastReceiver mBr = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Constants.SCAN_FINISH.equals(action)) {
                handleScanFinish();
            } else if (Constants.SCAN_ALREADY_STOP.equals(action)) {
                scanAlreadyStop(intent);
            } /*else if (Constants.FINISH_FM.equals(action)) {
                finish();
            }*/ else if (Constants.REFRESH_LISTVIEW.equals(action)) {
                LogUtils.d(TAG,"onFound channel from callback,then refresh listview");
                mAdapter.notifyDataSetChanged();
            }
        } 
    };

    private void scanAlreadyStop(Intent intent) {
        try {
        	if (null != mAdapter) {
        		mAdapter.notifyDataSetChanged();
        	}
        	if (null != mChannelHolder) {
        		mChannelHolder.flush();
        	}
            if (cancelScanDialog != null && cancelScanDialog.isShowing()){
                cancelScanDialog.dismiss();
                Toast.makeText(AllActivity.this, R.string.stop_scan_success, 500).show();
            }
            if (null != mListView) {
            	mListView.setEnabled(true);
            }
            
        } catch (IllegalStateException e) {
            LogUtils.d(TAG,"scan already stop ,please check illegal state");
        }
    }

    private void handleScanFinish() {
        LogUtils.d(TAG,"mScanDialog " + mScanDialog);
        if (mScanDialog != null && mScanDialog.isShowing()) {
            mScanDialog.dismiss();
        } else {
        	if (cancelScanDialog != null && cancelScanDialog.isShowing()){
                cancelScanDialog.dismiss();
            }
            LogUtils.d(TAG,"scan dialog is not showing");
            return;
        }
        mChannelHolder.flush();
        mListView.setEnabled(true);
        mAdapter.notifyDataSetChanged();
        Toast.makeText(this, R.string.scan_finish, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mChannelHolder = ChannelHolder.getInstance();
		mAddChannelIconLight = this.getApplicationContext().getResources()
				.getDrawable(R.drawable.ic_menu_add_holo_light);
		mAddChannelIconDark = this.getApplicationContext().getResources()
				.getDrawable(R.drawable.ic_menu_add_holo_dark);
        setContentView(R.layout.browser_station_list);
        setupViews();
        IntentFilter intentFilter = new IntentFilter(Constants.SCAN_FINISH);
//        intentFilter.addAction(Constants.FINISH_FM);
        intentFilter.addAction(Constants.SCAN_ALREADY_STOP);
        intentFilter.addAction(Constants.REFRESH_LISTVIEW);
        registerReceiver(mBr, intentFilter);
        
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_HEADSET_PLUG);
        filter.addAction(FmRadioIntent.FM_DISABLED_ACTION);
        registerReceiver(receiver,filter);
        mChannelHolder.setIsForegroundActivity(true);
        createAddChannelActionBar();
    }

    private void createAddChannelActionBar() {
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(R.string.scan_label);
        actionBar.setDisplayShowCustomEnabled(true);

        LayoutInflater inflater = (LayoutInflater)AllActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = (View)inflater.inflate(R.layout.add_channel,null);
		actionBar.setCustomView(view, new ActionBar.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT,
				Gravity.RIGHT));
       ImageView addchannel = (ImageView) actionBar.getCustomView().findViewById(R.id.add_channel);
       if (mChannelHolder.isAndroidTheme()) {
    	   addchannel.setImageDrawable(mAddChannelIconDark);
       } else {
    	   addchannel.setImageDrawable(mAddChannelIconLight);
       }
       addchannel.setOnClickListener(addChannelListener);
    }

    OnClickListener addChannelListener = new OnClickListener(){

		@Override
		public void onClick(View arg0) {

			LayoutInflater inflater = (LayoutInflater)AllActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				mAddChannelDialog = new AlertDialog.Builder(AllActivity.this)
						.setIcon(R.drawable.fm_app_icon)
						.setTitle(R.string.add)
						.setView(inflater.inflate(R.layout.add_channel_content, null))
						.setPositiveButton(R.string.ok,
								new DialogInterface.OnClickListener() {

									public void onClick(DialogInterface arg0,
											int arg1) {
										addChannel();
										Message result = Message.obtain(mHandler,EVENT_REFRESH_DATA);
															mHandler.sendMessageDelayed(result, 100);
									}
								})
						.setNegativeButton(R.string.cancel,
								new DialogInterface.OnClickListener() {

									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub

									}
								}).create();
				
				mAddChannelDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
				mAddChannelDialog.show();
		}};

	Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case EVENT_REFRESH_DATA:
				if (null != mAdapter) {
					mAdapter.notifyDataSetChanged();
				}
				break;
			case EVENT_DISABLE_FM:
				finish();
				break;
			case EVENT_CANCEL_SCAN:
				scanAlreadyStop(null);
				break;
			}
		}
	};
    private void addChannel(){
		mAddNameField = (EditText) mAddChannelDialog
				.findViewById(R.id.name);
		mAddChannelField = (EditText) mAddChannelDialog
				.findViewById(R.id.channel);
		// TODO Auto-generated method stub
		String name = mAddNameField.getText().toString().trim();
		if (TextUtils.isEmpty(name)) {
			Toast.makeText(AllActivity.this,
					R.string.name_empty,
					Toast.LENGTH_LONG)
					.show();
			return;
		}
		try {
			double dc = Double
					.valueOf(mAddChannelField
							.getText()
							.toString());
			int ic = (int) (dc * 1000);
			if ((dc * 1000 % 100) > 0) {
				Toast.makeText(AllActivity.this, R.string.channel_wrong_value,
						Toast.LENGTH_LONG)
						.show();
				return;
			}
			
			SharedPreferences fmConfigPreferences  = getSharedPreferences("fmConfigPreferences",
      				MODE_PRIVATE); 
            int bandFlag = fmConfigPreferences.getInt(Constants.BAND, 0);
              
            if(bandFlag == Constants.EUROPE_BAND) {
              if (ic > Constants.EUROPE_MAX_FREQ || ic < Constants.EUROPE_MIN_FREQ){
                      Toast.makeText(AllActivity.this, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                      return;
                 }
            } else if(bandFlag == Constants.JAPAN_BAND) {
              	if (ic > Constants.JAPAN_MAX_FREQ || ic < Constants.JAPAN_MIN_FREQ){
                      Toast.makeText(AllActivity.this, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                      return;
                  }
            }
			
            if (null != mChannelHolder) {
            	if (-1 != mChannelHolder.isInList(ic)) {
            		if (!TextUtils.isEmpty(mChannelHolder.getChannelName(ic))){		
            			Toast.makeText(AllActivity.this, R.string.favorite_channel_exist, Toast.LENGTH_LONG).show();
            			return;
            		}
            	}
            }
			String channel = String.valueOf(ic);
			Station station = new Station();
			station.setName(name);
			station.setFreq(channel);
			station.setFavorStatus(String
					.valueOf(false));
			station.setPosition(0);
			int result = mChannelHolder.add(station);
			if (result == -1) {
				Toast.makeText(
						AllActivity.this,
						R.string.all_max_info,
						Toast.LENGTH_LONG)
						.show();
			}

		} catch (NumberFormatException e) {
			Toast.makeText(
					AllActivity.this,
					R.string.channel_wrong_value,
					Toast.LENGTH_LONG)
					.show();
			return;
		}
    }
    @Override
    protected void onResume() {
        super.onResume();
        mAdapter.notifyDataSetChanged();
        if(!mChannelHolder.getIsForegroundActivity()){
       	 mChannelHolder.setIsForegroundActivity(true);
       }
    }

    @Override
    protected void onPause(){
        super.onPause();
        if (mAdapter != null) {
        	mAdapter.notifyDataSetChanged();
        }
        if(mChannelHolder.getIsForegroundActivity()){
       	 mChannelHolder.setIsForegroundActivity(false);
       }
    }

    @Override
    protected void onStop() {
        super.onStop();
        mListView.setEnabled(true);
    }

    protected void onDestroy() {
    	LogUtils.d(TAG,"onDestroy");
        super.onDestroy();
        unregisterReceiver(mBr);
        unregisterReceiver(receiver);
        
        if (mListView != null){
        	mListView.setAdapter(null);
        	mListView.setOnItemClickListener(null);
            mListView.setMultiChoiceModeListener(null);
        }
        mListView = null;
        if (mAdapter != null){
        	mAdapter.clear();
        }
        mAdapter = null;
		if (null != mDialog) {
			mDialog.dismiss();
		}
		mDialog = null;
        if (mScanDialog != null) {
        	mScanDialog.setOnCancelListener(null);
            mScanDialog.dismiss();
        }
        mScanDialog = null;
        if (cancelScanDialog != null) {
            cancelScanDialog.dismiss();
        }
        cancelScanDialog = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	  super.onCreateOptionsMenu(menu);	
    	  menu.add(0,MENU_SCAN_ALL, 0, R.string.scan_title)
    	  .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
    	  return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(MENU_SCAN_ALL).setEnabled(true);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final int itemId = item.getItemId();
        switch (itemId) {
        case MENU_SCAN_ALL:
        	scanAllChannel();
        	return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        try {
            LogUtils.d(TAG,"parent is " + parent + ", view is " + v + ", position is " + position + ", id is " + id);
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
    		boolean isHeadsetOn = am.isWiredHeadsetOn();
    		LogUtils.d(TAG,"onItemClick isHeadsetOn " + isHeadsetOn);
            if (!isHeadsetOn)
    			return;
            Intent intent = new Intent(this, FMService.class);
            intent.setAction(Constants.SET_CHANNEL);
            Station sta = mChannelHolder.getStationList().get(position);
            intent.putExtra("channel",Double.valueOf(sta.getFreq())/1000);
            startService(intent);
            mChannelHolder.setLauncher(XmlConst.VALUE_ALL_ACTIVITY);
        } catch (IllegalStateException e) {
            LogUtils.d(TAG,"onItemClick please check the illeagal state");
        } finally {
            over();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            mChannelHolder.setLauncher(XmlConst.VALUE_ALL_ACTIVITY);
            over();
        }
        return super.onKeyDown(keyCode, event);
    }

    private void over() {
        if (mScanDialog != null && mScanDialog.isShowing()) {
            mScanDialog.dismiss();
        }
        if (cancelScanDialog != null && cancelScanDialog.isShowing()) {
            cancelScanDialog.dismiss();
        }
        finish();
    }
    private void setupViews() {
    	mListView = (ListView) findViewById(R.id.listview);
        mAdapter = FMListAdapter.getInstance(this, mChannelHolder.getStationList(),mListView);   
        mListView.setAdapter(mAdapter);
        LogUtils.d(TAG,"List view size is : " + mListView.getCount());
        mListView.setOnItemClickListener(this);
        mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        mListView.setMultiChoiceModeListener(new ModeCallback());
        mAdapter.notifyDataSetChanged();
        
    }
    

    
    private class ModeCallback implements ListView.MultiChoiceModeListener {
    	private View mMultiSelectActionBarView;
		private ImageView mMultiSelect;
		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			switch (item.getItemId()) {
			case R.id.multi_delete:
				if (mListView.getCheckedItemCount() == 0) {
					Toast.makeText(AllActivity.this,
							getString(R.string.choose_item_to_delete),
							Toast.LENGTH_SHORT).show();
					return true;
				} else {
					deleteChannelItem(mode);
				}
				break;
			default:
				break;
			}
			return true;
		}

		public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
			MenuInflater inflater = getMenuInflater();
			inflater.inflate(R.menu.all_channel_del_menu, menu);
			if (mMultiSelectActionBarView == null) {
				mMultiSelectActionBarView = getLayoutInflater().inflate(R.layout.action_mode_custom_view, null);

				mMultiSelect = (ImageView) mMultiSelectActionBarView.findViewById(R.id.multi_select);
				mMultiSelect.setImageResource(R.drawable.art_check_all_nor);
				mMultiSelect.setOnClickListener(mSelectListener);
			}
			actionMode.setCustomView(mMultiSelectActionBarView);
			((TextView) mMultiSelectActionBarView.findViewById(R.id.title)).setText(R.string.select_channel);
			return true;
		}

		public void onDestroyActionMode(ActionMode arg0) {
			// TODO Auto-generated method stub
			
		}

		public boolean onPrepareActionMode(ActionMode arg0, Menu arg1) {
			// TODO Auto-generated method stub
			return false;
		}

		public void onItemCheckedStateChanged(ActionMode mode, int position,
				long id, boolean checked) {
			if (mListView.getCheckedItemCount() == mListView.getCount()) {
				mAllSelected = true;
				Drawable noChoose = getResources().getDrawable(
						R.drawable.art_icon_all_reverse_choose_nor);
				if (noChoose != null)
					mMultiSelect.setImageDrawable(noChoose);
			} else {
				mAllSelected = false;
				Drawable multichoose = getResources().getDrawable(
						R.drawable.art_check_all_nor);
				if (multichoose != null)
					mMultiSelect.setImageDrawable(multichoose);
			}
			
		}
    	
    }
    
	private View.OnClickListener mSelectListener = new View.OnClickListener() {

		public void onClick(View arg0) {
			if (mChannelHolder.getCount() > 0 ){
				if (!mAllSelected) {
					mAllSelected = true;
				} else {
					mAllSelected = false;
				}
				if (mAllSelected) {
					checkAll();
				} else {
					uncheckAll();
				}
				mAdapter.notifyDataSetChanged();
			}
		}

	};
	
	
	public void uncheckAll() {
		int count = mChannelHolder.getCount();
		for (int i = 0; i < count; i++) {
			mListView.setItemChecked(i, false);
		}
	}

	public void checkAll() {
		int count = mChannelHolder.getCount();
		for (int i = 0; i < count; i++) {
			mListView.setItemChecked(i, true);
		}
	}

	private boolean deleteChannelItem(ActionMode mode) {
		int count = mAdapter.getCount();
		int listCount = mChannelHolder.getStationList().size();
		for(int i = 0 ; i < listCount; i++ ){
			Station sta = mChannelHolder.getStationList().get(i);
		}
		if (count > 0) {
			if (mListView.getChoiceMode() == ListView.CHOICE_MODE_NONE) {
				return false;
			}
			preparedItemToBeDeleted();
			mAdapter.notifyDataSetChanged();
			mode.finish();
			return true;
		}
		return false;
	}
	
	
	private void preparedItemToBeDeleted(){
		ArrayList<Station> deleteList = new ArrayList<Station>();
		for(int i = 0 ; i < mChannelHolder.getCount();i++){
			if (mListView.isItemChecked(i)){
				Station sta = mChannelHolder.getItem(i);
				deleteList.add(sta);
			}
		}
		 for (Station sta : deleteList){
			 mChannelHolder.delete(sta);
	        }
	}
    private void scanAllChannel(){
		if ((mScanDialog != null && mScanDialog.isShowing())
				|| (cancelScanDialog != null && cancelScanDialog.isShowing())) {
			return;
		}
		AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
		boolean isHeadsetOn = am.isWiredHeadsetOn();
		LogUtils.d(TAG,"scanAllChannel isHeadsetOn " + isHeadsetOn);
		if (!isHeadsetOn)
			return;
		if (FMRadioActivity.isAirplaneMode(getApplicationContext())) {
			return;
		} 
		LogUtils.d(TAG,"scanAllChannel  ");
		if (mChannelHolder.getIsCancel()) {
			mChannelHolder.setIsCancel(false);
		}
		mListView.setEnabled(false);
		mChannelHolder.deleteAll();
		mAdapter.notifyDataSetChanged();
		scanAll();
    }
    private void scanAll() {
        mScanDialog = new ProgressDialog(this);
//        mScanDialog.setTitle(R.string.scan_title);
//        mScanDialog.setButton(AllActivity.this.getString(R.string.cancel_scan), mScanDialogClickListener);
        mScanDialog.setMessage(AllActivity.this.getString(R.string.scan_info));
        mScanDialog.setCancelable(true);
        mScanDialog.setOnCancelListener(mScanDialogClickListener);
        mScanDialog.show();
        Intent intent = new Intent(AllActivity.this, FMService.class);
        intent.setAction(Constants.START_SCAN_ALL);
        this.startService(intent);
    }

    private void createCancelScanDialog(){
        cancelScanDialog = new ProgressDialog(AllActivity.this);
        cancelScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        cancelScanDialog.setTitle(R.string.stop_scan_success);
        cancelScanDialog.setMessage(AllActivity.this.getString(R.string.cancel_scanning));
        cancelScanDialog.setCancelable(false);
        cancelScanDialog.show();
    }
        
    private DialogInterface.OnCancelListener mScanDialogClickListener = new DialogInterface.OnCancelListener() {
		@Override
		public void onCancel(DialogInterface dialog) {
			createCancelScanDialog();
            Intent intent = new Intent(AllActivity.this, FMService.class);
            intent.setAction(Constants.STOP_SCAN);
            AllActivity.this.startService(intent);
            mChannelHolder.setIsCancel(true);
            Message result = Message.obtain(mHandler,EVENT_CANCEL_SCAN);
			mHandler.sendMessageDelayed(result, 5000);
		}
    };
    
	private void noHeadsetDisableFM() {
		if (null == mChannelHolder) {
			mChannelHolder = ChannelHolder.getInstance();
		}
		if (FMService.sFmRadio.rxGetFMState() == FmRadio.STATE_ENABLED){
			Intent intent = new Intent(this, FMService.class);
			intent.setAction(Constants.DISABLE_FM);
			this.startService(intent);
			if (mChannelHolder.getSpeakerOn()) {
				setFmSpeaker(false);
			}
		} else {
			mChannelHolder.setIsAudioFocus(false);
			FMService.getHandler().sendMessage(Message.obtain(FMService.getHandler(), Constants.MSG_FINISH_ACTIVITY));
			Intent intent = new Intent(this, FMService.class);
			this.stopService(intent);
			mChannelHolder.flush();
		}
//	     finish();
	     Message result = Message.obtain(mHandler,EVENT_DISABLE_FM);
		 mHandler.sendMessageDelayed(result, 2000);
	    LogUtils.d(TAG,"ChannelListActivity noHeadsetDisableFM...");
	}
	
	private void setFmSpeaker(boolean status) {
		try {
			LogUtils.d(TAG, "setFmSpeaker: " + status);
			AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
			Method setSpeakerfmOn = am.getClass().getMethod("setSpeakerfmOn",
					boolean.class);
			setSpeakerfmOn.invoke(am, status);
		} catch (Exception e) {
			LogUtils.d(TAG, "Exception e: " + e);
		}
	}
}
