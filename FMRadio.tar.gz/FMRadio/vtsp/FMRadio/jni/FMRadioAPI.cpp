#include "jni.h"

#define LOG_TAG "NativeFM"
//#include <cutils/properties.h>
#include <stdlib.h>
#include "mylog.h"
#include "radioManager.h"

using namespace yuanTe;
static const char *classPathName = "com/borqs/fmradio/service/FMNative";
static JavaVM *g_jVM = NULL;
static RadioManagerC *rManager = NULL;
 
static jint native_fm_init(JNIEnv *env, jclass clazz)
{
	log("native_fm_init");
        rManager = new RadioManagerC();
	return (jint)3;
}

static jint native_fm_deinit(JNIEnv *env, jclass clazz)
{
	log("native_fm_deinit");
        if(rManager)
            delete rManager;
	return (jint)3;
}

static jint native_fm_open(JNIEnv *env, jclass clazz)
{
	int  ret = -1;
	log("native_fm_open");
	if(rManager){
		ret = rManager->init();
	}
	return (jint)ret;
}
static jint native_fm_close(JNIEnv *env, jclass clazz)
{
	int ret = -1;
	log("native_fm_close");
	if(rManager){
		ret = rManager->closeRadio();
	}
	return (jint)ret;
}
static jint native_fm_adjustvolume(JNIEnv *env, jclass clazz, jint jvulume, jint jmode)
{
	log("native_fm_adjustvolume");
	return (jint)3;
}
static jint native_fm_getvolume(JNIEnv *env, jclass clazz)
{
        log("native_fm_getvolume");
        return (jint)3;
}
static jint native_fm_changeChannel(JNIEnv *env, jclass clazz, jint jchannel)
{
        log("native_fm_changeChannel channel %d", jchannel);
	int  ret = -1;
        if(rManager){
            ret = rManager->changeChannel(jchannel);
         log("native_fm_changeChannel channel return %d", ret);
        }
        return (jint)ret;
}
static jint native_fm_beginSearch(JNIEnv *env, jclass clazz, jint jchannel)
{
        log("native_fm_beginSearch");
        return (jint)3;
}
static jint native_fm_stopSearch(JNIEnv *env, jclass clazz)
{
        log("native_fm_stopSearch");
        return (jint)3;
}
static jint native_fm_seek(JNIEnv *env, jclass clazz, jint jdirection)
{
        log("native_fm_seek %d",jdirection);
        jint result = -1;
        if(rManager){
        	result = rManager->seek(jdirection);
        }
        return (jint)result;
}
static void native_fm_setmode(JNIEnv *env, jclass clazz, jint mode)
{
	log("native_fm_setmode %d",mode);
	if(rManager){
		rManager->setRadioMode(mode);
	}
	return ;
}
static jint native_fm_getmode(JNIEnv *env, jclass clazz)
{
	jint result = -1;
	if(rManager){
		result = rManager->getRadioMode();
	}
	log("native_fm_getmode %d",result);
	return result;
}
static jintArray native_fm_autoSeekChannel(JNIEnv *env, jclass clazz)
{
    log("native_fm_autoSeekChannle()");
    jintArray ret = (env)->NewIntArray(16);
	if(rManager){
		jint* channels = rManager->autoSeekChannel();
		(env)->SetIntArrayRegion(ret,0,16,channels);
	}
	return ret;
}
static JNINativeMethod sMethods_table[] = {
      {"fm_init", 						"()I", 	(void *)native_fm_init},
      {"fm_deinit", 					"()I", 	(void *)native_fm_deinit},
      {"fm_open", 						"()I", 	(void *)native_fm_open},
      {"fm_close", 						"()I", 	(void *)native_fm_close},
      {"fm_adjustvolume", 				"(II)I",(void *)native_fm_adjustvolume},
      {"fm_getvolume", 					"()I", 	(void *)native_fm_getvolume},
      {"fm_changeChannel", 				"(I)I", (void *)native_fm_changeChannel},
      {"fm_beginSearch", 				"(I)I", (void *)native_fm_beginSearch},
      {"fm_stopSearch", 				"()I", 	(void *)native_fm_stopSearch},
      {"fm_seek", 						"(I)I", 	(void *)native_fm_seek},
      {"fm_setmode", 					"(I)V", 	(void *)native_fm_setmode},
      {"fm_getmode", 					"()I", 	(void *)native_fm_getmode},
      {"fm_autoSeekChannel",                     "()[I", (void *)native_fm_autoSeekChannel},
};
/*
 * Register several native methods for one class.
 */
static int registerNatives(JNIEnv* env, const char* className,
			   JNINativeMethod* gMethods, int numMethods)
{
	jclass clazz;

	clazz = env->FindClass(className);
	if (clazz == NULL) {
		 LOGE("Can not find class %s\n", className);
		return JNI_FALSE;
	}

	if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
		LOGE("Can not RegisterNatives\n");
		return JNI_FALSE;
	}

	return JNI_TRUE;
}
jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
	JNIEnv* env = NULL;
	jint result = -1;

	log("OnLoad");

	if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) {
		goto bail;
	}
	if (!registerNatives(env,
			     classPathName,
	                     sMethods_table,
			     sizeof(sMethods_table)/sizeof(sMethods_table[0]))) {
		goto bail;
	}
        env->GetJavaVM(&g_jVM);

	/* success -- return valid version number */
	result = JNI_VERSION_1_4;

bail:
	return result;
}
void JNI_OnUnload(JavaVM* vm, void* reserved)
{
	log("[JNI_OnUnload]");

}
