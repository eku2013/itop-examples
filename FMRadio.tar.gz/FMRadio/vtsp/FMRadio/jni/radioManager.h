#ifndef RADIO_MANAGER_H_20100826
#define RADIO_MANAGER_H_20100826

#include "radioDefines.h"
namespace yuanTe
{
class AbstractRadio;
typedef enum _RADIO_TYPE_
{
    RADIO_SI4754_OLD,
    RADIO_SI4754
}Radio_Type;

class RadioManagerC
{
public:
	RadioManagerC();
	~RadioManagerC();

public:
	int openRadio(int frequencySection,int channel,int volume);
	int init();
	int closeRadio();

	int adjustVolume(int volume,int mode);
	int getVolume();

	int changeChannel(int channel);

	int beginSearch(int channel);
	int stopSearch();
    int getVersion(int size,char* buf);
    
    int getRadioMode();
    void setRadioMode(int mode);
    /*
    // seekup:  0 = seek down
    //          1 = seek up
    */
    int seek(int direction);
    int* autoSeekChannel();
private:
    AbstractRadio * radioFactory(Radio_Type  radioType);
    AbstractRadio * m_radio;
};

}

#endif

