#ifndef ABSTRACTRADIO_H
#define ABSTRACTRADIO_H
namespace yuanTe
{

class AbstractRadio
{
public:
    virtual ~AbstractRadio(){};
    virtual  int openRadio(int /*frequencySection*/,int /*channel*/,int /*volume*/){return -1;}
    virtual int closeRadio(){return -1;}
    virtual int init(){return -1;}

    virtual int adjustVolume(int /*volume*/,int /*mode*/){return -1;}
    virtual int getVolume(){return -1;}

    virtual int changeChannel(int /*channel*/){return -1;}

    virtual int beginSearch(int /*channel*/){return -1;}
    virtual int stopSearch(){return -1;}
    virtual int getVersion(int /*size*/,char* /*buf*/){return -1;}
    virtual int getRadioMode(){return -1;}
    void setRadioMode(int /*mode*/){}
    /*
    // seekup:  0 = seek down
    //          1 = seek up
    */
    virtual int slotSearchChannel(unsigned char /*direction*/){return -1;}
    virtual int* autoSeekChannel(){int *arr;return arr;}
};
}

#endif // ABSTRACTRADIO_H
