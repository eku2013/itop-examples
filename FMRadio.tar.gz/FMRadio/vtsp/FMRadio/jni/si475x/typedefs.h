#ifndef TYPEDEFS_H
#define TYPEDEFS_H
#include "radioCommon.h"

#endif
