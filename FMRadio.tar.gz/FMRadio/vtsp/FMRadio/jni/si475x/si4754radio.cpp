#include "si4754radio.h"
#include "radioDefines.h"
#include "stdlib.h"
#include "mylog.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "si475xAMRX.h"
#include "si475xFMRX.h"
#include "radioCommon.h"
#include <unistd.h>

#ifdef __cplusplus
}
#endif
#define RADIO_CONFIG_FILE_PATHNAME		"/nand3/applicationdata/radio.ini"
#define AM_PATCH_FILE   "/nand3/applicationdata/fix_amrx_patch.csg"

using namespace  yuanTe;
si4754Radio::si4754Radio():m_radioMode(RM_FREQ_SECTION_NULL),
    m_currentFrequency(-1),
    m_isSearching(false),
    m_fmRssi(20),
    m_amRssi(20),
    m_fmSnr(3),
    m_amSnr(3),
    m_volumn(60)
{
	unsigned char * pPatch=NULL;
	setAMPatch(pPatch);
	//setAMPatchLine(line);
}
int si4754Radio::closeRadio()
{
    log("si4754Radio::closeRadio()");
    int result = 1;
    if((0 == closeFM()) && (0 == closeAM()))
    {
       result = 0;
       return result;
    }
    else
    {
       return result;
    }
}

int si4754Radio::changeChannel(int channel)
{
    if(isFM(channel))//FM的台
    {
    	log("changeChannel  m_radioMode = %d", m_radioMode);
        if(m_radioMode == RM_FREQ_SECTION_AM)//当前是AM模式
        {
            closeAM();//关闭AM才能初始化FM
            InitFM();
        }
        else if(m_radioMode== RM_FREQ_SECTION_NULL)//当前没有设置模式
        {
            closeAM();//关闭AM才能初始化FM
            InitFM();
        }
        m_radioMode = RM_FREQ_SECTION_FM;
        changeFM(channel);

    }
    else if(isAM(channel))//AM的台
    {
        if(m_radioMode == RM_FREQ_SECTION_FM)//当前是FM模式
        {
            closeFM();//关闭FM才能初始化AM
            InitAM();
        }
        else if(m_radioMode == RM_FREQ_SECTION_NULL)//当前没有设置模式
        {
            closeFM();//关闭FM才能初始化AM
            InitAM();
        }
        m_radioMode = RM_FREQ_SECTION_AM;
        changeAM(channel);

    }
    log("changeChannel  end");
    return 1;
}
int si4754Radio::init()
{
	if(m_radioMode == RM_FREQ_SECTION_AM)//当前是AM模式
	{
		InitAM();
	}
	else
	{
		InitFM();
	}
	return 1;
}
int si4754Radio::beginSearch(int channel)
{
    int res = -1;
    if(isFM(channel))//FM的台
    {
        if(m_radioMode != RM_FREQ_SECTION_FM)
        {
            return -1;
        }
        m_isSearching = true;
       // mute();
        changeFM(channel);
        res =0;
    }
    else
    {
        if(m_radioMode != RM_FREQ_SECTION_AM)
        {
            return -1;
        }
        m_isSearching = true;
        //mute();
        changeAM(channel);
        res =0;
    }
    return res;

}

int si4754Radio::stopSearch(void)
{
   m_isSearching = false;
   return 0;
}
int si4754Radio::getVersion(int size,char* buf)
{
    int res = -1;
   res = si475x_getPartInformation(size,buf);
    return res;
}
int si4754Radio::getRadioMode(){
    return m_radioMode;
}
void si4754Radio::setRadioMode(int mode){
    m_radioMode = mode;
}
int si4754Radio::slotSearchChannel(u8 direction)
{
    int res = -1;
    int channel = 0;

    log("slotSearchChannel  m_radioMode ",m_radioMode);
        if(m_radioMode == RM_FREQ_SECTION_FM)
        {
        	log("slotSearchChannel  RM_FREQ_SECTION_FM");
            res =  seekFM(direction);
            log("slotSearchChannel  seek result %d",res);
            if(!res)//为0表示收到台
            {
            	log("si475xFMRX_get_frequency");
                channel = si475xFMRX_get_frequency();
                log("si475xFMRX_get_frequency result %d",channel);
                if(isFM(channel*10))//在FM范围内,超范围的台丢弃
                {
                    //QTimer::singleShot(100,this,SLOT(slotSearchChannel()));
                }
                else
                {
                }
            }
            else//收不到台表示收台完成
            {
            }
        }
        else
        {
            res =  seekAM(direction);
            if(!res)//为0表示收到台
            {
                channel = si475xAMRX_get_frequency();
                if(isAM(channel))//在AM范围内,超范围的台丢弃
                {
                    //QTimer::singleShot(100,this,SLOT(slotSearchChannel()));
                }
                else
                {
                }
            }
            else//收不到台表示收台完成
            {
            }
        }

    return channel;
}

void si4754Radio::InitFM(void)
{
   setFmSnrRssi((u16)m_fmRssi,(u16)m_fmSnr);
   si475xFMRX_initialize();
   // wait for 600ms to avoid plosive
   usleep(600* 1000);
   si475xFMRX_set_volume(m_volumn);
   log("initFM  volume = %d ",m_volumn);
}
void si4754Radio::InitAM(void)
{
    setAmSnrRssi((u16)m_amRssi,(u16)m_amSnr);
    si475xAMRX_initialize();
    // wait for 600ms to avoid plosive
    usleep(600* 1000);
    si475xAMRX_set_volume(m_volumn);
    log("initAM  volume = %d ",m_volumn);

}
int si4754Radio::closeFM(void)
{
    log("close FM !");
    si475xFMRX_set_volume(0);
    si475xFMRX_mute(1);
    si475xFMRX_cancelAutoseek();
    si475xFMRX_fmCancelSeekOrTune();
    int result = si475xFMRX_powerdown();
    return result;
}

int si4754Radio::closeAM(void)
{
	log("close AM !");
    si475xAMRX_set_volume(0);
    si475xAMRX_mute(1);
    si475xAMRX_cancelAutoseek();
    si475xAMRX_amCancelSeekOrTune();
    int result = si475xAMRX_powerdown();
    return result;
}

void si4754Radio::changeFM(int channel)
{
    si475xFMRX_tune(0,(u16)((channel/10)&0xffff));
}

void si4754Radio::changeAM(int channel)
{
    si475xAMRX_tune((u16)(channel&0xffff));
}

int si4754Radio::seekFM(u8 direction)
{
    return si475xFMRX_seek(direction,1);// seek up, 0 = stop at band limits

}

int si4754Radio::seekAM(u8 direction)
{
    return si475xAMRX_seek(direction,1);// seek up, 0 = wrap at band limits
}

void si4754Radio::mute(void)
{
    if(m_radioMode == RM_FREQ_SECTION_FM)
    {
        si475xFMRX_mute(1);
    }
    else if(m_radioMode == RM_FREQ_SECTION_AM)
    {
        si475xAMRX_mute(1);
    }
}

void si4754Radio::unMute(void)
{
    if(m_radioMode == RM_FREQ_SECTION_FM)
    {
        si475xFMRX_mute(0);
    }
    else if(m_radioMode == RM_FREQ_SECTION_AM)
    {
        si475xAMRX_mute(0);
    }
}

bool si4754Radio::isFM(int channel)
{
    if(channel>= RM_FM_FREQ_MIN && channel <= RM_FM_FREQ_MAX)
        return true;
    return false;
}

bool si4754Radio::isAM(int channel)
{
    if(channel>= RM_AM_FREQ_MIN && channel <= RM_AM_FREQ_MAX)
        return true;
    return false;

}

int* si4754Radio::autoSeekChannel(void)
{
	int *arr;
	if(m_radioMode == RM_FREQ_SECTION_FM){
		arr = si475xFMRX_autoseek();
	    return arr;
	}else if(m_radioMode == RM_FREQ_SECTION_AM){
		arr = si475xAMRX_autoseek();
		return arr;
	}
	return arr;
}
