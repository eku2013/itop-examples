#ifndef SI4754RADIO_H
#define SI4754RADIO_H
#include "abstractRadio.h"
#include "radioCommon.h"
 namespace  yuanTe{
class si4754Radio:public AbstractRadio
{

public:
    si4754Radio();
    int closeRadio();
    int changeChannel(int /*channel*/);
    int beginSearch(int /*channel*/);
    int stopSearch();
    int getVersion(int size,char* buf);
    void setRadioMode(int mode);
    int getRadioMode();
    int slotSearchChannel(u8 direction);
    int init();
    int* autoSeekChannel();
    void mute(void);
    void unMute(void);
private:
    void InitFM(void);
    void InitAM(void);
    int closeFM(void);
    int closeAM(void);
    void changeFM(int channel);
    void changeAM(int channel);
    int seekFM(u8 direction);
    int seekAM(u8 direction);
    bool isFM(int channel);
    bool isAM(int channel);
    int m_radioMode;//AM/FM模式 或者初始化模式
    int m_currentFrequency;//当前模式
    bool m_isSearching;//是否正在搜索
    int m_fmRssi;//FM信号质量
    int m_amRssi;//am信号质量
    int m_fmSnr;//FM信噪比
    int m_amSnr;//am信噪比
    int m_volumn;//FM/AM音量

};
 }
#endif // SI4754RADIO_H
