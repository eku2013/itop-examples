#include "radioManager.h"
#include "abstractRadio.h"

#include "si475x/si4754radio.h"
#include "mylog.h"
using namespace yuanTe;

RadioManagerC::RadioManagerC()
{
    m_radio=0;
    m_radio = radioFactory(RADIO_SI4754);
}
RadioManagerC::~RadioManagerC()
{
    if(m_radio)
    {
        delete m_radio;
        m_radio = 0;
    }
}

int RadioManagerC::openRadio(int frequencySection,int channel,int volumeArg)
{
    if(m_radio)
        return m_radio->openRadio(frequencySection,channel,volumeArg);
    else
        return -1;
}
int RadioManagerC::init()
{
    if(m_radio)
        return m_radio->init();
    else
        return -1;
}
int RadioManagerC::closeRadio()
{
    log("RadioManagerC::closeRadio()");
    if(m_radio)
        return m_radio->closeRadio();
    else
        return -1;
}


int RadioManagerC::adjustVolume(int volumeArg,int mode)
{
    if(m_radio)
        return m_radio->adjustVolume(volumeArg,mode);
    else
        return -1;
}

int RadioManagerC::getVolume()
{
    if(m_radio)
        return m_radio->getVolume();
    else
        return -1;

}


int RadioManagerC::changeChannel(int channel)
{
    log("RadioManagerC::changeChannel %d", channel);
    if(m_radio)
        return m_radio->changeChannel(channel);
    else
        return -1;
}


int RadioManagerC::beginSearch(int channel)
{
    if(m_radio)
        return m_radio->beginSearch(channel);
    else
        return -1;
}

int RadioManagerC::stopSearch()
{
    if(m_radio)
        return m_radio->stopSearch();
    else
        return -1;

}
int RadioManagerC::getVersion(int size,char* buf)
{
    if(m_radio)
    {
        return m_radio->getVersion(size,buf);
    }
    return -1;
}
int RadioManagerC::getRadioMode(){
    if(m_radio)
    {
        return m_radio->getRadioMode();
    }
    return -1;
}
void RadioManagerC::setRadioMode(int mode){
    if(m_radio)
    {
        return m_radio->setRadioMode(mode);
    }
}
int RadioManagerC::seek(int direction){
    int freq = 0;
    log("RadioManagerC::seek direction %d",direction);
    if(m_radio){
    log("RadioManagerC::seek slotSearchChannel ");
        freq = m_radio->slotSearchChannel((u8)direction);
    }
    log("RadioManagerC::seek %d", freq);
    return freq;
}
int* RadioManagerC::autoSeekChannel(){
	int *arr;
	if(m_radio){
	   arr = m_radio->autoSeekChannel();
       return arr;
	}
	return arr;
}
AbstractRadio* RadioManagerC::radioFactory(Radio_Type  radioType)
{
    AbstractRadio * pRadio =0;
    switch(radioType)
    {
        case RADIO_SI4754_OLD:
            break;
        case RADIO_SI4754:
             pRadio = new si4754Radio;
            break;
        default:
            break;
    }
    return pRadio;
}
