#include "radioCommon.h"
#ifdef __cplusplus
extern "C" {
#endif
#include <unistd.h>

void wait_ms(u16 ms)
{
    usleep(ms*1000);
}


void wait_us(u16 us)
{
    usleep(us);
}

#ifdef __cplusplus
}
#endif
