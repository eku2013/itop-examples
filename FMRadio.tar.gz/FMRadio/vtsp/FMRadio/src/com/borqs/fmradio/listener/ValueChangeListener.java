package com.borqs.fmradio.listener;

public interface ValueChangeListener {
	void setValue(float value);
}
