package com.borqs.fmradio.utils;

public class FMConstants {
    public static final int FREQ_FM_MIN = 87000;
    public static final int FREQ_FM_MAX = 108000;

    public static final int FREQ_AM_MIN = 531;
    public static final int FREQ_AM_MAX = 1629;

    public static final int SEEK_DOWN = 0;
    public static final int SEEK_UP = 1;
    public static final int RM_FREQ_SECTION_FM = 0;
    public static final int RM_FREQ_SECTION_AM = 1;


    //Handler message
    public static final int MSG_FM_STATUS = 0;
    public static final int MSG_ENABLE_SUCCESSFUL = 1;
    public static final int MSG_DISABLE_SUCCESSFUL = 11;
    public static final int MSG_ENABLE_FAILED = 2;
    public static final int MSG_LEFT_SEEK_COMPLETE = 3;
    public static final int MSG_RIGHT_SEEK_COMPLETE = 4;
    public static final int MSG_SCAN_DONE = 5;
    public static final int MSG_SET_CHANNEL_DONE = 10;
    public static final int MSG_UPDATE_CHANNEL = 6;
    public static final int MSG_FM_ONRESUME = 7;
    public static final int MSG_FM_ONSTOP = 8;
    public static final int MSG_FM_EXIT = 9;

    //service command
    public static final int CMD_INIT = 101;
    public static final int CMD_ENABLE = 102;
    public static final int CMD_CLOSE = 103;
    public static final int CMD_SET_VOLUME = 104;
    public static final int CMD_GET_VOLUME = 105;
    public static final int CMD_SET_CHANNEL = 106;
    public static final int CMD_START_SCAN = 107;
    public static final int CMD_STOP_SCAN = 108;
    public static final int CMD_NEXT = 109;
    public static final int CMD_PREV = 110;
    public static final int CMD_SCAN = 111;
    public static final int CMD_SET_MUTE = 112;

    public static final int   MODE_FM_OFF           = 0;
    public static final int   MODE_FM_ON            = 1;

    public static final int AUDIO_STATUS_OK = 0;
    public static final int AUDIO_STATUS_ERROR = 1;

    public static final String KEYCODE_KEY_PLUG_OUT_EVENT = "com.borqs.civia.carkey_plug_out";
    public static final String KEYCODE_ACC_ON_EVENT = "com.borqs.civia.acc_on";
    public static final String KEYCODE_MENU_TURN_LEFT = "com.borqs.civia.menu.turn_left";
    public static final String KEYCODE_MENU_TURN_RIGHT = "com.borqs.civia.menu.turn_right";
    public static final String KEYCODE_LONGCLICK_LEFT_MENU = "com.borqs.civia.longclick.left_menu";
    public static final String KEYCODE_AUX_INSERT = "com.borqs.civia.aux.insert";
    public static final String KEYCODE_AUX_PLUG_OUT = "com.borqs.civia.aux.plug_out";

    public static final String FM_MUSIC_COMMUNICATION_SET_CHANNEL = "com.borqs.civia.fmradio.set_channel";
    public static final String FM_MUSIC_COMMUNICATION_NEXT_CHANNEL = "com.borqs.civia.fmradio.next_channel";
    public static final String FM_MUSIC_COMMUNICATION_PREV_CHANNEL = "com.borqs.civia.fmradio.prev_channel";
    public static final String FM_MUSIC_COMMUNICATION_DISABLE_FM = "com.borqs.civia.fmradio.disable_fm";
    public static final String FM_MUSIC_COMMUNICATION_ENABLE_FM = "com.borqs.civia.fmradio.enable_fm";
    public static final String DISABLE_MSG_FROM_WIGET = "disable_msg_from_widget";
    public static final String DISABLE_MSG_FROM_FM = "disable_msg_from_fm";

    public static final int FM_NOTIFICATION_ID = 777;

    public static final int FM_RECIVED_BRODCASET_PRIORITY = 10000;

    public static final int POWERING_ON_FM_NOTICE = 0;
    public static final int SCANNING_NOTICE = 1;
}
