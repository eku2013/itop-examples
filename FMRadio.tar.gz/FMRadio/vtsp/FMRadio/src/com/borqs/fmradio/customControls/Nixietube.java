package com.borqs.fmradio.customControls;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;

import com.borqs.fmradio.R;
import com.borqs.fmradio.listener.SwitchModeListener;
import com.borqs.fmradio.listener.ValueChangeListener;
import com.borqs.fmradio.utils.FmUtils;

public class Nixietube extends View implements SwitchModeListener, ValueChangeListener {

    Bitmap[] mNumMaps;
    Bitmap zeroXInvMap;
    Bitmap dotMap;
    boolean isShowDot = true;
    float mData = 0;
    private Context context;
    int[] mNumXFMPoses = {0, 40, 80, 130};
    int[] mNumXAMPoses = {0, 45, 90, 130};

    int mDotPos = 105;

    private ArrayList<Bitmap> bitMapList= new ArrayList<Bitmap>();

    public Nixietube(Context context) {
        super(context);
    }

    public Nixietube(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Nixietube(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.context = context;
        initBitmapArray();
    }
    
    public void setValue(float data) {
        if (isShowDot){
            if(data < 87.5f || data > 108f) {
                return;
            }
        } else {
            if (data < 531f || data > 1629f) {
                return;
            }
        }
        mData = FmUtils.tidyFreq(data);
        this.invalidate();
    }

    private void initBitmapArray() {
        log("initBitmapArray()");
        SharedPreferences sp = context.getSharedPreferences("FMRadio_config_file", Context.MODE_PRIVATE);
        isShowDot = sp.getBoolean("isFM", true);
        mNumMaps = new Bitmap[12];
        try {
            for (int i=0; i<=9; i++) {
                getNumberBitmap(i);
                bitMapList.add(mNumMaps[i]);
            }

            zeroXInvMap = ((BitmapDrawable)context.getResources()
                    .getDrawable(R.drawable.fm_number_0_x)).getBitmap();
            bitMapList.add(zeroXInvMap);
            dotMap = ((BitmapDrawable)context.getResources().getDrawable(R.drawable.fm_number_dot))
                    .getBitmap();
            bitMapList.add(dotMap);
        } catch (OutOfMemoryError e) {
            FmUtils.log("Nixietube", "OutOfMemoryError:" + e.toString());
        }
    }

    private void getNumberBitmap(int i) {
        int resID = getResources().getIdentifier("fm_number_" + i, "drawable", "com.borqs.fmradio");
        mNumMaps[i] = ((BitmapDrawable)context.getResources().getDrawable(resID)).getBitmap();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        log("onDraw");
        int data = (int)mData ;
        int value = 0;

        Paint paint = new Paint();
        paint.setAntiAlias(true);

        // draw dot
        if (isShowDot) {
            data = (int)(mData * 10);
            if (dotMap.isRecycled()) {
                dotMap = ((BitmapDrawable)context.getResources()
                        .getDrawable(R.drawable.fm_number_dot))
                        .getBitmap();
            }
            canvas.drawBitmap(dotMap, mDotPos, 0, paint);

            value = data / 1000;
            if (0 == value) {
                if (zeroXInvMap.isRecycled()) {
                    zeroXInvMap = ((BitmapDrawable)context.getResources()
                            .getDrawable(R.drawable.fm_number_0_x)).getBitmap();
                }
                canvas.drawBitmap(zeroXInvMap, mNumXFMPoses[0], 0, paint);
            } else {
                if (mNumMaps[value].isRecycled()) {
                    getNumberBitmap(value);
                }
                canvas.drawBitmap(mNumMaps[value], mNumXFMPoses[0], 0, paint);
            }
            data %= 1000;

            for (int i=1, divisor=100; i<4; i++, divisor/=10) {
                value = data / divisor;
                if (mNumMaps[value].isRecycled()) {
                    getNumberBitmap(value);
                }
                canvas.drawBitmap(mNumMaps[value], mNumXFMPoses[i], 0, paint);
                data %= divisor;
            }
        } else{
            value = data / 1000;
            if (0 == value) {
                if (zeroXInvMap.isRecycled()) {
                    zeroXInvMap = ((BitmapDrawable)context.getResources()
                            .getDrawable(R.drawable.fm_number_0_x)).getBitmap();
                }
                canvas.drawBitmap(zeroXInvMap, mNumXAMPoses[0], 0, paint);
            } else {
                if (mNumMaps[value].isRecycled()) {
                    getNumberBitmap(value);
                }
                canvas.drawBitmap(mNumMaps[value], mNumXAMPoses[0], 0, paint);
            }
            data %= 1000;
            for (int i=1, divisor=100; i<4; i++, divisor/=10) {
                value = data / divisor;
                if (mNumMaps[value].isRecycled()) {
                    getNumberBitmap(value);
                }
                canvas.drawBitmap(mNumMaps[value], mNumXAMPoses[i], 0, paint);
                data %= divisor;
            }

        }

    }

    private static void log(String msg) {
        FmUtils.log("Nixietube",  msg);
    }

    @Override
    public void onChanged(boolean value) {
        log("onChanged  " + value);
        isShowDot = value;
        this.invalidate();
    }

    public void releaseAllBitmapResource() {
        FmUtils.log("Nixietube", "releaseAllBitmapResource()");

        if( null != bitMapList && bitMapList.size() > 0) {
            for(Bitmap bitmap : bitMapList) {
                if (null != bitmap) {
                    try{
                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                        }
                    } catch(Exception e) {
                        FmUtils.log("Nixietube", e.toString());
                    }
                    bitmap = null;
                }
            }
            System.gc();
        }
        bitMapList.clear();
    }
}
