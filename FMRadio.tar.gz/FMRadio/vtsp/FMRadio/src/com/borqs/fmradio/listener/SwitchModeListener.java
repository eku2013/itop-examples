package com.borqs.fmradio.listener;

public interface SwitchModeListener {

	/*
	 * value = true ----FM
	 * value = false----AM
	 * */
	void onChanged(boolean value);
}
