package com.borqs.fmradio.listener;

import com.borqs.fmradio.FmRadioActivity;
import com.borqs.fmradio.utils.FMConstants;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class FmMusicBroadCastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (FMConstants.FM_MUSIC_COMMUNICATION_ENABLE_FM.equals(action)) {
                Intent startActivityIntent = new Intent(context,FmRadioActivity.class);
                startActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(startActivityIntent);
        }
    }
}
