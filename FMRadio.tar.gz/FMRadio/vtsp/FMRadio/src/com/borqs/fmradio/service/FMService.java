package com.borqs.fmradio.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;

import com.borqs.fmradio.FmRadioActivity;
import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.FMConstants;
import com.borqs.fmradio.utils.FmUtils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

public class FMService extends Service {
    private static final String TAG = "FMService";
    private static Handler mActivityHandler;
    private Handler mHandler;
    private NotificationManager notificationManager;
    private boolean isFMEnabled = false;
    private boolean mResumeAfterCall = false;
    private boolean isFirstEnableFM = false;
    private boolean isRunningFMMode = false;
    private FmServiceBinder mBinder = null;
    private AudioManager am;
    private TelephonyManager tm;
    private HandlerThread ht;

    @Override
    public IBinder onBind(Intent intent) {
        FmUtils.log(TAG, "onBind");

        if (null == mBinder)
            mBinder = new FmServiceBinder();
        return mBinder;
    }

    public static void setActivityHandler(Handler handler) {
        if (null != handler) {
            mActivityHandler = handler;
        } else {
            mActivityHandler.removeCallbacksAndMessages(null);
            mActivityHandler = null;
        }
    }

    private PhoneStateListener mPhoneStateListener = new PhoneStateListener() {

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            int result = 1;
            if (state == TelephonyManager.CALL_STATE_RINGING) {
                if (!isFMEnabled) {
                    return;
                }
                FmUtils.log(TAG,"onCallStateChanged:CALL_STATE_RINGING Mute FM Radio");
                if (FMConstants.MODE_FM_ON == FmUtils.getFmRxMode(am)) {
                    result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_OFF);
                    if (0 != result) {
                        FmUtils.log(TAG,"CALL_STATE_RINGING Mute FM Radio failed! result="+result);
                    }
                }
                mResumeAfterCall = true;
            } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                if (!isFMEnabled) {
                    return;
                }
                FmUtils.log(TAG,"onCallStateChanged:CALL_STATE_OFFHOOK Mute FM Radio");
                if (FMConstants.MODE_FM_ON == FmUtils.getFmRxMode(am)) {
                    result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_OFF);
                    if (0 != result) {
                        FmUtils.log(TAG,"CALL_STATE_OFFHOOK Mute FM Radio failed! result="+result);
                    }
                }
                mResumeAfterCall = true;
            } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                if(tm.getCallState() != TelephonyManager.CALL_STATE_IDLE) {
                    return;
                }
                FmUtils.log(TAG, "onCallStateChanged:CALL_STATE_IDLE unMute FM Radio");
                SystemClock.sleep(500);
                if (FMConstants.MODE_FM_OFF == FmUtils.getFmRxMode(am)
                        && mResumeAfterCall) {
                    result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_ON);
                    if (0 != result) {
                        FmUtils.log(TAG,"CALL_STATE_IDLE unMute FM Radio failed! result="+result);
                    }
                }
                mResumeAfterCall = false;
            }
        }
    };

    private OnAudioFocusChangeListener mAudioFocusListener = new OnAudioFocusChangeListener() {

        @Override
        public void onAudioFocusChange(int focusChange) {
                int result = 1;
                FmUtils.log(TAG,"AUDIOFOCUS Event is "+focusChange);
                switch (focusChange) {
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                        if (!isFMEnabled) {
                            return;
                        }
                        //When play video, Exit FM
                        if (!mResumeAfterCall) {
                            am.abandonAudioFocus(mAudioFocusListener);
                            if ( null != mActivityHandler ) {
                                    Message msg = Message.obtain(mActivityHandler, FMConstants.MSG_FM_EXIT);
                                    msg.sendToTarget();
                            }
                        }
                        break;
                case AudioManager.AUDIOFOCUS_GAIN:
                        result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_ON);
                        if (0 != result) {
                                FmUtils.log(TAG, "Error Handling AUDIOFOCUS_GAIN: Cannot enable Audio HAL." +
                                                "result="+result);
                        }
                        break;
                case AudioManager.AUDIOFOCUS_LOSS:
                        if (!isFMEnabled) {
                            return;
                        }
                        //When play music, Exit FM
                        am.abandonAudioFocus(mAudioFocusListener);
                        if ( null != mActivityHandler ) {
                                Message msg = Message.obtain(mActivityHandler, FMConstants.MSG_FM_EXIT);
                                msg.sendToTarget();
                        }
                        break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                        result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_ON);
                        if (0 != result) {
                                FmUtils.log(TAG, "Error Handling AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:" +
                                                " Cannot enable Audio HAL.result="+result);
                        }
                        break;
                default:
                        FmUtils.log(TAG,"Got Unknown AudioFocus Event!!");
                        break;
                }
        }

};

    @Override
    public void onCreate() {
        super.onCreate();
        FmUtils.log(TAG, "onCreate()");
        isFirstEnableFM = true;

        ht = new HandlerThread("FmServiceHandler");
        ht.start();
        mHandler = new FmServiceHandler(ht.getLooper(), this);
        loadFMlib();
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int r = am.requestAudioFocus(mAudioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            FmUtils.log(TAG, "Got AudioFocus!");
        } else {
            FmUtils.log(TAG, "Cannot Get AudioFocus!");
        }
        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        tm.listen(mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        notificationManager = (NotificationManager)
                this.getSystemService(android.content.Context.NOTIFICATION_SERVICE);
    }

    @Override
    public void onDestroy() {
        FmUtils.log(TAG, "onDestroy()");
        notificationManager.cancel(FMConstants.FM_NOTIFICATION_ID);
        if (isFMEnabled) {
            FmUtils.log(TAG, "onDestroy() isFMEnabled:"+isFMEnabled);
            FmUtils.setFmRxMode(am, FMConstants.MODE_FM_OFF);
            FMNative.fm_close();
            FMNative.fm_deinit();
        }
        if (null != ht) {
            boolean isQuit = ht.quit();
            FmUtils.log(TAG, "isQuit="+isQuit);
            ht = null;
        }
        if (null != tm) {
            tm.listen(mPhoneStateListener, 0);
            tm = null;
        }
        if (null != am) {
            am.abandonAudioFocus(mAudioFocusListener);
            am = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        FmUtils.log(TAG, "onUnbind()");
        return super.onUnbind(intent);
    }

    static class FmServiceHandler extends Handler {

        private final WeakReference<Service> mService;

        FmServiceHandler(Looper l,Service service) {
            super(l);
            mService = new WeakReference<Service>(service);
        }

        public void handleMessage (Message msg) {
            FmUtils.log(TAG, "handleMessage");

            final FMService fmService = (FMService) mService.get();
            if (null == fmService) {
                return;
            }
            if (!fmService.isFirstEnableFM && !fmService.isFMEnabled) {
                FmUtils.log(TAG, "FMService cmd is disable,isFMEnabled="+fmService.isFMEnabled);
                return;
            }
            if (fmService.isFirstEnableFM) {
                fmService.isFirstEnableFM = false;
            }

            Bundle b = msg.getData();
            int cmd = b.getInt("cmd");
            FmUtils.log(TAG,"cmd is " + cmd);
            Message sendMsg;
            switch (cmd) {
            case FMConstants.CMD_ENABLE:
                boolean enable = b.getBoolean("enable");
                boolean isFm = b.getBoolean("isFM");
                fmService.isRunningFMMode = isFm;
                fmService.startFm(enable,isFm?FMConstants.RM_FREQ_SECTION_FM:FMConstants.RM_FREQ_SECTION_AM);
                break;
            case FMConstants.CMD_NEXT:
                int curFreq_next = 0;
                if (FMConstants.MODE_FM_ON == FmUtils.getFmRxMode(fmService.am)){
                    FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_OFF);
                }
                curFreq_next = FMNative.fm_seek(FMConstants.SEEK_UP);
                FmUtils.log(TAG,"CMD_NEXT_FREQ: " + curFreq_next);
                if ( null != mActivityHandler ) {
                    sendMsg = Message.obtain(mActivityHandler, FMConstants.MSG_RIGHT_SEEK_COMPLETE);
                    sendMsg.obj = curFreq_next;
                    sendMsg.sendToTarget();
                }
                break;
            case FMConstants.CMD_PREV:
                int curFreq_prev = 0;
                if (FMConstants.MODE_FM_ON == FmUtils.getFmRxMode(fmService.am)){
                    FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_OFF);
                }
                curFreq_prev= FMNative.fm_seek(FMConstants.SEEK_DOWN);
                FmUtils.log(TAG,"CMD_PREV_FREQ:" + curFreq_prev);
                if ( null != mActivityHandler ) {
                    sendMsg = Message.obtain(mActivityHandler, FMConstants.MSG_LEFT_SEEK_COMPLETE);
                    sendMsg.obj = curFreq_prev;
                    sendMsg.sendToTarget();
                }
                break;
            case FMConstants.CMD_SET_CHANNEL:
                int freq = b.getInt("freq");
                int result = -1;
                boolean isFm_setChannel = b.getBoolean("isFM");
                if (fmService.isRunningFMMode == !isFm_setChannel) {
                    if (null != fmService.am && FMConstants.MODE_FM_ON 
                            == FmUtils.getFmRxMode(fmService.am)){
                        result = FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_OFF);
                    }
                    fmService.isRunningFMMode = isFm_setChannel;
                }
                int feedback = FMNative.fm_changeChannel(freq);
                FmUtils.log(TAG,"CMD_SET_CHANNEL:" + freq + " feedback:"+feedback);
                if (null != fmService.am && (FMConstants.MODE_FM_OFF ==
                        FmUtils.getFmRxMode(fmService.am)) && (feedback == 1)){
                    result = FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_ON);
                }
                if ( null != mActivityHandler ) {
                    sendMsg = Message.obtain(mActivityHandler, FMConstants.MSG_SET_CHANNEL_DONE);
                    sendMsg.sendToTarget();
                }
                Intent intent = new Intent(FMConstants.FM_MUSIC_COMMUNICATION_SET_CHANNEL);
                if (isFm_setChannel) {
                    float fm_freq = ((float)freq)/1000;
                    intent.putExtra("set_channel", String.valueOf(fm_freq));
                } else {
                    int am_freq = freq;
                    intent.putExtra("set_channel", String.valueOf(am_freq));
                }
                intent.putExtra("isFM", isFm_setChannel);
                fmService.sendBroadcast(intent);
                break;
            case FMConstants.CMD_SCAN:
                boolean isInvalidChannels = false;
                int invalidFlag = 0;
                if (null != fmService.am && FMConstants.MODE_FM_ON 
                        == FmUtils.getFmRxMode(fmService.am)){
                    FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_OFF);
                }
                int[] data = FMNative.fm_autoSeekChannel();
                FmUtils.log(TAG,"scan channel result:data[].length=" + data.length);
                int[] channels = new int[15];
                for (int i = 1 ; i < data.length ; i++) {
                    channels[i-1] = data[i];
                    if (0 == channels[i-1]) {
                        invalidFlag++;
                    }
                }
                // If user cancel scan operation to lead returned channels are invalid,
                // we'll ignore them.
                if ((1 == data[0]) && (15 == invalidFlag)) {
                    isInvalidChannels = true;
                }
                if (!isInvalidChannels) {
                    if (null != fmService.am && FMConstants.MODE_FM_ON 
                            == FmUtils.getFmRxMode(fmService.am)){
                        FmUtils.setFmRxMode(fmService.am, FMConstants.MODE_FM_ON);
                    }
                    if ( null != mActivityHandler ) {
                        sendMsg = Message.obtain(mActivityHandler, FMConstants.MSG_SCAN_DONE);
                        sendMsg.obj = channels;
                        sendMsg.sendToTarget();
                    }
                }
                break;
            case FMConstants.MSG_FM_ONRESUME:
                fmService.notificationManager.cancel(FMConstants.FM_NOTIFICATION_ID);
                break;
            case FMConstants.MSG_FM_ONSTOP:
                boolean isFM = b.getBoolean("isFM");
                float currentFreq = b.getFloat("currentFreq");
                fmService.showNotification(isFM,currentFreq);
                break;
            default:
                FmUtils.log(TAG,"warning, unexpected command");
            }
        }
    }
    public class FmServiceBinder extends Binder {

        public void sendBundle(Bundle b) {

            Message msg = mHandler.obtainMessage();
            msg.setData(b);
            msg.sendToTarget();
        }

        public void clear() {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }
    }
    private boolean loadFMlib(){
        InputStream is = null;

        try {
                String filePath = null;
                File dir = getApplicationContext().getDir("lib", 0);
                File file = new File(dir, "libbqfm.so");
                try {
                        if (file.exists()) {
                            file.delete();
                        }
                        FmUtils.log(TAG, "loadFMlib copy libbqfm.so");
                        file.createNewFile();
                        is = getApplicationContext().getAssets().open("libbqfm.so");
                        boolean rt = copyToFile(is, file);
                        FmUtils.log(TAG, " copy loadFMlib.so, success=" + rt + "file " + file.toString());
                        filePath = file.toString();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (null != is) {
                        is.close();
                    }
                }

                FmUtils.log(TAG,"file " + filePath);
                if (!TextUtils.isEmpty(filePath))
                    System.load(filePath);
                return true;
        } catch (Exception e) {
             return false;
        }
    }

    public void startFm(boolean enable, int mode) {
        FmUtils.log(TAG,"startFm  " + enable + "  mode " + mode);
        if ((isFMEnabled && enable) || (!isFMEnabled && !enable)) {
            FmUtils.log(TAG, "startFm() failed!");
            return;
        }

        int fmRxMode_result = -1;
        if (enable){
            int init_result = FMNative.fm_init();
            FmUtils.log(TAG,"fm_init  result" + init_result);
            FMNative.fm_setmode(mode);
            int open_result = FMNative.fm_open();
            FmUtils.log(TAG,"fm_open  result" + open_result);
            if (1 == open_result) {
                if (null != mActivityHandler) {
                    FmUtils.log(TAG,"enable FMRadio successfully");
                    mActivityHandler.sendEmptyMessage(FMConstants.MSG_ENABLE_SUCCESSFUL);
                    isFMEnabled = true;
                }
            }
        } else {
            if (null != am) {
                fmRxMode_result = FmUtils.setFmRxMode(am, FMConstants.MODE_FM_OFF);
            }
            FmUtils.log(TAG,"setFmRxMode off result" + fmRxMode_result);
            int close_result = FMNative.fm_close();
            FmUtils.log(TAG,"fm_close  result" + close_result);
            if (0 == close_result && 0 == fmRxMode_result) {
                FmUtils.log(TAG,"disable FMRadio successfully");
                isFMEnabled = false;
                mActivityHandler.sendEmptyMessage(FMConstants.MSG_DISABLE_SUCCESSFUL);
            }
            FMNative.fm_deinit();
        }
    }

    public static boolean copyToFile(InputStream inputStream, File destFile) {
        boolean ret = false;
        try {
                Class<?> c = Class.forName("android.os.FileUtils");
                Method method = c.getMethod("copyToFile", InputStream.class, File.class);
                ret = (Boolean)method.invoke(null, inputStream, destFile);
        } catch (Exception ex) {
                FmUtils.log(TAG,"copyToFile, " + ex);
        }
        return ret;
    }

    private void showNotification(boolean isFM, float currentFreq) {
        FmUtils.log(TAG,"showNotification");
        Notification notification = new Notification(R.drawable.fm_app_icon,
                getString(R.string.app_name),System.currentTimeMillis());
        notification.flags |= Notification.FLAG_ONGOING_EVENT;
        notification.flags |= Notification.FLAG_SHOW_LIGHTS;
        notification.defaults = Notification.DEFAULT_LIGHTS;
        notification.ledARGB = Color.BLUE;
        notification.ledOnMS =5000;

        CharSequence contentTitle = getString(R.string.app_name);
        CharSequence contentText;
        if (isFM) {
            contentText = new StringBuffer(String.valueOf(currentFreq))
                                    .append("MHz").toString();
        } else {
            contentText = new StringBuffer(String.valueOf(currentFreq))
                                    .append("KHz").toString();
        }
        Intent notificationIntent =new Intent(getApplicationContext(), FmRadioActivity.class);
        PendingIntent contentItent = PendingIntent.getActivity(getApplicationContext(), 0,
                notificationIntent, 0);
        notification.setLatestEventInfo(getApplicationContext(), contentTitle, contentText,
                contentItent);
        startForeground(FMConstants.FM_NOTIFICATION_ID, notification);
    }
}
