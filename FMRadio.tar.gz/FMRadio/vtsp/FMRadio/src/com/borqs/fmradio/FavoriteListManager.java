package com.borqs.fmradio;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.borqs.fmradio.customControls.FavoriteButton;
import com.borqs.fmradio.listener.SwitchModeListener;
import com.borqs.fmradio.listener.ValueChangeListener;
import com.borqs.fmradio.utils.FmUtils;

public class FavoriteListManager implements SwitchModeListener,
        ValueChangeListener {
    private static final String TAG = "FavoriteListManager";

    float[] mFMFaverFreqs = new float[6];
    float[] mAMFaverFreqs = new float[6];
    float[] mFaverFreqs = mFMFaverFreqs;
    private int mCurActived = -1;
    private ArrayList<View> mViewList = new ArrayList<View>();
    OnChannelActivatedListenner mListenner = null;
    FmRadioActivity mActivity = null;

    private static final int mChannelNum = 3;
    private static final String FM_MHZ = "MHz";
    private static final String AM_HZ = "KHz";
    private String mHz = FM_MHZ;

    public interface OnChannelActivatedListenner {
        void onChannelActivated(float freq);
    }

    public void setOnChannelActivatedListenner(OnChannelActivatedListenner l) {
        mListenner = l;
    }

    public FavoriteListManager(Activity a) {
        if (null == a) {
            return;
        }
        mActivity = (FmRadioActivity)a;
        getFaveriteFreqs();
        initViews();
    }

    private void getFaveriteFreqs() {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "faverite_Freq_fm", Context.MODE_PRIVATE);

        for (int i=0; i<mChannelNum * 2; i++) {
            mFMFaverFreqs[i] = sp.getFloat(String.valueOf(i), -1f);
        }
        sp = mActivity.getSharedPreferences(
                "faverite_Freq_am", Context.MODE_PRIVATE);
        for (int i=0; i<mChannelNum * 2; i++) {
            mAMFaverFreqs[i] = sp.getFloat(String.valueOf(i), -1f);
        }

        mFaverFreqs = mActivity.isFM?mFMFaverFreqs:mAMFaverFreqs;
        mHz = mActivity.isFM?FM_MHZ:AM_HZ;
    }

    private void initViews() {
        LinearLayout upList = (LinearLayout)mActivity.findViewById(R.id.fav_channel_up);
        LinearLayout downList = (LinearLayout)mActivity.findViewById(R.id.fav_channel_down);

        initHalfFaveriteList(true,upList);
        initHalfFaveriteList(false,downList);

        for (int i=0; i<mViewList.size(); i++) {
            View v = mViewList.get(i);

            float freq = mFaverFreqs[i];
            v.setTag(new ItemTag(i, freq));

            ((FavoriteButton)v).setContent(freq, mActivity.isFM);

            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FmUtils.log(TAG,"onClick");

                    if (mViewList.indexOf(v) == mCurActived) {
                        return;
                    }

                    ItemTag tag = (ItemTag)v.getTag();

                    if (-1 == tag.mFreq) {
                        // don't allow to save the same value
                        for(float j:mFaverFreqs){
                            if(j == mActivity.getFreq()){
                               Toast toast = Toast.makeText(mActivity.getApplicationContext(), R.string.add_notice,
                                        Toast.LENGTH_SHORT);
                               toast.setGravity(Gravity.CENTER, 0, 0);
                               toast.show();
                               return;
                            }
                        }
                        // judge the FM's channel range
                        if(mActivity.isFM && (mActivity.getFreq()<87.5f || mActivity.getFreq()>108f)){
                            return;
                        }else if(!mActivity.isFM && (mActivity.getFreq()<531f || mActivity.getFreq()>1629f)){
                            return;
                        }
                        tag.mFreq = mActivity.getFreq();
                        setFaveriteFreq(tag.mIndex, mActivity.getFreq(), true);
                        ((FavoriteButton)v).setContent(tag.mFreq, mActivity.isFM);
                    }

                    switchActived(v, true);
                }
            });

            v.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    FmUtils.log(TAG,"onLongClick");

                    ItemTag tag = (ItemTag)v.getTag();

                    tag.mFreq = -1;
                    mCurActived = -1;

                    setFaveriteFreq(tag.mIndex, tag.mFreq, false);
                    ((FavoriteButton)v).setContent(tag.mFreq, mActivity.isFM);

                    return true;
                }
            });
        }
    }

    private void initHalfFaveriteList(boolean flag, ViewGroup list) {
        FavoriteButton channelButton1 = null;
        FavoriteButton channelButton2 = null;
        FavoriteButton channelButton3 = null;
        if(flag){
             channelButton1 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_up_button1);
             channelButton2 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_up_button2);
             channelButton3 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_up_button3);
        } else {
             channelButton1 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_down_button1);
             channelButton2 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_down_button2);
             channelButton3 = (FavoriteButton) mActivity.findViewById(R.id.fav_channel_down_button3);
        }
        mViewList.add(channelButton1);
        mViewList.add(channelButton2);
        mViewList.add(channelButton3);
        FmUtils.log(TAG,"initHalfFaveriteList , " + mViewList.size());
    }

    @Override
    public void setValue(float freq) {
        FmUtils.log(TAG,"setValue, " + freq);

        if (mCurActived != -1 && Math.abs(freq - mFaverFreqs[mCurActived]) < 0.05) {
            return;
        }

        for (int i=0; i<mFaverFreqs.length; i++) {
            FmUtils.log(TAG,"mFaverFreqs[" + i + "] = " + mFaverFreqs[i]);
            if (Math.abs(freq - mFaverFreqs[i]) < 0.05) {
                FmUtils.log(TAG,"match");
                switchActived(mViewList.get(i), false);
                return;
            } else {
                ((FavoriteButton)mViewList.get(i)).getText().setBackgroundResource(0);
            }
        }

        switchActived(null, false);
    }

    private void switchActived(View v, boolean notify) {
        if (null == v) {
            if (mCurActived != -1) {
                mViewList.get(mCurActived).setPressed(false);
                mCurActived = -1;
            }
            return;
        }

        ItemTag tag = (ItemTag)v.getTag();
        FmUtils.log(TAG,"switchActived, freq = " + tag.mFreq + ", index = " + tag.mIndex + ", notify = " + notify);

        if (mCurActived == tag.mIndex) {
            return;
        }

        if (mCurActived != -1) {
            ((FavoriteButton)mViewList.get(mCurActived)).getText().setBackgroundResource(0);
        }
        mCurActived = tag.mIndex;

        ((FavoriteButton)mViewList.get(mCurActived)).getText().setBackgroundResource(R.drawable.fav_btn_bg);

        if (notify && mListenner != null) {
            mListenner.onChannelActivated(tag.mFreq);
        }
    }

    @Override
    public void onChanged(boolean value) {
        mFaverFreqs = value?mFMFaverFreqs:mAMFaverFreqs;
        mHz = value?FM_MHZ:AM_HZ;
        for (int i=0; i<mViewList.size(); i++) {
            View v = mViewList.get(i);

            float freq = mFaverFreqs[i];
            v.setTag(new ItemTag(i, freq));

            ((FavoriteButton)v).setContent(freq, mActivity.isFM);
        }
    }

    public float getLatestFreq() {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        float result = 0;
        if (mActivity.isFM){
            result = sp.getFloat("latest_freq_fm", 87.5f);
        } else {
            result = sp.getFloat("latest_freq_am", 531f);
        }
        return result;
    }

    public void saveLatestFreq(float freq) {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        if (mActivity.isFM){
            editor.putFloat("latest_freq_fm", freq);
        } else {
            editor.putFloat("latest_freq_am", freq);
        }
        editor.commit();
    }

    public void saveIsFMLastExit() {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isFM", mActivity.isFM);
        editor.commit();
    }

    public boolean getIsFMLastExit(){
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        return sp.getBoolean("isFM", true);
    }

    private void setFaveriteFreq(int index, float freq, boolean isAdd) {
        mFaverFreqs[index] = freq;
        SharedPreferences sp;
        if (mActivity.isFM){
            sp = mActivity.getSharedPreferences("faverite_Freq_fm", Context.MODE_PRIVATE);
        } else {
            sp = mActivity.getSharedPreferences("faverite_Freq_am", Context.MODE_PRIVATE);
        }
        SharedPreferences.Editor editor = sp.edit();
        if (isAdd) {
            editor.putFloat(String.valueOf(index), freq);
        } else {
            editor.remove(String.valueOf(index));
        }
        editor.commit();
    }

    public void saveIsFMPlayingLastPlugOut() {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isFMPlayingLastPlugOut", true);
        editor.commit();
    }

    public boolean getIsFMPlayingLastPlugOut() {
        SharedPreferences sp = mActivity.getSharedPreferences(
                "FMRadio_config_file", Context.MODE_PRIVATE);
        return sp.getBoolean("isFMPlayingLastPlugOut", false);
    }

    private class ItemTag {
        public ItemTag(int index, float freq) {
            mIndex = index;
            mFreq = freq;
        }
        public int mIndex = -1;
        public float mFreq = -1;
    }

    public void clearAllFavBtnResource() {
        for (View view : mViewList) {
            ((FavoriteButton)view).unbindAllDrawables();
        }
        mViewList.clear();
        mViewList = null;
    }
}
