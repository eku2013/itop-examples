package com.borqs.fmradio.utils;

import java.lang.reflect.Method;

import android.media.AudioManager;
import android.util.Log;

public class FmUtils {

	public static final String TAG = "FmUtils";
	public static boolean DEBUG = android.os.Build.TYPE.equalsIgnoreCase("user") ? Log
			.isLoggable(TAG, Log.DEBUG) : true;
			
	public static void log(String tag, String msg) {
		if (DEBUG) Log.d(tag, msg);
	}
	
	public static float tidyFreq(float freq) {
		return (float)Math.round(freq * 10) / 10;
	}
	
	public static int setFmRxMode(AudioManager am, int fmMode){
		int result = FMConstants.AUDIO_STATUS_ERROR;
		try {
			log(TAG, "setFmRxMode: " + fmMode);
			Method setFmRxMode = am.getClass().getMethod("setFmRxMode",
					int.class);
			result = (Integer) setFmRxMode.invoke(am, fmMode);
		} catch (Exception e) {
			e.printStackTrace();
			log(TAG, "Exception e: " + e);
		}
		log(TAG, "setFmRxMode: result " + result);
		return result;
	}
	public static int getFmRxMode(AudioManager am){
		int result = FMConstants.MODE_FM_OFF;
		try {
			log(TAG, "getFmRxMode " );
			Method getFmRxMode = am.getClass().getMethod("getFmRxMode");
			result = (Integer) getFmRxMode.invoke(am);
		} catch (Exception e) {
			log(TAG, "Exception e: " + e);
		}
		log(TAG, "getFmRxMode: result " + result);
		return result;
	}
}
