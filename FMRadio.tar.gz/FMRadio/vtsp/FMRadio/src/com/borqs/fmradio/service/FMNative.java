package com.borqs.fmradio.service;

public class FMNative {
	
    public native static int fm_init();
    public native static int fm_deinit();
    public native static int fm_open();
    public native static int fm_close();
    public native static int fm_adjustvolume(int volumeArg,int mode);
    public native static int fm_getvolume();
    public native static int fm_changeChannel(int channel);
    public native static int fm_beginSearch(int channel);
    public native static int fm_stopSearch();
    public native static int fm_seek(int direction);
    public native static void fm_setmode(int mode);
    public native static int fm_getmode();
    public native static int[] fm_autoSeekChannel();
}
