package com.borqs.fmradio.listener;

import com.borqs.fmradio.FmRadioActivity;
import com.borqs.fmradio.utils.FMConstants;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AccOnBroadCastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		
		if (FMConstants.KEYCODE_ACC_ON_EVENT.equals(action)) {
			SharedPreferences sp = context.getSharedPreferences(
					"FMRadio_config_file", Context.MODE_PRIVATE);
			boolean isPlaying = sp.getBoolean("isFMPlayingLastPlugOut", false);
			// judge whether is playing FM or not when last power off 
			if (isPlaying) {
				// set isFMPlayingLastPlugOut to default value
				SharedPreferences.Editor editor = sp.edit();
				editor.putBoolean("isFMPlayingLastPlugOut", false);
				editor.commit();
				// start FMRadio
				Intent startActivityIntent = new Intent(context,FmRadioActivity.class);
				startActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(startActivityIntent);			
		    } 
		}
	}
}
