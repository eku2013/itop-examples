package com.borqs.fmradio.customControls;

import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.FmUtils;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class FavoriteButton extends FrameLayout {
    private static final String TAG = "FavoriteButton";
    private ImageButton mImage;
    private TextView mText;

    public FavoriteButton(Context context, AttributeSet attrs) {
        super(context,attrs);
        mImage = new ImageButton(context.getApplicationContext(),attrs);
        mImage.setPadding(0,0,0,0);
        mImage.setImageResource(R.drawable.add_icon);
        mImage.setBackgroundColor(Color.TRANSPARENT);
        mImage.setClickable(false);

        mText = new TextView(context.getApplicationContext(),attrs);
        mText.setGravity(Gravity.CENTER);
        mText.setPadding(0,0,0,0);
        mText.setTextSize(32);
        mText.setTextColor(Color.WHITE);
        mText.setTextScaleX(1);
        mText.setVisibility(INVISIBLE);

        setClickable(true);
        setFocusable(true);
        setBackgroundResource(R.drawable.fav_channel_backgroud);
        addView(mImage);
        addView(mText);
    }

    public ImageView getImage() {
        return mImage;
    }

    public TextView getText() {
        return mText;
    }

    public void setContent(float freq, boolean isFM) {
        FmUtils.log(TAG, "setContent, freq="+freq);

        StringBuilder sb = new StringBuilder();
        // -1 show image, or show text.
        if (-1 == freq) {
            mText.setText("");
            mText.setVisibility(INVISIBLE);
            mImage.setVisibility(VISIBLE);
        } else {
            if (isFM) {
                sb.append("FM ").append( String.format("%.1f", freq));
            } else {
                sb.append("AM ").append( String.format("%4.0f",freq));
            }
            mImage.setVisibility(INVISIBLE);
            mText.setText(sb.toString());
            mText.setVisibility(VISIBLE);
        }
    }

    public void unbindAllDrawables() {
        unbindBackgroundDrawables(this);
    }

    private void unbindBackgroundDrawables(View view) {

        try {
            if (view != null) {
               if (view.getBackground() != null) {
                   view.getBackground().setCallback(null);
               }

               if (view instanceof ViewGroup) {
                   for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                        unbindBackgroundDrawables(((ViewGroup) view).getChildAt(i));
                   }

                   ((ViewGroup) view).removeAllViews();
               }
            }
        }
        catch (Exception e) {
            FmUtils.log(TAG,"some ViewGroups don't support the removeAllViews method");
        }
    }
}
