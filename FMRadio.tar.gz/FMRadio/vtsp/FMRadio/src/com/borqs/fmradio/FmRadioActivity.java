package com.borqs.fmradio;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import com.borqs.fmradio.FavoriteListManager.OnChannelActivatedListenner;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.service.FMService.FmServiceBinder;
import com.borqs.fmradio.utils.FMConstants;
import com.borqs.fmradio.utils.FmUtils;
import com.borqs.fmradio.customControls.Nixietube;
import com.borqs.fmradio.listener.SwitchModeListener;
import com.borqs.fmradio.listener.ValueChangeListener;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class FmRadioActivity extends Activity 
              implements OnChannelActivatedListenner,OnClickListener{
    private static final String TAG = "FmRadioActivity";

    private static final String FM = "FM";
    private static final String AM = "AM";
    private static final String FM_MHz = "MHz";
    private static final String AM_KHz = "KHz";
    private static final String IS_FM = "isFM";
    private static final String CMD = "cmd";
    private static final String ENABLE = "enable";
    private static final String FREQ = "freq";
    private static final String CUR_FREQ = "currentFreq";
    private static final String MSG = "msg";
    private static final String FM_SCAN_LIST = "fm_scan_list";
    private static final String AM_SCAN_LIST = "am_scan_list";
    private static final String SCAN_CHANNEL_SIZE = "scan_channel_size";
    private static final String FM_CONFIG_FILE = "FMRadio_config_file";

    private TextView show_FM_AM;
    private TextView show_MHz_KHz;
    private ImageButton left_prev_btn;
    private ImageButton left_seek_btn;
    private ImageButton right_next_btn;
    private ImageButton right_seek_btn;
    private ImageButton change_to_FM_btn;
    private ImageButton change_to_AM_btn;
    private ImageButton scan_btn;
    private ImageButton power_btn;
    private ImageButton change_music_btn;
    private ImageButton change_fm_btn;
    private Nixietube mNixietube;
    private ListView scanChannelListview;
    private ProgressDialog mProgressDialog;

    protected boolean isFM = true;
    private boolean mIsFMPowerOn = true;
    private float currentFreq = 0;
    private float oldChannel = 0;
    private boolean isRightSeek = true;
    private boolean isSeeking = false;
    private boolean isRegister = false;
    private boolean closeFM = false;
    private boolean isSettingChannel = false;
    private boolean isWrapedAround = false;

    private ArrayList<ValueChangeListener> mFreqListener = new ArrayList<ValueChangeListener>();
    private ArrayList<SwitchModeListener> mSwitchListener = new ArrayList<SwitchModeListener>();
    private ArrayList<String> scanFMChannelsList = new ArrayList<String>();
    private ArrayList<String> scanAMChannelsList = new ArrayList<String>();
    private ArrayList<ImageButton> imgBtnHolder = new ArrayList<ImageButton>();
    private ChannelListAdapter adapter = null;

    private int fm_cur_pos = -1;// current played channel row in scaned channel list
    private int am_cur_pos = -1;

    private FmServiceBinder mServiceBinder;

    private FavoriteListManager mFaveriteManager;

    private ServiceConnection mConnection = new ServiceConnection(){

        public void onServiceConnected(ComponentName className, IBinder service) {
            FmUtils.log(TAG, "onServiceConnected");

            mServiceBinder = (FmServiceBinder)service;
            sendEnableFmCmd(mIsFMPowerOn);
            FmUtils.log(TAG,"init freq: " + currentFreq);
        }

        public void onServiceDisconnected(ComponentName className) {
            FmUtils.log(TAG, "onServiceDisconnected");
            mServiceBinder.clear();
            mServiceBinder = null;
            FMService.setActivityHandler(null);
        }
    };

    private Handler mHandler = new FmUIHandler(this);

    static class FmUIHandler extends Handler{

        private final WeakReference<Activity> mActivity;

        public FmUIHandler(Activity activity) {
            mActivity = new WeakReference<Activity>(activity);
        }

        public void handleMessage(Message msg) {
            FmUtils.log(TAG, "msg is " + msg);

            final FmRadioActivity fmActivity = (FmRadioActivity) mActivity.get();
            if (null == fmActivity) {
                return;
            }
            switch (msg.what) {
            case FMConstants.MSG_ENABLE_SUCCESSFUL:
                FmUtils.log(TAG, "MSG_ENABLE_SUCCESSFUL  set freq" + fmActivity.currentFreq);
                fmActivity.setFreq(fmActivity.currentFreq, null, true);
                break;
            case FMConstants.MSG_LEFT_SEEK_COMPLETE:
                fmActivity.isRightSeek = false;
                float left_seek_channel = (fmActivity.isFM ? (FmUtils.tidyFreq((Integer)msg.obj)/100):
                      (FmUtils.tidyFreq((Integer)msg.obj)));
                FmUtils.log(TAG, "MSG_LEFT_SEEK_COMPLETE  prev freq" + left_seek_channel +
                        "  oldChannel" + fmActivity.oldChannel);
                if ( 0f == left_seek_channel) { // If FM don't seek channel,we'll set last channel.
                    left_seek_channel = fmActivity.oldChannel;
                } else if (left_seek_channel > fmActivity.oldChannel) {
                    // If FM seek channel to band limits,we'll wrap around band limits.  
                    fmActivity.isWrapedAround = true;
                }
                fmActivity.setFreq(left_seek_channel, fmActivity.left_prev_btn, true);
                fmActivity.updateChannelCursor(left_seek_channel, false);
                break;
            case FMConstants.MSG_RIGHT_SEEK_COMPLETE:
                fmActivity.isRightSeek = true;
                float right_seek_channel = (fmActivity.isFM ? (FmUtils.tidyFreq((Integer)msg.obj)/100):
                      (FmUtils.tidyFreq((Integer)msg.obj)));
                FmUtils.log(TAG, "MSG_RIGHT_SEEK_COMPLETE  next freq" + right_seek_channel +
                        "  oldChannel" + fmActivity.oldChannel);
                if ( 0f == right_seek_channel) { // If FM don't seek channel,we'll set last channel.
                    right_seek_channel = fmActivity.oldChannel;
                } else if (right_seek_channel < fmActivity.oldChannel) {
                    // If FM seek channel to band limits,we'll wrap around band limits.
                    fmActivity.isWrapedAround = true;
                }
                fmActivity.setFreq(right_seek_channel, fmActivity.right_next_btn, true);
                fmActivity.updateChannelCursor(right_seek_channel, false);
                break;
            case FMConstants.MSG_SCAN_DONE:
                fmActivity.mProgressDialog.dismiss();
                int[] channels = (int[]) msg.obj;
                if ( null != channels ) {
                    fmActivity.saveScanChannels(channels);
                    fmActivity.updateChannelCursor(fmActivity.currentFreq, true);
                }
                break;
            case FMConstants.MSG_SET_CHANNEL_DONE:
                fmActivity.mProgressDialog.dismiss();
                fmActivity.isSettingChannel = false;
                break;
            case FMConstants.MSG_UPDATE_CHANNEL:
                float updateChannel = (Float)msg.obj;
                if (null != fmActivity.mNixietube) {
                    fmActivity.mNixietube.setValue(updateChannel);
                }
                break;
            case FMConstants.MSG_FM_EXIT:
                fmActivity.sendEnableFmCmd(false);
                break;
            case FMConstants.MSG_DISABLE_SUCCESSFUL:
                fmActivity.unbindService(fmActivity.mConnection);
                if (null != fmActivity.mFaveriteManager) {
                    fmActivity.mFaveriteManager.saveLatestFreq(fmActivity.currentFreq);
                    fmActivity.mFaveriteManager.saveIsFMLastExit();
                }
                fmActivity.saveScanChannelsToXml(fmActivity.scanFMChannelsList,
                        fmActivity.scanAMChannelsList);
                fmActivity.finish();
                break;
            }
        }
    };

    private BroadcastReceiver mBr = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
                 String action = intent.getAction();
                 if (FMConstants.KEYCODE_KEY_PLUG_OUT_EVENT.equals(action)) {
                     if ( null != mFaveriteManager) {
                         mFaveriteManager.saveIsFMPlayingLastPlugOut();
                     }
                     sendEnableFmCmd(false);
                 } else if (FMConstants.KEYCODE_MENU_TURN_LEFT.equals(action)) {
                     this.abortBroadcast(); // avoid music is lunched.
                     moveChannelUp();
                 } else if (FMConstants.KEYCODE_MENU_TURN_RIGHT.equals(action)) {
                     this.abortBroadcast(); // avoid music is lunched.
                     moveChannelDown();
                 } else if (FMConstants.KEYCODE_LONGCLICK_LEFT_MENU.equals(action)) {
                     sendEnableFmCmd(false);
                 } else if (FMConstants.KEYCODE_AUX_INSERT.equals(action)) {
                     sendEnableFmCmd(false);
                 } else if (FMConstants.FM_MUSIC_COMMUNICATION_NEXT_CHANNEL.equals(action)) {
                     oldChannel = currentFreq;
                     sendNextCmd();
                 } else if (FMConstants.FM_MUSIC_COMMUNICATION_PREV_CHANNEL.equals(action)) {
                     oldChannel = currentFreq;
                     sendPrevCmd();
                 } else if (FMConstants.FM_MUSIC_COMMUNICATION_DISABLE_FM.equals(action)) {
                     String msg = intent.getStringExtra(MSG);
                     if (FMConstants.DISABLE_MSG_FROM_FM.equals(msg)){
                         return;
                     } else {
                         sendEnableFmCmd(false);
                     }
                 }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FmUtils.log(TAG, "onCreate");
        setContentView(R.layout.main);
        showDialog(FMConstants.POWERING_ON_FM_NOTICE);
        FMService.setActivityHandler(mHandler);
        startService();
        initButtons();
        updateFMAMButtons();
        scanChannelListview = (ListView)findViewById(R.id.list);
        adapter = new ChannelListAdapter(getApplicationContext());
        scanChannelListview.setAdapter(adapter); 
        scanChannelListview.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        scanChannelListview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View arg1,
            int position, long id) {
                  if (null != adapter) {
                      if (isFM) {
                          fm_cur_pos = position;
                          adapter.setCurPos(fm_cur_pos);
                      } else {
                          am_cur_pos = position;
                          adapter.setCurPos(am_cur_pos);
                      }
                  }
                  String selectedChannelStr = null;
                  float selectedChannel = 0f;
                  if(isFM){
                     selectedChannelStr = scanFMChannelsList.get(position);
                  }else{
                     selectedChannelStr = scanAMChannelsList.get(position);
                  }
                  if( null != selectedChannelStr){
                      selectedChannel = Float.parseFloat(selectedChannelStr
                                 .substring(0,selectedChannelStr.length()-3));
                  } else {
                      return;
                  }
                  setFreq(selectedChannel,null,true);
                }
            });
        if ( null != mFaveriteManager) {
                getScannedChannelsFromXml();
                if (mFaveriteManager.getIsFMLastExit()) {
                    if (null != adapter) {
                        adapter.refresh(scanFMChannelsList);
                    }
                } else {
                    if (null != adapter) {
                        adapter.refresh(scanAMChannelsList);
                    }
                }
        }
        if (!isRegister) {
                IntentFilter intentFilter = new IntentFilter(FMConstants.KEYCODE_KEY_PLUG_OUT_EVENT);
                intentFilter.addAction(FMConstants.KEYCODE_AUX_INSERT);
                intentFilter.addAction(FMConstants.KEYCODE_LONGCLICK_LEFT_MENU);
                intentFilter.addAction(FMConstants.KEYCODE_MENU_TURN_LEFT);
                intentFilter.addAction(FMConstants.KEYCODE_MENU_TURN_RIGHT);
                intentFilter.addAction(FMConstants.FM_MUSIC_COMMUNICATION_DISABLE_FM);
                intentFilter.addAction(FMConstants.FM_MUSIC_COMMUNICATION_NEXT_CHANNEL);
                intentFilter.addAction(FMConstants.FM_MUSIC_COMMUNICATION_PREV_CHANNEL);
                intentFilter.setPriority(FMConstants.FM_RECIVED_BRODCASET_PRIORITY);
                registerReceiver(mBr,intentFilter);
                isRegister = true;
        }
        FmUtils.log(TAG, "onCreate end");
    }
    protected ArrayList<String> saveScanChannels(int[] channels) {
        if(isFM){
            scanFMChannelsList.clear();
            for(int i:channels){
                StringBuffer fmChannelValue = new StringBuffer();
                float channelFM = ((float)i)/100;
                if(channelFM < 87.5f || channelFM > 108f){
                    continue;
                }
                fmChannelValue.append(channelFM).append(FM_MHz);
                scanFMChannelsList.add(fmChannelValue.toString());
            }
            return scanFMChannelsList;
        }else{
            scanAMChannelsList.clear();
            for(int j:channels){
                StringBuffer amChannelValue = new StringBuffer();
                if(j < 531f || j > 1629f){
                    continue;
                }
                amChannelValue.append(j).append(AM_KHz);
                scanAMChannelsList.add(amChannelValue.toString());
            }
            return scanAMChannelsList;
        }
    }

    private class UpdateSeekChannnelThread implements Runnable{
        @Override
        public void run() {
            float steup = isFM ? 0.1f:1f;
            float data = oldChannel;
            // If FM seek channel to band limits,we'll wrap around band limits.
            while((isRightSeek ? (isWrapedAround ? (data > currentFreq):(data < currentFreq))
                    :(isWrapedAround ? (data < currentFreq):(data > currentFreq)))){
                try{
                    if(isRightSeek){
                        if (isWrapedAround) {
                            data = data - steup;
                        } else {
                            data = data + steup;
                        }
                    } else {
                        if (isWrapedAround) {
                            data = data + steup;
                        } else {
                            data = data - steup;
                        }
                    }
                    if(isFM){
                        data = FmUtils.tidyFreq(data);
                    }
                    Thread.sleep(3);
                    if ( null != mHandler) {
                       Message msg = Message.obtain(mHandler,FMConstants.MSG_UPDATE_CHANNEL);
                       msg.obj = data;
                       msg.sendToTarget();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
            if (isWrapedAround) {
                isWrapedAround = false;
            }
            isSeeking = false;
        }

    }
    private void setFreq(float freq, Object caller, boolean setDevice) {
        FmUtils.log(TAG,"setFreq: " + freq);

        if (null == mFreqListener) {
            return;
        }

        currentFreq = freq;
        if (setDevice) {
            if(isSeeking){
                new Thread(new UpdateSeekChannnelThread()).start();
            }
            sendSetChannelCmd(freq);
            if(isSeeking){
                mFaveriteManager.setValue(freq);
                return;
            }
        }

        for (ValueChangeListener l: mFreqListener) {
            if (null == l) {
                continue;
            }
            if (l != caller) {
                l.setValue(freq);
            }
        }
    }
    protected void onPause() {
        FmUtils.log(TAG,"onPause");
        super.onPause();
    }
    @Override
    protected void onStop() {
        super.onStop();

        if (!closeFM) {
            if (null != mServiceBinder) {
                Bundle b = new Bundle();
                b.putInt(CMD, FMConstants.MSG_FM_ONSTOP);
                b.putBoolean(IS_FM, isFM);
                b.putFloat(CUR_FREQ,currentFreq);
                mServiceBinder.sendBundle(b);
            }
        }
    }
    private void initButtons(){
        // get fm status (FM or AM) from config file
        SharedPreferences fm_sp = getSharedPreferences(FM_CONFIG_FILE, Context.MODE_PRIVATE);
        isFM = fm_sp.getBoolean(IS_FM, true);

        mFaveriteManager = new FavoriteListManager(this);
        mFaveriteManager.setOnChannelActivatedListenner(this);
        mSwitchListener.add(mFaveriteManager);
        mFreqListener.add(mFaveriteManager);
        // Init FM's mode and current freq.
        isFM = mFaveriteManager.getIsFMLastExit();
        currentFreq = mFaveriteManager.getLatestFreq();
        // show FM or AM

        show_FM_AM = (TextView)findViewById(R.id.show_FM_AM);
        show_MHz_KHz = (TextView)findViewById(R.id.show_MHz_KHz);

        // search channel operation button
        left_prev_btn = (ImageButton)findViewById(R.id.left_prev_button);
        left_prev_btn.setOnClickListener(this);
        imgBtnHolder.add(left_prev_btn);
        left_seek_btn = (ImageButton)findViewById(R.id.left_seek_button);
        left_seek_btn.setOnClickListener(this);
        imgBtnHolder.add(left_seek_btn);
        right_next_btn = (ImageButton)findViewById(R.id.right_next_button);
        right_next_btn.setOnClickListener(this);
        imgBtnHolder.add(right_next_btn);
        right_seek_btn = (ImageButton)findViewById(R.id.right_seek_button);
        right_seek_btn.setOnClickListener(this);
        imgBtnHolder.add(right_seek_btn);

        mNixietube = (Nixietube)findViewById(R.id.nixie_tube);
        mSwitchListener.add(mNixietube);
        mFreqListener.add(mNixietube);
        // Init display main UI channels.
        mNixietube.setValue(currentFreq);

        // switch FM and AM button
        change_to_FM_btn = (ImageButton)findViewById(R.id.change_to_fm_btn);
        change_to_FM_btn.setOnClickListener(this);
        imgBtnHolder.add(change_to_FM_btn);
        change_to_AM_btn = (ImageButton)findViewById(R.id.change_to_am_btn);
        change_to_AM_btn.setOnClickListener(this);
        imgBtnHolder.add(change_to_AM_btn);

        // scan channel and power off fm button
        scan_btn = (ImageButton)findViewById(R.id.scan_btn);
        scan_btn.setOnClickListener(this);
        imgBtnHolder.add(scan_btn);
        power_btn = (ImageButton)findViewById(R.id.power_btn);
        power_btn.setOnClickListener(this);
        imgBtnHolder.add(power_btn);
        change_music_btn = (ImageButton)findViewById(R.id.music_btn);
        change_music_btn.setOnClickListener(this);
        imgBtnHolder.add(change_music_btn);
        change_fm_btn = (ImageButton)findViewById(R.id.fm_btn);
        change_fm_btn.setOnClickListener(this);
        imgBtnHolder.add(change_fm_btn);
    }
    private void startService() {
        FmUtils.log(TAG, "startService");
        Intent intent = new Intent().setClass(this, FMService.class);
        this.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
    }

    private void sendSetChannelCmd(float channel) {
        FmUtils.log(TAG,"sendSetChannelCmd channel " + channel);
        try {
            int ic ;
            if (isFM){
                if (channel < 87.5f || channel > 108f){
                    return;
                }
                ic = (int) (channel * 1000);
            } else {
                if(channel < 531f || channel > 1629f){
                    return;
                }
                ic = (int) channel;
            }

            Bundle b = new Bundle();
            b.putInt(CMD, FMConstants.CMD_SET_CHANNEL);
            b.putInt(FREQ, ic);
            b.putBoolean(IS_FM, isFM);
            mServiceBinder.sendBundle(b);
            isSettingChannel = true;
        } catch (NumberFormatException e) {
            Toast.makeText(FmRadioActivity.this,R.string.channel_wrong_value,
                    Toast.LENGTH_LONG).show();
            return;
        }
    }

    public float getFreq(){
        return currentFreq;
    }
    @Override
    protected void onResume() {
        super.onResume();
        FmUtils.log(TAG, "onResume");

        if (null != mServiceBinder) {
            Bundle b = new Bundle();
            b.putInt(CMD, FMConstants.MSG_FM_ONRESUME);
            mServiceBinder.sendBundle(b);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FmUtils.log(TAG, "onDestroy");

        if (isRegister) {
            unregisterReceiver(mBr);
            isRegister = false;
        }

        if (null != mFaveriteManager){
            mFaveriteManager.setOnChannelActivatedListenner(null);
            mFaveriteManager.clearAllFavBtnResource();
            mFaveriteManager = null;
        }
        mFreqListener.clear();
        mFreqListener = null;
        mSwitchListener.clear();
        mSwitchListener = null;

        scanFMChannelsList.clear();
        scanFMChannelsList = null;
        scanAMChannelsList.clear();
        scanAMChannelsList = null;
        adapter = null;

        for (View view : imgBtnHolder) {
            unbindDrawables((ImageButton)view);
        }
        imgBtnHolder.clear();
        imgBtnHolder = null;

        mNixietube.releaseAllBitmapResource();
        mNixietube = null;
    }

    @Override
    public void onBackPressed() {
        FmUtils.log(TAG, "onBackPressed");
        moveTaskToBack(true);
        return;
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        Toast toast = null;

        switch(viewId){
        case R.id.left_prev_button:
            if (!isSeeking) {
                isSeeking = true;
                oldChannel = currentFreq;
                sendPrevCmd();
            } else {
                toast = Toast.makeText(getApplicationContext(), R.string.seek_notice,
                             Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            break;
        case R.id.left_seek_button:
            float freq_left = getFreq();
            if (isFM && (freq_left <= 87.5f)){
                return;
            }else if(!isFM && (freq_left <= 531f)){
                return;
            }
            FmUtils.log(TAG,"getFreq() = " + freq_left);
            freq_left = FmUtils.tidyFreq(freq_left - getSeekSpacing());
            FmUtils.log(TAG,"freq - space = " + freq_left);
            setFreq(freq_left, left_seek_btn, true);
            updateChannelCursor(freq_left, false);
            break;
        case R.id.right_next_button:
            if (!isSeeking) {
                isSeeking = true;
                oldChannel = currentFreq;
                sendNextCmd();
            } else {
                toast = Toast.makeText(getApplicationContext(), R.string.seek_notice,
                         Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
            }
            break;
        case R.id.right_seek_button:
            float freq_right = getFreq();
            if (isFM && (freq_right >= 108f)){
                return;
            }else if(!isFM && (freq_right >= 1629f)){
                return;
            }
            FmUtils.log(TAG,"getFreq() = " + freq_right);
            freq_right = FmUtils.tidyFreq(freq_right + getSeekSpacing());
            FmUtils.log(TAG,"freq + space = " + freq_right);
            setFreq(freq_right, right_seek_btn, true);
            updateChannelCursor(freq_right, false);
            break;
        case R.id.change_to_fm_btn:
            if (!isSeeking) {
                mFaveriteManager.saveLatestFreq(currentFreq);
                isFM = true;
                updateFMAMButtons();
                notifyFMAMChanged();
            } else {
                toast = Toast.makeText(getApplicationContext(), R.string.seek_notice,
                         Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
            }
            break;
        case R.id.change_to_am_btn:
            if (!isSeeking) {
                mFaveriteManager.saveLatestFreq(currentFreq);
                isFM = false;
                updateFMAMButtons();
                notifyFMAMChanged();
            } else {
                toast = Toast.makeText(getApplicationContext(), R.string.seek_notice,
                         Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
            }
            break;
        case R.id.scan_btn:
            sendScanCmd();
            break;
        case R.id.power_btn:
            mIsFMPowerOn = !mIsFMPowerOn;
            sendEnableFmCmd(mIsFMPowerOn);
            break;
        case R.id.music_btn:
            startMusicApp();
            break;
        case R.id.fm_btn:
            break;
        default:
            break;
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        FmUtils.log(TAG, "onCreateDialog,id="+id);
        switch (id) {
        case FMConstants.SCANNING_NOTICE:
            mProgressDialog = new ProgressDialog(FmRadioActivity.this);
            mProgressDialog.setMessage(getString(R.string.scan_notice));
            mProgressDialog.setCanceledOnTouchOutside(false);
            break;
        case FMConstants.POWERING_ON_FM_NOTICE:
            mProgressDialog = new ProgressDialog(FmRadioActivity.this);
            mProgressDialog.setMessage(getString(R.string.open_fm));
            mProgressDialog.setCanceledOnTouchOutside(false);
            break;
        }
        return mProgressDialog;
    }

    private void startMusicApp() {
        FmUtils.log(TAG, "startMusicApp()");

        ComponentName musicApp = new ComponentName(
                "com.borqs.music",
                "com.borqs.music.ui.MediaPlaybackActivity");
        try{
            Intent intent = new Intent();
            intent.setComponent(musicApp);
            startActivity(intent);
        }catch(Exception e){
            FmUtils.log(TAG, "Don't find available music app!");
        }
    }
    private void moveChannelDown() {
        String selectedChannelStr = null;
        float channel = -1l;

        if ( null == adapter) {
            return;
        }

        if (isFM) {
               if (null != scanFMChannelsList) {
                   int fmSize = scanFMChannelsList.size();
                   if (fmSize != 0) {
                        if (fm_cur_pos >= -1 && fm_cur_pos < (fmSize - 1)) {
                            fm_cur_pos++;
                        } else if (fm_cur_pos == (fmSize - 1)) {
                            fm_cur_pos = 0;
                        }
                        selectedChannelStr = scanFMChannelsList.get(fm_cur_pos);
                   } else {
                       // If scanned channels list's size is 0, scan all channels.
                       sendScanCmd();
                       return;
                   }
               }
               adapter.setCurPos(fm_cur_pos);
        } else {
               if (null != scanAMChannelsList) {
                   int amSize = scanAMChannelsList.size();
                   if (amSize != 0) {
                        if (am_cur_pos >= -1 && am_cur_pos < (amSize - 1)) {
                            am_cur_pos++;
                        } else if (am_cur_pos == (amSize - 1)) {
                            am_cur_pos = 0;
                        }
                        selectedChannelStr = scanAMChannelsList.get(am_cur_pos);
                    } else {
                        // If scanned channels list's size is 0, scan all channels.
                        sendScanCmd();
                        return;
                    }
               }
               adapter.setCurPos(am_cur_pos);
        }

        adapter.notifyDataSetChanged();

        if (null != selectedChannelStr) {
            channel = Float.parseFloat(selectedChannelStr.substring(0,
                    selectedChannelStr.length() - 3));
        }
        if (-1l != channel) {
            setFreq(channel, null, true);
        }
    }

    private void moveChannelUp() {
        String selectedChannelStr = null;
        float channel = -1l;

        if ( null == adapter) {
            return;
        }

        if (isFM) {
               if (null != scanFMChannelsList) {
                   int fmSize = scanFMChannelsList.size();
                   if (fmSize != 0) {
                        if (fm_cur_pos > 0 && fm_cur_pos <= (fmSize-1)) {
                            fm_cur_pos--;
                        } else if (fm_cur_pos == 0 || fm_cur_pos == -1) {
                            fm_cur_pos = fmSize-1;
                        }
                        selectedChannelStr = scanFMChannelsList.get(fm_cur_pos);
                   } else {
                        // If scanned channels list's size is 0, scan all channels.
                        sendScanCmd();
                        return;
                   }
               }
               adapter.setCurPos(fm_cur_pos);
        } else {
               if (null != scanAMChannelsList) {
                   int amSize = scanAMChannelsList.size();
                   if (amSize != 0) {
                       if (am_cur_pos > 0 && am_cur_pos <= (amSize-1)) {
                           am_cur_pos--;
                       } else if (am_cur_pos == 0 || am_cur_pos == -1) {
                           am_cur_pos = amSize-1;
                       }
                       selectedChannelStr = scanAMChannelsList.get(am_cur_pos);
                   } else {
                       // If scanned channels list's size is 0, scan all channels.
                       sendScanCmd();
                       return;
                   }
               }
               adapter.setCurPos(am_cur_pos);
        }

        adapter.notifyDataSetChanged();

        if (null != selectedChannelStr) {
            channel = Float.parseFloat(selectedChannelStr.substring(0,
                    selectedChannelStr.length() - 3));
        }
        if (-1l != channel) {
            setFreq(channel, null, true);
        }
    }
    private void sendScanCmd() {
        FmUtils.log(TAG,"sendScanCmd");
        Bundle b = new Bundle();
        b.putInt(CMD, FMConstants.CMD_SCAN);
        mServiceBinder.sendBundle(b);
        showDialog(FMConstants.SCANNING_NOTICE);
    }
    private float getSeekSpacing() {
        float space = 0.1f;
        if (!isFM){
            space = 9f;
        }
        return space;
    }

    private void sendEnableFmCmd(boolean enable) {
        FmUtils.log(TAG,"sendEnableFmCmd " + enable);

        if (isSettingChannel) {
            return;
        }
        Bundle b = new Bundle();
        b.putInt(CMD, FMConstants.CMD_ENABLE);
        b.putBoolean(ENABLE, enable);
        b.putBoolean(IS_FM, isFM);
        mServiceBinder.sendBundle(b);
        if (!enable){
            closeFM = true;

            // Notify widget to change UI.
            Intent intent = new Intent(FMConstants.FM_MUSIC_COMMUNICATION_DISABLE_FM);
            intent.putExtra(MSG, FMConstants.DISABLE_MSG_FROM_FM);
            sendBroadcast(intent);

        }
    }

    private void sendNextCmd() {
        FmUtils.log(TAG,"sendNextCmd");
        Bundle b = new Bundle();
        b.putInt(CMD, FMConstants.CMD_NEXT);
        mServiceBinder.sendBundle(b);
    }

    private void sendPrevCmd() {
        FmUtils.log(TAG,"sendPrevCmd");
        Bundle b = new Bundle();
        b.putInt(CMD, FMConstants.CMD_PREV);
        mServiceBinder.sendBundle(b);
    }

    private void notifyFMAMChanged(){
        for (SwitchModeListener l: mSwitchListener) {
            l.onChanged(isFM);
        }
        float freq = mFaveriteManager.getLatestFreq();
        FmUtils.log(TAG,"init freq: " + freq);
        setFreq(freq, null, true);
        updateChannelCursor(freq, false);
    }

    private void updateChannelCursor(float freq,boolean isScaned) {
        // refresh the scan channel list when switch between fm and am
        int flag = -1;
        float channel = -1f;
        if (null == adapter) {
            return;
        }
        if(isFM){
            if (null == scanFMChannelsList) {
                return;
            }
            adapter.refresh(scanFMChannelsList);
            if (-1 != fm_cur_pos){
                for(int i = 0;i < scanFMChannelsList.size();i++){
                    String fmStr = scanFMChannelsList.get(i);
                    if(freq == Float.parseFloat(fmStr
                             .substring(0,fmStr.length()-3))){
                        fm_cur_pos = i;
                        flag++;
                        break;
                    }
                }
            }
            if (isScaned) {
                if (-1 == flag) {
                    // If current played freq isn't contained in scanned channels list,
                    // play the first channel in scanned list.
                    if (scanFMChannelsList.size() > 0) {
                        fm_cur_pos = 0;
                        adapter.setCurPos(fm_cur_pos);
                        String fmChannel = scanFMChannelsList.get(0);
                        channel = Float.parseFloat(fmChannel
                                    .substring(0, fmChannel.length()-3));
                        mNixietube.setValue(channel);
                        currentFreq = channel;
                        setFreq(channel, null, true);
                    } else {
                        // If scan action can't get any channels,
                        // play default channel.
                        adapter.setCurPos(-1);
                        setFreq(87.5f, null, true);
                    }
                } else {
                    adapter.setCurPos(fm_cur_pos);
                    setFreq(freq, null, true);
                }
            } else {
                if (-1 == flag) {
                    adapter.setCurPos(-1);
                } else {
                    if (scanFMChannelsList.size() > 0) {
                        adapter.setCurPos(fm_cur_pos);
                    } else {
                        adapter.setCurPos(-1);
                    }
                }
            }
        } else {
            if (null == scanAMChannelsList) {
                return;
            }
            adapter.refresh(scanAMChannelsList);
            if (-1 != am_cur_pos){
                for(int i = 0;i < scanAMChannelsList.size();i++){
                    String AmStr = scanAMChannelsList.get(i);
                    if(freq == Float.parseFloat(AmStr
                             .substring(0,AmStr.length()-3))){
                        am_cur_pos = i;
                        flag++;
                        break;
                    }
                }
            }
            if (isScaned) {
                if (-1 == flag) {
                    // If current played freq isn't contained in scanned channels list,
                    // play the first channel in scanned list.
                    if (scanAMChannelsList.size() > 0) {
                        am_cur_pos = 0;
                        adapter.setCurPos(am_cur_pos);
                        String amChannel = scanAMChannelsList.get(0);
                        channel = Float.parseFloat(amChannel
                                    .substring(0, amChannel.length()-3));
                        mNixietube.setValue(channel);
                        currentFreq = channel;
                        setFreq(channel, null, true);
                    } else {
                        // If scan action can't get any channels,
                        // play default channel.
                        adapter.setCurPos(-1);
                        setFreq(531f, null, true);
                    }
                } else {
                    adapter.setCurPos(am_cur_pos);
                    setFreq(freq, null, true);
                }
            } else {
                if (-1 == flag) {
                    adapter.setCurPos(-1);
                } else {
                    if (scanAMChannelsList.size() > 0) {
                        adapter.setCurPos(am_cur_pos);
                    } else {
                        adapter.setCurPos(-1);
                    }
                }
            }
        }
    }

    private void updateFMAMButtons() {
        if(isFM){
            change_to_FM_btn.setBackgroundResource(R.drawable.button_fm_press);
            change_to_AM_btn.setBackgroundResource(R.drawable.button_am);
            updateFMAMDisplay(isFM);
        } else {
            change_to_FM_btn.setBackgroundResource(R.drawable.button_fm);
            change_to_AM_btn.setBackgroundResource(R.drawable.button_am_press);
            updateFMAMDisplay(isFM);
        }
    }

    private void updateFMAMDisplay(boolean isFm) {

        if(isFm){
            if(!FM.equals(show_FM_AM.getText().toString())){
                show_FM_AM.setText(FM);
            }
            if(!FM_MHz.equals(show_MHz_KHz.getText().toString())){
                show_MHz_KHz.setText(FM_MHz);
            }
        }else{
            if(!AM.equals(show_FM_AM.getText().toString())){
                show_FM_AM.setText(AM);
            }
            if(!AM_KHz.equals(show_MHz_KHz.getText().toString())){
                show_MHz_KHz.setText(AM_KHz);
            }
        }
    }

    private void saveScanChannelsToXml(ArrayList<String> fmChannelList,
            ArrayList<String> amChannelList) {
        float channel = 0f;
        if ( null != fmChannelList && fmChannelList.size() !=0 ) {
            SharedPreferences fm_sp = getSharedPreferences(
                    FM_SCAN_LIST, Context.MODE_PRIVATE);

            SharedPreferences.Editor fm_editor = fm_sp.edit();
            fm_editor.clear();

            fm_editor.putInt(SCAN_CHANNEL_SIZE, fmChannelList.size());
            for(int i = 0; i < fmChannelList.size(); i++){
                        String fmChannelStr = fmChannelList.get(i);
                        channel = Float.parseFloat(fmChannelStr
                                 .substring(0,fmChannelStr.length()-3));
                        fm_editor.putFloat("fm_scan_"+i, channel);
            }
            fm_editor.commit();
        }
        if ( null != amChannelList && amChannelList.size() !=0 ) {
            SharedPreferences am_sp = getSharedPreferences(
                    AM_SCAN_LIST, Context.MODE_PRIVATE);

            SharedPreferences.Editor am_editor = am_sp.edit();
            am_editor.clear();

            am_editor.putInt(SCAN_CHANNEL_SIZE, amChannelList.size());
            for(int i = 0; i < amChannelList.size(); i++){
                        String amChannelStr = amChannelList.get(i);
                        channel = Float.parseFloat(amChannelStr
                                 .substring(0,amChannelStr.length()-3));
                        am_editor.putFloat("am_scan_"+i, channel);
            }
            am_editor.commit();
        }
    }

    private void getScannedChannelsFromXml() {
            // get saved fm scanned channels from xml.
            SharedPreferences fm_sp = getSharedPreferences(
                    FM_SCAN_LIST, Context.MODE_PRIVATE);

            scanFMChannelsList.clear();
            int fm_size = fm_sp.getInt(SCAN_CHANNEL_SIZE, 0);
            if (fm_size > 0) {
                for(int i = 0; i < fm_size; i++) {
                    int fm_channel = (int)(fm_sp.getFloat("fm_scan_"+i, 90.0f)*100);
                    StringBuffer fmChannelValue = new StringBuffer();
                    float channelFM = ((float)fm_channel)/100;
                    if(channelFM < 87.5f || channelFM > 108f){
                        continue;
                    }
                    fmChannelValue.append(channelFM).append(FM_MHz);
                    scanFMChannelsList.add(fmChannelValue.toString());
                }
            }

            // get saved am scanned channels from xml.
            SharedPreferences am_sp = getSharedPreferences(
                    AM_SCAN_LIST, Context.MODE_PRIVATE);

            scanAMChannelsList.clear();
            int am_size = am_sp.getInt(SCAN_CHANNEL_SIZE, 0);
            if (am_size > 0) {
                for(int i = 0; i < am_size; i++) {
                    int channelAM = (int)am_sp.getFloat("am_scan_"+i, 531f);
                    StringBuffer amChannelValue = new StringBuffer();
                    if(channelAM < 531f || channelAM > 1629f){
                        continue;
                    }
                    amChannelValue.append(channelAM).append(AM_KHz);
                    scanAMChannelsList.add(amChannelValue.toString());
                }
            }
    }

    @Override
    public void onChannelActivated(float freq) {
        setFreq(freq, mFaveriteManager, true);
        updateChannelCursor(freq, false);
    }

    private class ChannelListAdapter extends BaseAdapter {
        private LayoutInflater inflater;
        private ArrayList<String> scanChannelsList = new ArrayList<String>();
        private int cur_pos = -1;

        public ChannelListAdapter(Context context) {
        inflater = (LayoutInflater) context
        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public void setCurPos(int curPos) {
            cur_pos = curPos;
        }

        public void refresh(ArrayList<String> list) {
            scanChannelsList = list;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return scanChannelsList.size();
        }

        @Override
        public Object getItem(int position) {
            return scanChannelsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final ViewHolder holder;
            if (null == convertView) {
                convertView = inflater.inflate(R.layout.scan_channel_list_item, null, false);
                holder = new ViewHolder();
                holder.channelItemText = (TextView)convertView.findViewById(R.id.channelValue);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.channelItemText.setBackgroundResource(0);
            holder.channelItemText.setText(scanChannelsList.get(position));
            holder.channelItemText.setTextColor(Color.WHITE);
            holder.channelItemText.setGravity(Gravity.CENTER);
            if (position == cur_pos) {
                holder.channelItemText.setBackgroundResource(R.drawable.list_highlight);
                holder.channelItemText.setTextColor(Color.WHITE);
                holder.channelItemText.setFocusable(false);
                TextPaint paint = holder.channelItemText.getPaint();
                paint.setFakeBoldText(true);
            }
            return convertView;
        }
    }

    private class ViewHolder {
        TextView channelItemText;
    }

    private void unbindDrawables(View view) {

        try {
            if (view != null) {
               if (view.getBackground() != null) {
                   view.getBackground().setCallback(null);
               }

               if (view instanceof ViewGroup) {
                   for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                        unbindDrawables(((ViewGroup) view).getChildAt(i));
                   }

                   ((ViewGroup) view).removeAllViews();
               }
            }
        }
        catch (Exception e) {
            FmUtils.log(TAG,"some ViewGroups don't support the removeAllViews method");
        }
    }
}
