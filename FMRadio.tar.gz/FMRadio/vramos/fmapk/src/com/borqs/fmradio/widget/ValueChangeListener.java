package com.borqs.fmradio.widget;

public interface ValueChangeListener {
	void setValue(int value);
}
