package com.borqs.fmradio;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.borqs.fmradio.service.FmService;
import com.borqs.fmradio.service.FmService.FmServiceBinder;
import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class ChannelListActivity extends ListActivity 
	implements FmService.FmCallback {

	private ChannelAdapter mAdapter = new ChannelAdapter();
	private ListView mList;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		initActionBar();
		
		mAdapter.loadFreqs(this);
		
		mList = getListView();
		mList.setBackgroundResource(R.drawable.fm_list_bg);
		mList.setDivider(this.getResources().getDrawable(R.drawable.fm_list_line));
		
		mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent data = new Intent();
				int freq = (Integer)mAdapter.getItem(position);
				data.putExtra("freq", freq);
				ChannelListActivity.this.setResult(RESULT_OK, data);
				FmUtils.asyncSaveLastsFreq(freq, ChannelListActivity.this);
				finish();
			}
		});
		
		this.setListAdapter(mAdapter);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		log("onResume");
		bindService();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		log("onPause");
		cancelScan();
		unbindService();
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
    @Override 
    public boolean onCreateOptionsMenu(Menu menu) 
    { 
        MenuInflater inflater = getMenuInflater(); 
        inflater.inflate(R.layout.options_menu, menu); 
        return true; 
    }
    
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			return true;
			
		case R.id.scan_all: {
			showScanDialog();
			FmUtils.scanAll(mServiceBinder);
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
		
	}
	
	private ProgressDialog mScanDialog;
	private void showScanDialog() {
		mScanDialog = new ProgressDialog(this);
		mScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mScanDialog.setTitle(R.string.scanning);
		mScanDialog.setMessage(this.getString(R.string.scanning));
		mScanDialog.setIndeterminate(false);
		mScanDialog.setCancelable(false);
		mScanDialog.setButton(this.getString(R.string.cancel), new DialogInterface.OnClickListener(){   
            @Override  
            public void onClick(DialogInterface dialog, int which) {   
                cancelScan();
            }   
        });
		mScanDialog.show();
	}
	
	private void cancelScan() {
		FmUtils.scanAbort(mServiceBinder);
		if (mScanDialog != null) {
			mScanDialog.dismiss();
		}
		log("cancel Scan");
	}
    
	private void initActionBar() {
		ActionBar ab = this.getActionBar();
		ab.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.fm_titlebar_bg));
		ab.setHomeButtonEnabled(true);
		ab.setTitle(R.string.turn_back);
		ab.setIcon(R.drawable.fm_list_ic_return);
	}
	
	/*
	 * Service related
	 */
	private FmServiceBinder mServiceBinder;
	
	private ServiceConnection mConnection = new FmServiceConnection();
	
	private void bindService() {
		log("bindService");
    	Intent intent = new Intent().setClass(this, FmService.class);
    	this.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
	}
	
	private void unbindService() {
		log("unbindService");
		mServiceBinder.unregisterFmCallback(ChannelListActivity.this);
		unbindService(mConnection);
	}
	
	private class FmServiceConnection implements ServiceConnection {
		public void onServiceConnected(ComponentName className, IBinder service) {
			log("onServiceConnected");
			
			mServiceBinder = (FmServiceBinder)service;
			mServiceBinder.registerFmCallback(ChannelListActivity.this);
		}

		public void onServiceDisconnected(ComponentName className) {
			log("onServiceDisconnected");
		}
	};
	
	@Override
	public void onFmCallBack(Bundle b) {
		Message msg = mHandler.obtainMessage();
		msg.setData(b);
		msg.sendToTarget();
	}
	
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Bundle b = msg.getData();
			int resp = b.getInt(Consts.RESP_EXTRA);
			log("get resopnse: " + resp);
			switch (resp) {
			case Consts.RESP_CHANNEL_FREQ:
				float freq = b.getFloat(Consts.PARAM_0);
				log("get freq " + freq);
//				setFreq(freq, null, false);
				break;
				
			case Consts.RESP_SCAN_COMPLETE:
				ArrayList<Integer> freqs = (ArrayList<Integer>)b.getIntegerArrayList(Consts.PARAM_0);
				mAdapter.clear();
				mList.setAdapter(null);
				log("freqs.length = " + freqs.size());
				for (int i=0; i<freqs.size(); i++) {
					log("get channel: " + freqs.get(i));
					mAdapter.addFreq(freqs.get(i));
				}
				mList.setAdapter(mAdapter);
				mAdapter.saveFreqs(ChannelListActivity.this);
				
				if (mScanDialog != null) {
					mScanDialog.dismiss();
				}
				break;
				
			case Consts.RESP_SCAN_GOT_CHANNEL:
				int count = b.getInt(Consts.PARAM_0);
				String str = ChannelListActivity.this.getString(R.string.scan_got, count);
				mScanDialog.setMessage(str);
				break;
			}
		}
	};
	
	/*
	 * list adapter
	 */
	
	class ChannelAdapter implements ListAdapter {

		ArrayList<Integer> mFreqList = new ArrayList<Integer>();
		
		public void loadFreqs(Activity activity) {
			mFreqList.clear();
			mFreqList = FmUtils.loadChannelList(activity);
		}
		
		public void saveFreqs(Activity activity) {
			FmUtils.saveChannelList(mFreqList, activity);
		}
		
		public void addFreq(int freq) {
			mFreqList.add(freq);
		}
		
		public void clear() {
			mFreqList.clear();
		}
		
		@Override
		public int getCount() {
			return mFreqList.size();
		}

		@Override
		public Object getItem(int position) {
			if (position < 0 || position >= mFreqList.size()) {
				return null;
			}
			return mFreqList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public int getItemViewType(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = null;
			if (null == convertView) {
				LayoutInflater inflater = ChannelListActivity.this.getLayoutInflater();
				v = inflater.inflate(R.layout.channel_list_item, null);
			} else {
				v = convertView;
			}
			TextView tv = (TextView)v.findViewById(R.id.text);
			String text = String.valueOf(position+1) + "   "	 + 
					FmUtils.getFreqDisplay(mFreqList.get(position));
			log("text = " + text);
			tv.setText(text);
			
			return v;
		}

		@Override
		public int getViewTypeCount() {
			// TODO Auto-generated method stub
			return 1;
		}

		@Override
		public boolean hasStableIds() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isEmpty() {
			return mFreqList.size() == 0;
		}

		@Override
		public void registerDataSetObserver(DataSetObserver observer) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void unregisterDataSetObserver(DataSetObserver observer) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean areAllItemsEnabled() {
			// TODO Auto-generated method stub
			return true;
		}

		@Override
		public boolean isEnabled(int position) {
			// TODO Auto-generated method stub
			return true;
		}
		
	};
	
	private static void log(String msg) {
		FmUtils.log("ChannelListActivity, " + msg);
	}

}
