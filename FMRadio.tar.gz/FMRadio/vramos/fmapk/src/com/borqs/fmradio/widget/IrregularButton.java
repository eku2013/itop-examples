package com.borqs.fmradio.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Button;

public class IrregularButton extends Button {

	Bitmap mBitmap = null;
	
    public IrregularButton(Context context) {
    	super(context);
    	mBitmap = drawableToBitmap(getBackground());
    }

    public IrregularButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        mBitmap = drawableToBitmap(getBackground());
    }

    public IrregularButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mBitmap = drawableToBitmap(getBackground());
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
    	int x = (int)event.getX();
    	int y = (int)event.getY();
    	int action = event.getAction();
    	
    	if (x >= 0 && x < mBitmap.getWidth() 
    			&& y >= 0 && y < mBitmap.getHeight() 
    			&& mBitmap.getPixel(x, y)==0) {
    	
    		
    		if (MotionEvent.ACTION_MOVE == action) { // move out of button
    			event.setAction(MotionEvent.ACTION_UP);
    			super.onTouchEvent(event);
    		}
    		
    		return false;
    	}
    	
    	return super.onTouchEvent(event);
    }
    
    private static Bitmap drawableToBitmap(Drawable drawable) {  
    	if (null == drawable) {
    		return null;
    	}
    	
        // get drawable width and height 
        int w = drawable.getIntrinsicWidth();  
        int h = drawable.getIntrinsicHeight();  
  
        // get drawable color format  
        Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888  
                : Bitmap.Config.RGB_565;  
        // create corresponding bitmap  
        Bitmap bitmap = Bitmap.createBitmap(w, h, config);  
        // build bitmap canvas  
        Canvas canvas = new Canvas(bitmap);  
        drawable.setBounds(0, 0, w, h);  
        // draw drawable to canvas of bitmap  
        drawable.draw(canvas);  
        return bitmap;  
    }
}
