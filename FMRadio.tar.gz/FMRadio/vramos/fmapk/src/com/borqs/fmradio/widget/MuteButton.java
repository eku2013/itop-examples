package com.borqs.fmradio.widget;

import com.borqs.fmradio.utils.FmUtils;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

public class MuteButton extends Button implements ValueChangeListener {
	
	private int mVolume = 0;

    public MuteButton(Context context) {
        super(context, null);
    }

    public MuteButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    
	public MuteButton(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		
	}

	public void mute(int volume) {
		mVolume = volume;
		this.setActivated(true);
	}
	
	public int unmute() {
		this.setActivated(false);
		return mVolume;
	}
	
	public boolean isMute() {
		return this.isActivated();
	}
	
	@Override
	public void setValue(int value) {
		log("setValue, " + value);
		this.setActivated(value < 0.1);
		mVolume = value;
	}

    private static void log(String msg) {
    	FmUtils.log("MuteButton, " + msg);
    }
}
