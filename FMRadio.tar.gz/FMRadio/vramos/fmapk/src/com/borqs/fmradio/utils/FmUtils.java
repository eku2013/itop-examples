package com.borqs.fmradio.utils;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import com.borqs.fmradio.service.FmService.FmServiceBinder;

public class FmUtils {
	
	public static final int MAX_FREQ = 109000;
	public static final int MIN_FREQ = 85000;

	public static final String TAG = "FmRadio";
	public static boolean DEBUG = android.os.Build.TYPE.startsWith("user") ? Log
			.isLoggable(TAG, Log.DEBUG) : true;
			
	public static void log(String msg) {
		if (true) Log.d(TAG, msg);
	}
	
	public static int tidyFreq(int freq) {
		int ret = (int)Math.round(freq / 100) * 100;
		if (ret > MAX_FREQ) {
			ret = MAX_FREQ;
		} else if (ret < MIN_FREQ) {
			ret = MIN_FREQ;
		}
		return ret;
	}
	
	public static int tidyValue(int freq, int min, int scope) {
		int max = min + scope;
		int ret = freq;
		if (ret > max) {
			ret = max;
		} else if (ret < min) {
			ret = min;
		}
		log("tidyValue, ret = " + ret);
		return ret;
	}
	
	public static int freqToValue(int freq) {
		return freq - Consts.FREQ_DEVICE_BASE;
	}
	
	public static int valueToFreq(int value) {
		return tidyFreq(value + Consts.FREQ_DEVICE_BASE);
	}
	
	public static void setDeviceEnable(boolean turnTo, FmServiceBinder binder) {
		log("setDeviceEnable, turnTo = " + turnTo);
		Bundle b = new Bundle();
		if (turnTo) {
			b.putInt(Consts.CMD_EXTRA, Consts.CMD_START);
		} else {
			b.putInt(Consts.CMD_EXTRA, Consts.CMD_STOP);
		}
		binder.sendBundle(b);
	}
	
	public static void setDeviceMute(boolean turnTo, FmServiceBinder binder) {
		log("setDeviceMute, turnTo = " + turnTo);
		Bundle b = new Bundle();
		if (turnTo) {
			b.putInt(Consts.CMD_EXTRA, Consts.CMD_SET_MUTE);
		} else {
			b.putInt(Consts.CMD_EXTRA, Consts.CMD_SET_UNMUTE);
		}
		binder.sendBundle(b);
	}
	
	public static void closeDevice(FmServiceBinder binder) {
		log("closeDevice");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_CLOSE);
		binder.sendBundle(b);
	}
	
	public static void setDeviceFreq(int freq, FmServiceBinder binder) {
		log("setDeviceFreq");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_TUNE_FREQ);
		b.putInt(Consts.PARAM_0, freq);
		binder.sendBundle(b);
	}
	
	public static void getDeviceFreq(FmServiceBinder binder) {
		log("getDeviceFreq");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_GET_FREQ);
		binder.sendBundle(b);
	}
	
	public static void getDeviceVolume(FmServiceBinder binder) {
		log("getDeviceVolume");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_GET_VOLUME);
		binder.sendBundle(b);
	}
	
	public static void scanAll(FmServiceBinder binder) {
		log("scanAll");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SCAN_ALL);
		binder.sendBundle(b);
	}
	
	public static void scanAbort(FmServiceBinder binder) {
		log("scanAbort");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SCAN_ABORT);
		binder.sendBundle(b);
	}
	
	public static void searchForward(FmServiceBinder binder, int freq) {
		log("searchForward");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SCAN_NEXT);
		b.putInt(Consts.PARAM_0, freq);
		binder.sendBundle(b);
	}
	
	public static void searchBackward(FmServiceBinder binder, int freq) {
		log("searchForward");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SCAN_PREV);
		b.putInt(Consts.PARAM_0, freq);
		binder.sendBundle(b);
	}
	
	public static void getDevicePowerState(FmServiceBinder binder) {
		log("getDevicePowerState");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_GET_POWER_STATE);
		binder.sendBundle(b);
	}
	
	public static void saveLatestFreq(int freq, Context context) {
		SharedPreferences sp = context.getSharedPreferences(
				Consts.SP_NAME, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sp.edit();
		editor.putInt("latest_freq", freq);
		editor.commit();
	}
	
	public static void asyncSaveLastsFreq(final int freq, final Context context) {
		new Thread() {
			public void run() {
				saveLatestFreq(freq, context);
			}
		}.start();
	}
	
	public static void asyncSaveAndSetFreq(final int freq, 
			final Context context, final FmServiceBinder binder) {
		Thread t = new Thread() {
			public void run() {
				log("asyncSaveAndSetFreq thread");
				saveLatestFreq(freq, context);
				setDeviceFreq(freq, binder);
			}
		};
		t.setPriority(Thread.MIN_PRIORITY);
		t.start();
	}
	
	public static void saveAndSetFreq(final int freq, 
			final Context context, final FmServiceBinder binder) {
		saveLatestFreq(freq, context);
		setDeviceFreq(freq, binder);
	}
	
	public static int getLatestFreq(Context context) {
		SharedPreferences sp = context.getSharedPreferences(
				Consts.SP_NAME, Context.MODE_PRIVATE);
		return sp.getInt("latest_freq", 90000);
	}
	
//	public static int getVolume(Context context) {
//		AudioManager am = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
//		return am.getStreamVolume(AudioManager.STREAM_MUSIC);
//	}
	
	public static int getVolume(Context context) {
		SharedPreferences sp = context.getSharedPreferences(Consts.SP_NAME,
				Context.MODE_PRIVATE);
		return sp.getInt("volume", 20);
	}

	public static void saveVolume(int volume, Context context) {
		SharedPreferences sp = context.getSharedPreferences(Consts.SP_NAME,
				Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sp.edit();
		editor.putInt("volume", volume);
		editor.commit();
	}
	
	public static int getMaxVolume(Context context) {
		AudioManager am = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		return am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
	}
	
	public static int valueToVolume(int value) {
		return (int)((double)Consts.MAX_VOLUME * value / 256);
	}
	
	public static int volumeToValue(int volume) {
		return (int)((double)256 * volume / Consts.MAX_VOLUME);
	}
	
	public static void setDeviceVolume(int volume, FmServiceBinder binder) {
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SET_VOLUME);
		b.putInt(Consts.PARAM_0, volume);
		binder.sendBundle(b);
	}
	
	public static void setDeviceVolume(int volume, Handler workerHandler) {
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_SET_VOLUME);
		b.putInt(Consts.PARAM_0, volume);
		Message msg = workerHandler.obtainMessage(Consts.CMD_SET_VOLUME);
		msg.setData(b);
		msg.sendToTarget();
	}
	
	public static void setSystemVolume(int volume, Context context) {
		AudioManager am = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		log("setSystemVolume, volume = " + volume);
		am.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
	}
	
	public static int getSystemVolume(Context context) {
		AudioManager am = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		int volume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
		return volume;
	}
	
	public static void saveChannelList(ArrayList<Integer> freqs, Activity activity) {
		int count = freqs.size();
		SharedPreferences sp = activity.getSharedPreferences(
				Consts.SP_NAME, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sp.edit();
		editor.putInt("channel_count", count);
		for (int i=0; i<count; i++) {
			editor.putInt("channel_" + i, freqs.get(i));
		}
		editor.commit();
	}
	
	public static ArrayList<Integer> loadChannelList(Activity activity) {
		SharedPreferences sp = activity.getSharedPreferences(
				Consts.SP_NAME, Context.MODE_PRIVATE);
		int count = sp.getInt("channel_count", 0);
		ArrayList<Integer> freqs = new ArrayList<Integer>(count);
		
		for (int i=0; i<count; i++) {
			freqs.add(sp.getInt("channel_" + i, -1));
		}
		
		return freqs;
	}
	
	/*
	 * portrait or landscape
	 */
	public static boolean isPortrait(Context context) {
		Display display = ((WindowManager) context
				.getSystemService(context.WINDOW_SERVICE)).getDefaultDisplay();
		int orientation = display.getOrientation();
		log("isPortrait: " + orientation);
		return ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE != orientation
				&& ActivityInfo.SCREEN_ORIENTATION_USER != orientation;
	}
	
	public static boolean isHeadsetPluged(Context context) {
		boolean ret = false;
		AudioManager am = (AudioManager)context.getSystemService(Activity.AUDIO_SERVICE);
		ret = am.isWiredHeadsetOn();
		log("isHeadsetPluged: " + ret);
        return ret;
	}
	
	public static String getFreqDisplay(int freq) {
		return String.format("%.1fMHz", (float)freq/1000);
	}
	
}
