package com.borqs.fmradio.service;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;

import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class FmService extends Service {
	
	private static final int SHOW_PROMPT_DIALOG = 20;
	
	private static final int CMD_DELAY = 0;
	
	private static AlertDialog mPromptDialog = null;
	
	private static boolean mInited = false;
	
	private ArrayList<FmCallback> mCallbacks = new ArrayList<FmCallback>();
	private FmServiceBinder mBinder = null;
	private Handler mWorkHandler;
	private HandlerThread mWorkThread;
	private Handler mMainThreadHandler;
	private HandlerThread mCmdLineThread;
	private Handler mCmdLineHandler;
	private FmHeadsetMonitor mHeadsetMonitor;
	private FmAudioControler mAudioCtler;
	private Object mLock;
	
	public interface FmCallback {
		void onFmCallBack(Bundle b);
	}
	
	void invokeCallback(Bundle b) {
		log("invokeCallback: " + mCallbacks.size() + " callbacks");
		for (FmCallback cb: mCallbacks) {
			log("call: " + cb.getClass().getName());
			cb.onFmCallBack(b);
		}
	}
	
	private void promptPlugHeadset(Context context) {
		log("promptPlugHeadset");
		DialogInterface.OnClickListener l = new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (mBinder != null) {
					closeFmRadio();
				}
			}
		};
		
		if (null == mPromptDialog) {
			log("mPromptDialog is null");
			mPromptDialog = new AlertDialog.Builder(context)
					.setTitle(R.string.headset_missing)
					.setMessage(context.getResources().getString(R.string.headset_missing_tip))
					.setIcon(R.drawable.fm)
					.setNegativeButton(R.string.quit, l)
					.create();
			mPromptDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
			mPromptDialog.setCancelable(false);
		}
		
		if (!mPromptDialog.isShowing()) {
			log("show mPromptDialog");
			mPromptDialog.show();
		}
	}
	
	@Override
    public void onCreate() {
		log("onCreate, mInited = " + mInited);
		
		Consts.MAX_VOLUME = FmUtils.getMaxVolume(this);
		
		mBinder = new FmServiceBinder();
		
		mLock = new Object();
		
		if (null == mWorkThread) {
			mWorkThread = new HandlerThread("FmServiceHandler");
			mWorkThread.start();
		}
		
		if (null == mWorkHandler) {
			mWorkHandler = new FmWorkerHandler(mWorkThread.getLooper(), this, mLock);
		}
		
		if (null == mMainThreadHandler) {
			mMainThreadHandler = new Handler() {
				public void handleMessage (Message msg) {
					log("mMainThreadHandler, " + msg.what);
					switch (msg.what) {
						
					case Consts.HEADSET_LOST:
						FmUtils.setDeviceMute(true, mBinder);
						promptPlugHeadset(FmService.this);
						break;
						
					case Consts.HEADSET_PLUGED:
						FmUtils.setDeviceMute(false, mBinder);
						if (mPromptDialog != null && mPromptDialog.isShowing()) {
							mPromptDialog.dismiss();
						}
						break;
					}
				}
			};
		}
		
		if (null == mCmdLineThread) {
			mCmdLineThread = new HandlerThread("FmCmdLineThread");
			mCmdLineThread.start();
		}
		if (null == mCmdLineHandler) {
			mCmdLineHandler = new FmCmdLineHandler(mCmdLineThread.getLooper(), mWorkHandler, mLock);
		}
		
		mHeadsetMonitor = new FmHeadsetMonitor(this, mMainThreadHandler);
		mAudioCtler = new FmAudioControler(this, mWorkHandler);
		
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_GET_POWER_STATE);
		Message msg = mWorkHandler.obtainMessage();
		msg.setData(b);
		msg.sendToTarget();
		
    }
	
	@Override
    public void onDestroy() {
		log("onDestroy");
    }
	
	@Override
	public IBinder onBind(Intent intent) {
		log("onBind");
		
		if (null == mBinder) {
			mBinder = new FmServiceBinder();
		}

		return mBinder;
	}
	
	@Override
    public void onRebind(Intent intent) {
		log("onRebind");
    }
	
	@Override
    public boolean onUnbind(Intent intent) {
		log("onUnbind");
//		reflect_changeApplicationBluetoothState(false);
        return false;
    }
	
	boolean startMonitorHeadsetAndVolume() {
		boolean ret = false;
		if (mHeadsetMonitor != null) {
			mHeadsetMonitor.startCheckHeadset();
		}
		
		if (mAudioCtler != null) {
			ret = mAudioCtler.requestAudioFocus();
		}
		
		return ret;
	}
	
	boolean stopMonitorHeadsetAndVolume() {
		boolean ret = false;
		if (mHeadsetMonitor != null) {
			mHeadsetMonitor.stopCheckHeadset();
		}
		
		if (mAudioCtler != null) {
			ret = mAudioCtler.releaseAudioFocus();
		}
		return ret;
	}
	
	private int mPendingCmd = -1;
	public class FmServiceBinder extends Binder {
		
		public void sendBundle(Bundle b) {
			
			int cmd = b.getInt(Consts.CMD_EXTRA);
			
			Message msg = mWorkHandler.obtainMessage(cmd);
			msg.setData(b);
			if (mWorkHandler.hasMessages(cmd)) {
				mWorkHandler.removeMessages(cmd);
			}
			
			int delay = CMD_DELAY;
			
			switch (cmd) {
			case Consts.CMD_SET_VOLUME:
				mAudioCtler.setValue(b);
				break;
				
			case Consts.CMD_START:
				if (!FmUtils.isHeadsetPluged(FmService.this)) {
					promptPlugHeadset(FmService.this);
					break;
				}
				setUiPowerOn(true);
				// do not break;
			default:
				mWorkHandler.sendMessageDelayed(msg, CMD_DELAY);
				break;
			}
		}
		
		public void registerFmCallback(FmCallback fec) {
			log("registerFmCallback, fec = " + fec);
			if (fec != null) {
				mCallbacks.add(fec);
			}
		}
		
		public void unregisterFmCallback(FmCallback fec) {
			log("unregisterFmCallback");
			if (fec != null) {
				mCallbacks.remove(fec);
			}
		}
	}
	private void setUiPowerOn(boolean on) {
		Bundle bb = new Bundle();
		bb.putInt(Consts.RESP_EXTRA, Consts.RESP_POWER_STATE);
		if (on) {
			bb.putInt(Consts.PARAM_0, Consts.DEVICE_ON);
		} else {
			bb.putInt(Consts.PARAM_0, Consts.DEVICE_OFF);
		}
		invokeCallback(bb);
	}
	/*
	 * BlueTooth chip
	 */
	
    private void reflect_changeApplicationBluetoothState(boolean tureOn) {
    	BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    	
    	try {
	    	Class<?> c_BluetoothStateChangeCallback = Class.forName(
	    			"android.bluetooth.BluetoothAdapter$BluetoothStateChangeCallback");
	    	
	    	Class<?> intes[] = c_BluetoothStateChangeCallback.getInterfaces();
	    	for (int i=0; i<intes.length; i++) {
	    		log("interface: " + intes[i].getName());
	    	}
	    	
	    	Method method = BluetoothAdapter.class.getMethod(
	    			"changeApplicationBluetoothState",
	    			boolean.class,
	    			c_BluetoothStateChangeCallback);
	    	
	    	Object interfaceObject = Proxy.newProxyInstance(c_BluetoothStateChangeCallback.getClassLoader(),
	                new Class[] {c_BluetoothStateChangeCallback}, new ProxyListener());
	    	
	    	method.invoke(bluetoothAdapter, tureOn, interfaceObject);
    	
    	} catch (Exception ex) {
    		log("reflect_changeApplicationBluetoothState, " + ex);
    		ex.printStackTrace();
    	}
    	
    }
    
	public class ProxyListener implements java.lang.reflect.InvocationHandler {

		public ProxyListener() {

		}

		public Object invoke(Object proxy, Method m, Object[] args)
				throws Throwable {

			Object result = null;
			try {

				if (m.getName().equals("onBluetoothStateChange")) {
					result = myMethod(args[0]);
				}
			} catch (Exception e) {
				throw new RuntimeException("unexpected invocation exception: " +
				e.getMessage());

			} finally {
				System.out.println("end method " + m.getName());
			}

			return result;
		}
		
		Object myMethod(Object arg) {
			boolean on = (Boolean)arg;
            log("onBluetoothStateChange on: " + on);
            if (on) {
            	// [TODO] open the comments if need init bluetooth
//        		int ret = FMNative.fm_init(fmCallbacks);
//        		log("FMNative.fm_init return " + ret);
            }
            
            return null;
		}
	}
	
	void closeFmRadio() {
		log("closeFmRadio");
		FmUtils.closeDevice(mBinder);
		Bundle b = new Bundle();
		b.putInt(Consts.RESP_EXTRA, Consts.RESP_CLOSE);
		invokeCallback(b);
	}
	
	void setDeviceVolume(int volume) {
		FmUtils.setDeviceVolume(volume, mBinder);
	}
	
	void setUiVolume() {
		log("setUiVolume");
		int value = mAudioCtler.getCurrentValue();
		mAudioCtler.setValue(value, false, false, true);
	}
	
	private static void log(String msg) {
		FmUtils.log("FmService: " + msg);
	}
}
