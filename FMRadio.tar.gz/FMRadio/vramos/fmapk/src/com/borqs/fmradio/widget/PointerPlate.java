package com.borqs.fmradio.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.FmUtils;

public class PointerPlate extends DialPlate {

	private Bitmap mPointerBitmap = null;
	
	private float mCurrentDegree = super.mDegree;
	private float mStepDegree = 20f;
	
	public PointerPlate(Context context) {
		super(context);
	}
	
	public PointerPlate(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
	
	public PointerPlate(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FmView);
		
		Drawable pointerDra = a.getDrawable(R.styleable.FmView_pointer_res);
		mPointerBitmap = ((BitmapDrawable)pointerDra).getBitmap();
	}
	
	@Override
	void onChange(float degree) {
		log("onChange, degree = " + degree);
		mSettingValue = false;
		this.invalidate();
	}
	
	@Override
	void onMove(float degree) {
		log("onMove, degree = " + degree);
		mSettingValue = true;
		this.invalidate();
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		
		boolean needContunue = true;
		canvas.save();
		
		float x = - super.mRadius;
		float y = - mPointerBitmap.getHeight() / 2;
		
		log("onDraw, x = " + x + ", y = " + y);
		
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		
		canvas.translate(super.mAxesX, super.mAxesY);
		
		float degree;

		if (Math.abs(mCurrentDegree - super.mDegree) < mStepDegree) {
			degree = super.mDegree;
			needContunue = false;
		} else {
			degree = mCurrentDegree > super.mDegree ? mCurrentDegree - mStepDegree : mCurrentDegree + mStepDegree;
		}
		
//		log("onDraw, degree = " + degree);
		
		canvas.rotate(degree + super.mBaseDegree);

		canvas.drawBitmap(mPointerBitmap, x, y, paint);

		canvas.restore();
		
		mCurrentDegree = degree;
		
		log("mListener = " + mListener + ", mIsMoving = " + mIsMoving + ", mSettingValue = " + mSettingValue);
		if (needContunue) {
			this.invalidate();
		} else if (mListener != null && !mIsMoving && !mSettingValue) {
			mListener.onValueChanged(mValue);
		}
		
		if (mSettingValue && !needContunue) {
			mSettingValue = false;
		}
	}

	private static void log(String msg) {
		FmUtils.log("PointerPlate, " + msg);
	}
}
