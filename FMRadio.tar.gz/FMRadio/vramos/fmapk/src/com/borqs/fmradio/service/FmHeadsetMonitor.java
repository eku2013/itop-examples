package com.borqs.fmradio.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;

import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class FmHeadsetMonitor extends BroadcastReceiver {
	
	private boolean sIsRegisted = false;
	private Context mContext;
	private Handler mHandler;
	
	public FmHeadsetMonitor(Context context, Handler handler) {
		mContext = context;
		mHandler = handler;
	}
	
	public void startCheckHeadset() {
		log("startCheckHeadset, sIsRegisted = " + sIsRegisted);
		if (!sIsRegisted) {
			mContext.registerReceiver(this, mIntentFilter);
			sIsRegisted = true;
		}
		
		if (!FmUtils.isHeadsetPluged(mContext)) {
			mHandler.sendEmptyMessage(Consts.HEADSET_LOST);
		}
		
	}
	
	public void stopCheckHeadset() {
		log("stopCheckHeadset, sIsRegisted = " + sIsRegisted);
		if (sIsRegisted) {
			try {
				mContext.unregisterReceiver(this);
				sIsRegisted = false;
			} catch (IllegalArgumentException ex) {
				// dons't matter
			}
		}
	}
	
	private static IntentFilter mIntentFilter =
			new IntentFilter(Intent.ACTION_HEADSET_PLUG);

	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		log("onReceive: action = " + action);
		if (Intent.ACTION_HEADSET_PLUG.equals(action)) {
			int pluged = intent.getIntExtra("state", 0);
			log("head set is pluged: " + pluged);
			if (0 == pluged) {
				mHandler.sendEmptyMessage(Consts.HEADSET_LOST);
			} else {
				mHandler.sendEmptyMessage(Consts.HEADSET_PLUGED);
			}
		}
	}
	
	private static void log(String msg) {
		FmUtils.log("FmHeadsetMonitor: " + msg);
	}
}
