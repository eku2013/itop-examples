package com.borqs.fmradio;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.borqs.fmradio.utils.FmUtils;
import com.borqs.fmradio.widget.ValueChangeListener;

public class FaveriteListManager implements ValueChangeListener {

	int[] mFaverFreqs = new int[12];
	MainActivity mActivity = null;
	ArrayList<View> mViewList = new ArrayList<View>();
	OnChannelActivatedListenner mListenner = null;
	private int mCurActived = -1;
	
	public interface OnChannelActivatedListenner {
		void onChannelActivated(int freq);
	}
	
	public void setOnChannelActivatedListenner(OnChannelActivatedListenner l) {
		mListenner = l;
	}
	
	public FaveriteListManager(Activity a) {
		if (null == a) {
			return;
		}
		mActivity = (MainActivity)a;
		getFaveriteFreqs();
    	initViews();
	}
	
	@Override
	public void setValue(int freq) {
		log("setValue, " + freq);
		
		if (mCurActived != -1 && freq == mFaverFreqs[mCurActived]) {
			return;
		}
		
		for (int i=0; i<mFaverFreqs.length; i++) {
//			log("mFaverFreqs[" + i + "] = " + mFaverFreqs[i]);
//			log("delta = " + Math.abs(freq - mFaverFreqs[i]));
			if (freq == mFaverFreqs[i]) {
				log("match");
				switchActived(mViewList.get(i), false);
				return;
			}
		}
		
		switchActived(null, false);
	}
	
	private void initHalfFaveriteList(boolean left, ViewGroup list, LayoutInflater inflater) {
		String name;
		int paddingRight;
		if (left) {
			name = "fm_list_left";
			paddingRight = 200;
		} else {
			name = "fm_list_right";
			paddingRight = 30;
		}
		for (int i=1; i<=6; i++) {
			View item = inflater.inflate(R.layout.faverite_list_item, null);
			int resid = mActivity.getResources().getIdentifier(
					name + "_" + i + "_selector", "drawable", "com.borqs.fmradio");
			item.setBackgroundResource(resid);
			item.setPadding(0, 0, paddingRight, 0);
			list.addView(item);
			mViewList.add(item);
		}
	}
	
	private void initWholeFaveriteList(LayoutInflater inflater) {
		ListView listView = (ListView)mActivity.findViewById(R.id.faverite_list);
		
		for (int i=0; i<12; i++) {
			mViewList.add(inflater.inflate(R.layout.faverite_list_item, null));
		}
		
		listView.setAdapter(new FaveriteListAdapter(mViewList));
	}
	
	private void getFaveriteFreqs() {
		SharedPreferences sp = mActivity.getSharedPreferences(
				"Consts.SP_NAME", Context.MODE_PRIVATE);
		for (int i=0; i<12; i++) {
			mFaverFreqs[i] = sp.getInt(String.valueOf(i), -1);
		}
	}
	
	private void initViews() {
		
		LayoutInflater inflater = mActivity.getLayoutInflater();
		
		if (FmUtils.isPortrait(mActivity)) {
			LinearLayout leftList = (LinearLayout)mActivity.findViewById(R.id.left_list);
			LinearLayout rightList = (LinearLayout)mActivity.findViewById(R.id.right_list);
			
			initHalfFaveriteList(true, leftList, inflater);
			initHalfFaveriteList(false, rightList, inflater);
			
		} else {
			initWholeFaveriteList(inflater);
			
		}
    	
		for (int i=0; i<mViewList.size(); i++) {
			View v = mViewList.get(i);
			
			int freq = mFaverFreqs[i];
			v.setTag(new ItemTag(i, freq));
			
			String text;
			if (-1 == freq) {
				text = "    +       ";
			} else {
				text = FmUtils.getFreqDisplay(freq);
			}
			((TextView)v).setText(text);
			
			v.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					
					if (mViewList.indexOf(v) == mCurActived) {
						return;
					}
					
					ItemTag tag = (ItemTag)v.getTag();
					
					if (-1 == tag.mFreq) {
						tag.mFreq = mActivity.getFreq();
						setFaveriteFreq(tag.mIndex, mActivity.getFreq());
						((Button)v).setText(FmUtils.getFreqDisplay(tag.mFreq));
					}
					
					switchActived(v, true);
				}
			});
			
			v.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					ItemTag tag = (ItemTag)v.getTag();
					
					tag.mFreq = mActivity.getFreq();
					
					setFaveriteFreq(tag.mIndex, tag.mFreq);
					
					((Button)v).setText(FmUtils.getFreqDisplay(tag.mFreq));
					
					switchActived(v, true);
					
					return true;
				}
			});
		}
	}
	
	private void switchActived(View v, boolean notify) {
		if (null == v) {
			if (mCurActived != -1) {
				mViewList.get(mCurActived).setActivated(false);
				mCurActived = -1;
			}
			return;
		}
		
		ItemTag tag = (ItemTag)v.getTag();
		log("switchActived, freq = " + tag.mFreq + ", index = " + tag.mIndex + ", notify = " + notify);
		
		if (mCurActived == tag.mIndex) {
			return;
		}
		
		if (mCurActived != -1) {
			mViewList.get(mCurActived).setActivated(false);
		}
		mCurActived = tag.mIndex;
		
		v.setActivated(true);
		
		if (notify && mListenner != null) {
			mListenner.onChannelActivated(tag.mFreq);
		}
	}
	
	private void setFaveriteFreq(int index, int freq) {
		mFaverFreqs[index] = freq;
		SharedPreferences sp = mActivity.getSharedPreferences(
				"Consts.SP_NAME", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sp.edit();
		editor.putInt(String.valueOf(index), freq);
		editor.commit();
	}
	
	private class ItemTag {
		public ItemTag(int index, int freq) {
			mIndex = index;
			mFreq = freq;
		}
		public int mIndex = -1;
		public int mFreq = -1;
	}
	
    private static void log(String msg) {
    	FmUtils.log("FaveriteListManager, " + msg);
    }
}
