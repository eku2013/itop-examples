package com.borqs.fmradio.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;

import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class FmAudioControler extends BroadcastReceiver {

	private FmService mService;
	boolean mRegistered = false;
	private static int mCurSysVol = -1;
	private static int mCurValue = -1;
	private Handler mWorkerHandler;
	
    /**
     * following value defined in AudioManager and be hid.
     */
	public static final String VOLUME_CHANGED_ACTION = 
			"android.media.VOLUME_CHANGED_ACTION";
	
	public static final String EXTRA_VOLUME_STREAM_TYPE = 
			"android.media.EXTRA_VOLUME_STREAM_TYPE";
	
	public static final String EXTRA_VOLUME_STREAM_VALUE =
	        "android.media.EXTRA_VOLUME_STREAM_VALUE";
	
	public static final String EXTRA_PREV_VOLUME_STREAM_VALUE =
	        "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE";
	
	private static IntentFilter mIntentFilter =
			new IntentFilter(VOLUME_CHANGED_ACTION);
	
	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		log("onReceive, " + action);
		if (VOLUME_CHANGED_ACTION.equals(action)) {
			int type = intent.getIntExtra(EXTRA_VOLUME_STREAM_TYPE, -1);
			if (AudioManager.STREAM_MUSIC == type) {
				int volume = intent.getIntExtra(EXTRA_VOLUME_STREAM_VALUE, -1);
				log("get VOLUME_CHANGED_ACTION volume = " + volume + ", mCurSysVol = " + mCurSysVol);
				if (volume >= 0 && mCurSysVol != volume) {
					setVolume(volume, true, false, true);
				}
			}
		}
	}
	
	public void setVolume(int volume, boolean setDevice, boolean setSys, boolean setUi) {
		log("setVolume, " + volume + " " 
				+ (setDevice ? "setDevice " : "")
				+ (setSys ? "setSys " : "")
				+ (setUi ? "setUi" : ""));
		
		mCurValue = FmUtils.volumeToValue(volume);
		mCurSysVol = volume;
	
		if (setUi) {
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_GET_VOLUME);
			b.putInt(Consts.PARAM_0, mCurValue);
			mService.invokeCallback(b);
		}
		
		if (setDevice) {
			FmUtils.setDeviceVolume(mCurValue, mWorkerHandler);
		}
		
		if (setSys) {
			FmUtils.setSystemVolume(volume, mService);
		}
	}
	
	public void setValue(int value, boolean setDevice, boolean setSys, boolean setUi) {
		log("setValue, " + value + " " 
				+ (setDevice ? "setDevice " : "")
				+ (setSys ? "setSys " : "")
				+ (setUi ? "setUi" : ""));
		
		mCurValue = value;
		
		if (setUi) {
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_GET_VOLUME);
			b.putInt(Consts.PARAM_0, mCurValue);
			mService.invokeCallback(b);
		}
		
		if (setDevice) {
			FmUtils.setDeviceVolume(mCurValue, mWorkerHandler);
		}
		
		if (setSys) {
			int volume = FmUtils.valueToVolume(value);
			mCurSysVol = volume;
			FmUtils.setSystemVolume(volume, mService);
		}
	}
	
	public void setValue(Bundle b) {
		int value = b.getInt(Consts.PARAM_0);
		setValue(value, true, true, false);
	}
	
	public FmAudioControler(FmService service, Handler workerHandler) {
		mService = service;
		mCurSysVol = FmUtils.getSystemVolume(mService);
		mCurValue = FmUtils.volumeToValue(mCurSysVol);
		mWorkerHandler = workerHandler;
	}
	
	private AudioManager.OnAudioFocusChangeListener mAudioFocusChangeListener = 
			new AudioManager.OnAudioFocusChangeListener() {
		@Override
		public void onAudioFocusChange(int focusChange) {
			log("onAudioFocusChange: " + focusChange);
			if (focusChange < 0) {
				mService.closeFmRadio();
			}
		}
	};
	
	boolean requestAudioFocus() {
		log("requestAudioFocus");
		boolean ret = false;
		AudioManager am = (AudioManager)mService.getSystemService(Context.AUDIO_SERVICE);
		ret = (AudioManager.AUDIOFOCUS_REQUEST_GRANTED 
				== am.requestAudioFocus(
						mAudioFocusChangeListener, 
						AudioManager.STREAM_MUSIC, 
						AudioManager.AUDIOFOCUS_GAIN));
		if (ret && !mRegistered) {
			mService.registerReceiver(this, mIntentFilter);
			mRegistered = true;
		}
		
		int volume = FmUtils.getSystemVolume(mService);
		mCurSysVol = volume;
		setVolume(volume, true, false, true);
		
		log("requestAudioFocus return " + ret);
		return ret;
	}
	
	boolean releaseAudioFocus() {
		log("releaseAudioFocus");
		boolean ret = false;
		AudioManager am = (AudioManager)mService.getSystemService(Context.AUDIO_SERVICE);
		ret = (AudioManager.AUDIOFOCUS_REQUEST_GRANTED
				== am.abandonAudioFocus(mAudioFocusChangeListener));
		if (ret && mRegistered) {
			mService.unregisterReceiver(this);
			mRegistered = false;
		}
		log("releaseAudioFocus return " + ret);
		return ret;
	}
	
	int getCurrentValue() {
		log("getCurrentValue, " + mCurValue);
		return mCurValue;
	}

	private static void log(String msg) {
		FmUtils.log("AudioControler: " + msg);
	}
	
}
