package com.borqs.fmradio;

import android.app.Activity;
import android.os.Bundle;

import com.borqs.fmradio.service.FMNative;
import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class test extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
//		ServiceUtils.setFmRxMode(this, Consts.MODE_FM_ON);
		
		FMNative.fm_init(fmCallbacks);
		FMNative.fm_func_on();
		FMNative.fm_set_snr_threshold(0);
		FMNative.fm_auto_search(1, 23000, 50);
	}
	
	
	private FMNative.fm_callbacks fmCallbacks = new FMNative.fm_callbacks() {

		@Override
		public void fm_get_region_tune_mode_callback(int param) {
			log("fm_get_region_tune_mode_callback, param = " + param);
		}

		@Override
		public void fm_get_channel_freq_callback(int param) {
			log("fm_get_channel_freq_callback, param = " + param);
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_CHANNEL_FREQ);
			float freq = FmUtils.valueToFreq(param);
			b.putFloat(Consts.PARAM_0, freq);
//			invokeCallback(b);
		}

		@Override
		public void fm_get_current_rssi_callback(int param) {
			log("fm_get_current_rssi_callback, param = " + param);
		}

		@Override
		public void fm_get_current_snr_callback(int param) {
			log("fm_get_current_snr_callback, param = " + param);
		}

		@Override
		public void fm_get_search_steps_callback(int param) {
			log("fm_get_search_steps_callback, param = " + param);
		}

		@Override
		public void fm_get_mute_state_callback(int param) {
			log("fm_get_mute_state_callback, param = " + param);
		}

		@Override
		public void fm_get_volume_gain_callback(int param) {
			log("fm_get_volume_gain_callback, param = " + param);
		}

		@Override
		public void fm_get_preset_channels_callback(int values[]) {
			log("fm_get_preset_channels_callback");
			int length = values.length;
			float freqs[] = new float[length];
			
			for (int i=0; i<length; i++) {
				freqs[i] = FmUtils.valueToFreq(values[i]);
				log("1. " + freqs[i] + "MHz");
			}
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_SCAN_COMPLETE);
			b.putFloatArray(Consts.PARAM_0, freqs);
		}

		@Override
		public void fm_get_search_rssi_threshold_callback(int param) {
			log("fm_get_search_rssi_threshold_callback, param = " + param);
		}

		@Override
		public void fm_get_snr_threshold_callback(int param) {
			log("fm_get_snr_threshold_callback, param = " + param);
		}

		@Override
		public void fm_get_stereo_mono_status_callback(int param) {
			log("fm_get_stereo_mono_status_callback, param = " + param);
		}

		@Override
		public void fm_get_power_state_callback(int state) {
			// TODO Auto-generated method stub
			
		}
		
	};
	
	private static void log(String msg) {
		FmUtils.log("test: " + msg);
	}
}
