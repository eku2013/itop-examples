package com.borqs.fmradio;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.borqs.fmradio.FaveriteListManager.OnChannelActivatedListenner;
import com.borqs.fmradio.service.FmService;
import com.borqs.fmradio.service.FmService.FmServiceBinder;
import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;
import com.borqs.fmradio.widget.IrregularButton;
import com.borqs.fmradio.widget.LightCross;
import com.borqs.fmradio.widget.MuteButton;
import com.borqs.fmradio.widget.Nixietube;
import com.borqs.fmradio.widget.PointerPlate;
import com.borqs.fmradio.widget.ValueChangeListener;
import com.borqs.fmradio.widget.VolumePlate;

public class MainActivity extends Activity 
	implements FmService.FmCallback, OnChannelActivatedListenner{
	
	private ServiceConnection mConnection = new FmServiceConnection();
	private FmServiceBinder mServiceBinder;
	
	private ArrayList<ValueChangeListener> mVolumeListener = new ArrayList<ValueChangeListener>();
	private ArrayList<ValueChangeListener> mFreqListener = new ArrayList<ValueChangeListener>();
	
	/*
	 * Activity calss override
	 * (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		log("onCreate");
		
		this.startService(new Intent().setClass(this, FmService.class));
		setContentView(R.layout.main_activity);
		
		initActionBar();
		initView();

	}
	
	@Override
	public void onResume() {
		super.onResume();
		log("onResume");
		bindService();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		log("onPause");
		unbindService();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		FmUtils.saveLatestFreq(getFreq(), this);
		log("onDestroy");
	}
	
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		log("onActivityResult, resultCode = " + resultCode);
		if (Activity.RESULT_OK == resultCode) {
			int freq = data.getIntExtra("freq", -1);
			log("freq = " + freq);
			if (freq != -1) {
				setFreq(freq, null, true);
			}
		}
    }
	
	/*
	 * public method
	 */

	public int getFreq() {
		int freq = FmUtils.tidyFreq(mChannelPlate.getValue());
		return freq;
	}
	
	public void setVolume(int volume, Object caller, boolean changeDevice) {
		log("setVolume: " + volume);
		
		for (ValueChangeListener l: mVolumeListener) {
			if (l != caller) {
				l.setValue(volume);
			}
		}
		
		if (changeDevice) {
			FmUtils.setDeviceVolume(volume, mServiceBinder);
		}
	}
	
	public int getVolume() {
		return mVolumePlate.getValue();
	}
	
	/*
	 * UI, views related method
	 */
	
	private Nixietube mNixietube;
	private PointerPlate mChannelPlate;
	private VolumePlate mVolumePlate;
	private FaveriteListManager mFaveriteManager;
	private IrregularButton mMoveForward;
	private IrregularButton mMoveBackward;
	private IrregularButton mSearchForward;
	private IrregularButton mSearchBackward;
	private IrregularButton mShowList;
	private MuteButton mVolumeMute;
	private Button mVolumeUp;
	private Button mVolumeDown;
	private LightCross mLightCross;
	private IrregularButton mOnOffButton;
	private IrregularButton mShutter;
	
	private void initView() {
		
		mShutter = (IrregularButton)findViewById(R.id.shutter);
		mShutter.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
			}
		});
		
		mFaveriteManager = new FaveriteListManager(this);
		mFreqListener.add(mFaveriteManager);
		mFaveriteManager.setOnChannelActivatedListenner(this);
		
		mMoveForward = (IrregularButton)findViewById(R.id.move_forward);
		mMoveForward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int freq = getFreq();
				log("getFreq() = " + freq);
				freq = FmUtils.tidyFreq(freq + 100);
				log("freq + 100 = " + freq);
				setFreq(freq, mMoveForward, true);
			}
		});
		
		mMoveBackward = (IrregularButton)findViewById(R.id.move_backward);
		mMoveBackward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int freq = getFreq();
				log("getFreq() = " + freq);
				freq = FmUtils.tidyFreq(freq - 100);
				log("freq - 100 = " + freq);
				setFreq(freq, mMoveBackward, true);
			}
		});
		
		mSearchForward = (IrregularButton)findViewById(R.id.search_forward);
		mSearchForward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				FmUtils.searchForward(mServiceBinder, getFreq());
			}
		});
		
		mSearchBackward = (IrregularButton)findViewById(R.id.search_backward);
		mSearchBackward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				FmUtils.searchBackward(mServiceBinder, getFreq());
			}
		});
		
		mLightCross = (LightCross)findViewById(R.id.light_cross);
		if (mLightCross != null) {
			mLightCross.setMainLooper(this.getMainLooper());
		}
		
		mOnOffButton = (IrregularButton)findViewById(R.id.on_off);
		mOnOffButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean turnTo = !mOnOffButton.isActivated();
				
				// if turn off, the ui can be switch directly
				// but if turn on, the headset should be check firstly by 
				// fmservice, and service will send message to notify the 
				// activity to switch ui.
				if (!turnTo) {
					setOnOffUI(turnTo);
				}
				FmUtils.setDeviceEnable(turnTo, mServiceBinder);
			}
		});
		mOnOffButton.setActivated(false);
		
		mChannelPlate = (PointerPlate)findViewById(R.id.channel_plate);
		mFreqListener.add(mChannelPlate);
		mChannelPlate.setOnDegreeChangedListener(new PointerPlate.OnDegreeChangedListener() {
			@Override
			public void onValueChanging(int value) {
//				setFreq(value, mChannelPlate, false);
			}
			@Override
			public void onValueChanged(int value) {
				setFreq(value, mChannelPlate, true);
			}
			
		});
		
		mNixietube = (Nixietube)findViewById(R.id.nixie_tube);
		mFreqListener.add(mNixietube);
		
		IrregularButton btnExit = (IrregularButton)findViewById(R.id.btn_exit);
		btnExit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				FmUtils.closeDevice(mServiceBinder);
				setOnOffUI(false);
				finish();
			}
		});
		
		mShowList = (IrregularButton)findViewById(R.id.btn_list);
		mShowList.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, ChannelListActivity.class);
				MainActivity.this.startActivityForResult(intent, 0);
			}
		});
		
		mVolumePlate = (VolumePlate)findViewById(R.id.volume_plate);
		mVolumeListener.add(mVolumePlate);
		mVolumePlate.setOnDegreeChangedListener(new VolumePlate.OnDegreeChangedListener() {
			@Override
			public void onValueChanging(int value) {
				log("mVolumePlate, onValueChanging " + value);
				setVolume(value, mVolumePlate, true);
			}
			@Override
			public void onValueChanged(int value) {
				log("mVolumePlate, onValueChanged " + value);
				setVolume(value, mVolumePlate, true);
			}
			
		});
		
		mVolumeDown = (Button)findViewById(R.id.volume_down);
		mVolumeDown.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int volume = mVolumePlate.getValue() - 1;
				log("volume = " + volume);
				setVolume(volume, v, true);
			}
		});
		
		mVolumeUp = (Button)findViewById(R.id.volume_up);
		mVolumeUp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int volume = mVolumePlate.getValue() + 1;
				setVolume(volume, v, true);
			}
		});
		
		mVolumeMute = (MuteButton)findViewById(R.id.volume_mute);
		mVolumeListener.add(mVolumeMute);
		
		mVolumeMute.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mVolumeMute.isMute()) {
					setVolume(mVolumeMute.unmute(), mVolumeMute, true);
				} else {
					mVolumeMute.mute(getVolume());
					setVolume(0, mVolumeMute, true);
				}
			}
		});
	}
	
	private void setEnalbeAllViews(boolean enable) {
		log("setEnalbeAllViews");
		ViewGroup root = (ViewGroup)this.findViewById(R.id.container);
		int count = root.getChildCount();
		log("setEnalbeAllViews, count = " + count);
		for (int i=0; i<count; i++) {
			View v = root.getChildAt(i);
			if (v.getId() != R.id.on_off && v.getId() != R.id.btn_exit) {
				v.setClickable(enable);
			}
		}
	}
	
	private void setOnOffUI(boolean turnTo) {
		mOnOffButton.setActivated(turnTo);
		mLightCross.setActive(turnTo);
		
		if (turnTo) {
			log("hide shutter");
			mShutter.setVisibility(View.GONE);
		} else {
			log("show shutter");
			mShutter.setVisibility(View.VISIBLE);
		}
	}
	
	private void initActionBar() {
		ActionBar ab = this.getActionBar();
		ab.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.fm_titlebar_bg));
	}
	
	/*
	 * Service related
	 */
	private void bindService() {
		log("bindService");
    	Intent intent = new Intent().setClass(this, FmService.class);
    	this.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
	}
	
	private void unbindService() {
		log("unbindService");
		mServiceBinder.unregisterFmCallback(this);
		unbindService(mConnection);
	}
	
	private class FmServiceConnection implements ServiceConnection {
		public void onServiceConnected(ComponentName className, IBinder service) {
			log("onServiceConnected");
			
			mServiceBinder = (FmServiceBinder)service;
			mServiceBinder.registerFmCallback(MainActivity.this);
			
			FmUtils.getDevicePowerState(mServiceBinder);
			FmUtils.getDeviceFreq(mServiceBinder);
			FmUtils.getDeviceVolume(mServiceBinder);
//			int freq = FmUtils.getLatestFreq(MainActivity.this);
//			log("init freq: " + freq);
//			setFreq(freq, null, false);
			
//			int volume = FmUtils.getSystemVolume(MainActivity.this);
//			setVolume(volume, null, false);
			
		}

		public void onServiceDisconnected(ComponentName className) {
			log("onServiceDisconnected");
		}
	};
	
	private void setFreq(int freq, Object caller, boolean setDevice) {
		log("setFreq: " + freq + ", setDevice = " + setDevice);
		
		int settingFreq = FmUtils.tidyFreq(freq);
		log("setFreq, listener count = " + mFreqListener.size());
		for (ValueChangeListener l: mFreqListener) {
			if (l != caller) {
				l.setValue(settingFreq);
			}
		}
		
		if (setDevice) {
			FmUtils.saveAndSetFreq(settingFreq, this, mServiceBinder);
		}
		
		log("setFreq: return");
	}
	
	/*
	 * FM Service interface
	 * (non-Javadoc)
	 * @see com.borqs.fmradio.service.FmService.FmCallback#onFmCallBack(android.os.Bundle)
	 */

	@Override
	public void onFmCallBack(Bundle b) {
		Message msg = mHandler.obtainMessage();
		msg.setData(b);
		msg.sendToTarget();
	}
	
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Bundle b = msg.getData();
			int resp = b.getInt(Consts.RESP_EXTRA);
			log("get resopnse: " + resp);
			switch (resp) {
			case Consts.RESP_CHANNEL_FREQ:
				int freq = b.getInt(Consts.PARAM_0);
				log("get freq " + freq);
				setFreq(freq, null, false);
				break;
				
			case Consts.RESP_CLOSE:
				setOnOffUI(false);
				finish();
				break;
			
			case Consts.RESP_POWER_STATE:
				int state = b.getInt(Consts.PARAM_0);
				setOnOffUI(state == 1);
				break;
				
			case Consts.RESP_GET_VOLUME:
				int value = b.getInt(Consts.PARAM_0);
				log("RESP_GET_VOLUME, value = " + value);
				setVolume(value, null, false);
			}
		}
	};
	
	/*
	 * FaveriteListManager.OnChannelActivatedListenner
	 */
	@Override
	public void onChannelActivated(int freq) {
		setFreq(freq, mFaveriteManager, true);
	}
	
	/*
	 * log method
	 */
	
    private static void log(String msg) {
    	FmUtils.log("MainActivity, " + msg);
    }

}
