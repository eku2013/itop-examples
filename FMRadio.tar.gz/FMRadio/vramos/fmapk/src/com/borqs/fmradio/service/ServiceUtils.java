package com.borqs.fmradio.service;

import java.lang.reflect.Method;

import com.borqs.fmradio.service.FmService.FmServiceBinder;
import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class ServiceUtils {
	
	
	static int initDevice(FMNative.fm_callbacks fmCallbacks) {
		log("initDevice");
		
		int ret = FMNative.fm_init(fmCallbacks);
		log("FMNative.fm_init return " + ret);
		
//		regin_tone_mode
//		Bit0: 0 = Europe, 1 = Japan
//		Bit1: 0 = mono, 1 = stereo
		ret = FMNative.fm_set_region_tune_mode(2);
		log("FMNative.fm_set_region_tune_mode return " + ret);
		
		ret = FMNative.fm_set_search_steps(100);
		log("FMNative.fm_set_search_steps return " + ret);
		
		return 0;
	}
	
	public static int setFmRxMode(Context context, int mode) {
		log("setFmRxMode: " + mode);
		AudioManager audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		int ret = -1;
		try {
	    	Method method = AudioManager.class.getMethod(
	    			"setFmRxMode",
	    			int.class);
	    	ret = (Integer)method.invoke(audioManager, mode);
	    	log("setFmRxMode: reflect_setFmRxMode return " + ret);
		} catch (Exception ex) {
			log("setFmRxMode: " + ex);
		}
		return ret;
	}
	
	static void setDeviceFreq(int freq, Handler handler) {
		log("setDeviceFreq");
		Bundle b = new Bundle();
		b.putInt(Consts.CMD_EXTRA, Consts.CMD_TUNE_FREQ);
		b.putInt(Consts.PARAM_0, freq);
		
		Message msg = handler.obtainMessage();
		msg.setData(b);
		msg.sendToTarget();
	}
	
	private static void log(String msg) {
		FmUtils.log("ServiceUtils: " + msg);
	}
}
