/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.borqs.fmradio.service;


public class FMNative {
    private static final String NATIVE_PATH = "/data/data/com.borqs.fmradio/lib/libfminterlayer.so";
    private static final String NATIVE_PATH_1 = "/system/lib/libfminterlayer.so";
    static {
    	System.load(NATIVE_PATH_1);
    }
    
    public interface fm_callbacks {
    	void fm_get_region_tune_mode_callback(int param);
    	void fm_get_channel_freq_callback(int param);
    	void fm_get_current_rssi_callback(int param);
    	void fm_get_current_snr_callback(int param);
    	void fm_get_search_steps_callback(int param);
    	void fm_get_mute_state_callback(int param);
    	void fm_get_volume_gain_callback(int param);
    	void fm_get_preset_channels_callback(int[] freqs);
    	void fm_get_search_rssi_threshold_callback(int param);
    	void fm_get_snr_threshold_callback(int param);
    	void fm_get_stereo_mono_status_callback(int param);
    	void fm_get_power_state_callback(int state);
    }
    
	public native static int fm_init(Object callbacks);
	public native static int fm_func_on();
	public native static int fm_get_region_tune_mode();
	public native static int fm_set_region_tune_mode(int mode);
	public native static int fm_tune_freq(int freq);
	public native static int fm_get_current_freq();
	public native static int fm_set_search_rssi_threshold(int threshold);
	public native static int fm_get_search_rssi_threshold();
	public native static int fm_get_current_rssi();
	public native static int fm_set_snr_threshold(int threshold);
	public native static int fm_get_snr_threshold();
	public native static int fm_get_current_snr();
	public native static int fm_search(int direct, int freq);
	public native static int fm_auto_search(int direct, int freq, int num);
	public native static int fm_searchabort();
	public native static int fm_set_search_steps(int steps);
	public native static int fm_get_search_steps();
	public native static int fm_mute();
	public native static int fm_unmute();
	public native static int fm_get_mute_state();
	public native static int fm_set_volume(int volume);
	public native static int fm_get_volume();
	public native static int fm_func_off();
	public native static int fm_close();
	public native static int fm_get_stereo_mono_status();
	public native static int fm_get_power_state();
}
