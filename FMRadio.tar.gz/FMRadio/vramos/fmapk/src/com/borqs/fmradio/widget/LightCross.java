package com.borqs.fmradio.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;

import com.borqs.fmradio.utils.FmUtils;

public class LightCross extends View {

	private static final int ROW_COUNT = 17;
	private static final int COLUMN_COUNT = 48;
	private static final int TIME_INTERVAL = 200;
	private static final float INTENSITY = 5;
	
	private static float mCrossWidth;
	private boolean mActived = false;
	private Handler mHandler = null;
	
	Bitmap[] cross;

	public LightCross(Context context) {
		super(context);
	}

    public LightCross(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
    
    public LightCross(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        
        initBitmapArray(context);
        
    }
    
    public void setActive(boolean active) {
    	mActived = active;
    	if (active && mHandler != null) {
    		mHandler.sendEmptyMessage(0);
    	}
    }
    
    private void initBitmapArray(Context context) {
    	cross = new Bitmap[ROW_COUNT];
    	for (int i=1; i<=ROW_COUNT; i++) {
    		int resID = getResources().getIdentifier("fm_audio_" + i, "drawable", "com.borqs.fmradio");
    		cross[i-1] = ((BitmapDrawable)context.getResources().getDrawable(resID)).getBitmap();
    	}
    	if (cross[0] != null) {
    		mCrossWidth = cross[0].getWidth() + 1;
    	}
    }
    
    public void setMainLooper(Looper looper) {
    	mHandler = new Handler(looper) {
    		@Override
    		public void handleMessage(Message msg) {
    			if (mActived) {
    				this.removeMessages(0);
    				this.sendEmptyMessageDelayed(0, TIME_INTERVAL);
    				invalidate();
    			} else {
    				invalidate();
    				mStrong = 0;
    			}
    		}
    	};
    }
    
	@Override
	protected void onDraw(Canvas canvas) {
		
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		
		canvas.translate(0, canvas.getHeight());
		
		if (mActived) {
			drawAnimation_3(canvas, paint);
		} else {
			drawUnActive(canvas, paint);
		}
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension((int) (mCrossWidth * COLUMN_COUNT),
				cross[ROW_COUNT - 1].getHeight());
	}
	
	private void drawAnimation_1(Canvas canvas, Paint paint) {
		for (int i=0; i<COLUMN_COUNT; i++) {
			int value = (int)(Math.random() * (ROW_COUNT - 1));
			canvas.drawBitmap(cross[value], mCrossWidth * i, - cross[value].getHeight(), paint);
		}
	}
	
	private void drawAnimation_2(Canvas canvas, Paint paint) {
		float strong = (float)Math.random() * (ROW_COUNT - INTENSITY);
		
		for (int i=0; i<COLUMN_COUNT; i++) {
			int value = (int)(strong + (Math.random() * 2 - 1) * INTENSITY);
			if (value < 0) {
				value = 0;
			} else if (value > ROW_COUNT - 1) {
				value = ROW_COUNT - 1;
			}
			canvas.drawBitmap(cross[value], mCrossWidth * i, - cross[value].getHeight(), paint);
		}
	}
	
	private static float mStrong = 10;
	private void drawAnimation_3(Canvas canvas, Paint paint) {
		
		if (mStrong < 3) {
			mStrong = (float)(mStrong + Math.random() * INTENSITY);
		} else if (mStrong > ROW_COUNT - 3) {
			mStrong = (float)(mStrong - Math.random() * INTENSITY);
		} else {
			mStrong = (float)(mStrong + (Math.random() - 0.5) * INTENSITY);
		}
		
		
		for (int i=0; i<COLUMN_COUNT; i++) {
			int value = (int)(mStrong + (Math.random() * 2 - 1) * INTENSITY);
			if (value < 0) {
				value = 0;
			} else if (value > ROW_COUNT - 1) {
				value = ROW_COUNT - 1;
			}
			canvas.drawBitmap(cross[value], mCrossWidth * i, - cross[value].getHeight(), paint);
		}
	}
	
	private void drawUnActive(Canvas canvas, Paint paint) {
		for (int i=0; i<COLUMN_COUNT; i++) {
			canvas.drawBitmap(cross[0], mCrossWidth * i, - cross[0].getHeight(), paint);
		}
	}
	
	private static void log(String msg) {
		FmUtils.log("LightCross, " + msg);
	}
}
