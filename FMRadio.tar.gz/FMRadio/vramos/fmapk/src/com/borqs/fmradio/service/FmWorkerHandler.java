package com.borqs.fmradio.service;

import java.util.ArrayList;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

public class FmWorkerHandler extends Handler {
	private FmService mService;
	private Handler mWatchDog;
	private HandlerThread mWatchDogThread;
	private int sDeviceState = Consts.DEVICE_OFF;
	private boolean mInited = false;
	private int sDestFreq = -1;
	private Object mLock;
	private int mCurScanFreq;
	private ArrayList<Integer> mChannelList = new ArrayList<Integer>();
	
	private static final int MSG_TIME_OUT = 10;
	
	FmWorkerHandler(Looper l, FmService service, Object lock) {
		super(l);
		mService = service;
		mWatchDogThread = new HandlerThread("FmWorkerHandler_WatchDog");
		mWatchDogThread.start();
		mWatchDog = new Handler(mWatchDogThread.getLooper()) {
				public void handleMessage (Message msg) {
					switch (msg.what) {
					case MSG_TIME_OUT:
						log("cmd " + msg.arg1 + " timeout");
						break;
					}
				}
		};
		
		mLock = lock;
	}
	
	public void handleMessage (Message msg) {
		log("handleMessage");
		
		Bundle b = msg.getData();
		
		int cmd = msg.what;
		log("cmd is " + cmd);
		Message wMsg = mWatchDog.obtainMessage(MSG_TIME_OUT, cmd, 0);
		mWatchDog.sendMessageDelayed(wMsg, 3000);
		
		if (!mInited) {
//			reflect_changeApplicationBluetoothState(true);
			ServiceUtils.initDevice(fmCallbacks);
			mInited = true;
		}
		
		switch (cmd) {
		case Consts.CMD_START: {
			if (!mService.startMonitorHeadsetAndVolume()) {
				break;
			}
			int ret = FMNative.fm_func_on();
			log("FMNative.fm_func_on return " + ret);
			ret = ServiceUtils.setFmRxMode(mService, Consts.MODE_FM_ON);
			log("setFmRxMode 0 return " + ret);
			
			sDeviceState = Consts.DEVICE_ON;
		}
			break;
			
		case Consts.CMD_STOP: {
			
			int ret = ServiceUtils.setFmRxMode(mService, Consts.MODE_FM_OFF);
			log("setFmRxMode 1 return " + ret);
			ret = FMNative.fm_func_off();
			log("FMNative.fm_func_off return " + ret);
			mService.stopMonitorHeadsetAndVolume();
			sDeviceState = Consts.DEVICE_OFF;
		}
			break;
			
		case Consts.CMD_CLOSE: {
			int ret = ServiceUtils.setFmRxMode(mService, Consts.MODE_FM_OFF);
			log("setFmRxMode 1 return " + ret);
			ret = FMNative.fm_func_off();
			log("FMNative.fm_func_off return " + ret);
			mService.stopMonitorHeadsetAndVolume();
			
			FMNative.fm_close();
			mInited = false;
			sDeviceState = Consts.DEVICE_OFF;
			break;
		}
			
		case Consts.CMD_TUNE_FREQ: {
			int freq = b.getInt(Consts.PARAM_0);
			log("tuen freq to " + freq);
			sDestFreq = freq;
			int value = FmUtils.freqToValue(freq);
			FMNative.fm_tune_freq(value);
			break;
		}
			
		case Consts.CMD_GET_FREQ: {
			int ret = FMNative.fm_get_current_freq();
			log("fm_get_current_freq = " + ret);
			break;
		}
			
		case Consts.CMD_SCAN_ALL: {
			log("scan all");
			if (Consts.DEVICE_SCANNING == sDeviceState) {
				int freq = msg.arg1;
				mChannelList.add(freq);
				mCurScanFreq = freq;
				
				log("scan all, scan next: " + mCurScanFreq);
				int value = FmUtils.freqToValue(mCurScanFreq) - 100;
				FMNative.fm_search(Consts.FM_SEARCH_DOWN, value);
			} else {
				sDeviceState = Consts.DEVICE_SCANNING;
				mCurScanFreq = Consts.FREQ_MAX;
				mChannelList.clear();
				int value = FmUtils.freqToValue(mCurScanFreq);
				FMNative.fm_search(Consts.FM_SEARCH_DOWN, value);
			}
			break;
		}
			
		case Consts.CMD_SCAN_NEXT: {
			int freq = b.getInt(Consts.PARAM_0);
			log("scan next: " + freq);
			
			sDeviceState = Consts.DEVICE_SEARCHING;
			
			int value = FmUtils.freqToValue(freq) + 100;
			FMNative.fm_search(Consts.FM_SEARCH_UP, value);
			break;
		}
			
		case Consts.CMD_SCAN_PREV: {
			int freq = b.getInt(Consts.PARAM_0);
			log("scan next: " + freq);
			
			sDeviceState = Consts.DEVICE_SEARCHING;
			
			int value = FmUtils.freqToValue(freq) - 100;
			FMNative.fm_search(Consts.FM_SEARCH_DOWN, value);
			break;
		}
			
		case Consts.CMD_SCAN_ABORT:
			log("scan abort");
			FMNative.fm_searchabort();
			sDeviceState = Consts.DEVICE_SCAN_ABORTING;
			break;
			
		case Consts.CMD_GET_POWER_STATE:
			FMNative.fm_get_power_state();
			break;
			
		case Consts.CMD_SET_VOLUME: {
			int value = b.getInt(Consts.PARAM_0);
			log("set volume: " + value);
			FMNative.fm_set_volume(value);
			int volume = FmUtils.valueToVolume(value);
			break;
		}
		
		case Consts.CMD_GET_VOLUME: {
			mService.setUiVolume();
			break;
		}
		
		case Consts.CMD_SET_MUTE:
			log("set mute");
			FMNative.fm_mute();
			break;
			
		case Consts.CMD_SET_UNMUTE:
			log("set unmute");
			FMNative.fm_unmute();
			break;
			
		default:
			log("warning, unexpected command");
		}
		// for monitor native method timeout
		mWatchDog.removeMessages(MSG_TIME_OUT);
	}
	
	private FMNative.fm_callbacks fmCallbacks = new FMNative.fm_callbacks() {

		@Override
		public void fm_get_region_tune_mode_callback(int param) {
			log("fm_get_region_tune_mode_callback, param = " + param);
		}

		@Override
		public void fm_get_channel_freq_callback(int param) {
			
			log("fm_get_channel_freq_callback, param = " + param + ", sDeviceState = " + sDeviceState);
			
			if (Consts.DEVICE_SETTNG_FREQ == sDeviceState) {
				
				if (FmUtils.valueToFreq(param) != sDestFreq) {
					log("fm_get_channel_freq_callback, set freq again");
					ServiceUtils.setDeviceFreq(sDestFreq, FmWorkerHandler.this);
				} else {
					sDeviceState = Consts.DEVICE_ON;
				}
			}
			
			if (Consts.DEVICE_SEARCHING == sDeviceState) {
				sDeviceState = Consts.DEVICE_ON;
				
				Bundle b = new Bundle();
				b.putInt(Consts.RESP_EXTRA, Consts.RESP_CHANNEL_FREQ);
				int freq = FmUtils.valueToFreq(param);
				b.putInt(Consts.PARAM_0, freq);
				mService.invokeCallback(b);
			}

			if (Consts.DEVICE_SCANNING == sDeviceState
					|| Consts.DEVICE_SCAN_ABORTING == sDeviceState) {
				int freq = FmUtils.valueToFreq(param);
				if (Consts.FREQ_MIN == freq
						|| Consts.DEVICE_SCAN_ABORTING == sDeviceState) {
					log("scan call completed");
					// scanning completed
					// send result to ChannelListActivity
					sDeviceState = Consts.DEVICE_ON;
					Bundle b = new Bundle();
					b.putInt(Consts.RESP_EXTRA, Consts.RESP_SCAN_COMPLETE);
					b.putIntegerArrayList(Consts.PARAM_0, mChannelList);
					mService.invokeCallback(b);
				} else {
					Bundle bd = new Bundle();
					bd.putInt(Consts.RESP_EXTRA, Consts.RESP_SCAN_GOT_CHANNEL);
					bd.putInt(Consts.PARAM_0, mChannelList.size()+1);
					mService.invokeCallback(bd);
					
					Message msg = FmWorkerHandler.this.obtainMessage(
							Consts.CMD_SCAN_ALL, freq, 0);
					FmWorkerHandler.this.sendMessageDelayed(msg, 0);
					
				}
				
			}
		}

		@Override
		public void fm_get_current_rssi_callback(int param) {
			log("fm_get_current_rssi_callback, param = " + param);
		}

		@Override
		public void fm_get_current_snr_callback(int param) {
			log("fm_get_current_snr_callback, param = " + param);
		}

		@Override
		public void fm_get_search_steps_callback(int param) {
			log("fm_get_search_steps_callback, param = " + param);
		}

		@Override
		public void fm_get_mute_state_callback(int param) {
			log("fm_get_mute_state_callback, param = " + param);
		}

		@Override
		public void fm_get_volume_gain_callback(int param) {
			log("fm_get_volume_gain_callback, param = " + param);
		}

		@Override
		public void fm_get_preset_channels_callback(int values[]) {
			log("fm_get_preset_channels_callback");
			
			int length = 0;
			for (int i=values.length-1; i>=0; i--) {
				if (values[i] != 0) {
					length++;
				}
			}
			
			int freqs[] = new int[length];
			
			int index = 0;
			for (int i=0; i<values.length; i++) {
				if (0 == values[i]) {
					continue;
				}
				freqs[index] = FmUtils.valueToFreq(values[i]);
				log(index + ". " + freqs[index] + "MHz" + ", data = " + values[i]);
			}
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_SCAN_COMPLETE);
			b.putIntArray(Consts.PARAM_0, freqs);
			mService.invokeCallback(b);
		}

		@Override
		public void fm_get_search_rssi_threshold_callback(int param) {
			log("fm_get_search_rssi_threshold_callback, param = " + param);
		}

		@Override
		public void fm_get_snr_threshold_callback(int param) {
			log("fm_get_snr_threshold_callback, param = " + param);
		}

		@Override
		public void fm_get_stereo_mono_status_callback(int param) {
			log("fm_get_stereo_mono_status_callback, param = " + param);
		}
		
		@Override
		public void fm_get_power_state_callback(int state) {
			log("fm_get_power_state_callback, " + state);
			
			sDeviceState = state;
			
			if (state == Consts.DEVICE_ON && mService != null) {
				mService.startMonitorHeadsetAndVolume();
			}
			
			Bundle b = new Bundle();
			b.putInt(Consts.RESP_EXTRA, Consts.RESP_POWER_STATE);
			b.putInt(Consts.PARAM_0, state);
			mService.invokeCallback(b);
		}
		
	};
	
	private static void log(String msg) {
		FmUtils.log("FmWorkerHandler: " + msg);
	}
}
