package com.borqs.fmradio.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.FmUtils;

public class Nixietube extends View implements ValueChangeListener {
	
	Bitmap[] mNumMaps;
	Bitmap zeroXInvMap;
	Bitmap dotMap;
	int mData = 0;
	
	int[] mNumXPoses = {0, 0, 0, 0};
	
	int mDotPos = 0;
	
	public Nixietube(Context context) {
		super(context);
	}

    public Nixietube(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
    
    public Nixietube(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        
        initBitmapArray(context, attrs);
        
    }
    
    public void setValue(int data) {
    	if (data < 10000 || data > 999000) {
    		return;
    	}
    	mData = FmUtils.tidyFreq(data);
    	this.invalidate();
    }
    
    private void initBitmapArray(Context context, AttributeSet attrs) {
		
    	TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FmView);
		mNumMaps = new Bitmap[12];
		
		mNumMaps[0] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_0))).getBitmap();
		mNumMaps[1] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_1))).getBitmap();
		mNumMaps[2] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_2))).getBitmap();
		mNumMaps[3] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_3))).getBitmap();
		mNumMaps[4] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_4))).getBitmap();
		mNumMaps[5] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_5))).getBitmap();
		mNumMaps[6] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_6))).getBitmap();
		mNumMaps[7] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_7))).getBitmap();
		mNumMaps[8] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_8))).getBitmap();
		mNumMaps[9] = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_9))).getBitmap();
    	
		zeroXInvMap = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_0_x))).getBitmap();
		dotMap = ((BitmapDrawable)(a.getDrawable(R.styleable.FmView_res_dot))).getBitmap();
		
		int x = 0;
		mNumXPoses[0] = x;
		x += zeroXInvMap.getWidth();
		mNumXPoses[1] = x;
		x += zeroXInvMap.getWidth();
		mNumXPoses[2] = x;
		x += zeroXInvMap.getWidth();
		mDotPos = x;
		x += dotMap.getWidth();
		mNumXPoses[3] = x;
    }
    
	@Override
	protected void onDraw(Canvas canvas) {
		log("onDraw");
		int data = (int)(mData / 100);
		int value = 0;
		
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		
		// draw dot
		canvas.drawBitmap(dotMap, mDotPos, 0, paint);
		
		value = data / 1000;
		if (0 == value) {
			canvas.drawBitmap(zeroXInvMap, mNumXPoses[0], 0, paint);
		} else {
			canvas.drawBitmap(mNumMaps[value], mNumXPoses[0], 0, paint);
		}
		data %= 1000;
		
		for (int i=1, divisor=100; i<4; i++, divisor/=10) {
			value = data / divisor;
			canvas.drawBitmap(mNumMaps[value], mNumXPoses[i], 0, paint);
			data %= divisor;
		}
		
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(zeroXInvMap.getWidth()*4 + dotMap.getWidth(),
				zeroXInvMap.getHeight());
	}
	
    private static void log(String msg) {
    	FmUtils.log("Nixietube, " + msg);
    }
}
