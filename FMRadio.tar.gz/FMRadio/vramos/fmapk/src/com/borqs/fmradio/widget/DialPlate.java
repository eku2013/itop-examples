package com.borqs.fmradio.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import com.borqs.fmradio.R;

import com.borqs.fmradio.utils.FmUtils;

public abstract class DialPlate extends ImageView implements OnTouchListener, ValueChangeListener {
	
	protected float mDegree = 0; // based on mLowerLimit
	protected float mBaseDegree = 0;
	protected float mScopeDegree = 180;
	
	protected int mValue = 0;
	protected int mBaseValue = 0;
	protected int mScopeValue = 100;
	
	protected boolean mIsMoving = false;
	
	protected boolean mSettingValue = false;
	
	protected Bitmap mBitmap = null;
	protected float mAxesX = 0;
	protected float mAxesY = 0;
	protected float mRadius = 0;
	protected OnDegreeChangedListener mListener = null;

	public DialPlate(Context context) {
		super(context);
	}
	
	public DialPlate(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    
	public DialPlate(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		Drawable d = getBackground();
		mBitmap = drawableToBitmap(d);
		setOnTouchListener(this);
		
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FmView);
		
		mAxesX = a.getFloat(R.styleable.FmView_axes_x, 0);
		mAxesY = a.getFloat(R.styleable.FmView_axes_y, 0);
		mDegree = a.getFloat(R.styleable.FmView_defalut_degree, 0);
		mBaseDegree = a.getFloat(R.styleable.FmView_base_degree, 0);
		mScopeDegree = a.getFloat(R.styleable.FmView_scope_degree, 0);
		mBaseValue = a.getInteger(R.styleable.FmView_base_value, 0);
		mScopeValue = a.getInteger(R.styleable.FmView_scope_value, 0);
		mRadius = a.getFloat(R.styleable.FmView_radius, 0);
	}

	public interface OnDegreeChangedListener {
		void onValueChanging(int value);
		void onValueChanged(int value);
	}
	
	public void setOnDegreeChangedListener(OnDegreeChangedListener l) {
		mListener = l;
	}
	
	abstract void onChange(float degree);
	abstract void onMove(float degree);
	
	public void setAxes(float x, float y) {
		mAxesX = x;
		mAxesY = y;
	}
	
	public void setDegree(float degree) {
		mDegree = limit360(degree);
		mValue = degreeToValue(mDegree);
		this.invalidate();
	}
	
	@Override
	public void setValue(int value) {
		if (mIsMoving) {
			return;
		}
		mSettingValue = true;
		
//		log("setValue, value = " + value);
		if (value < mBaseValue) {
			value = mBaseValue;
		} else if (value > mBaseValue + mScopeValue) {
			value = mBaseValue + mScopeValue;
		}
		
		mValue = FmUtils.tidyValue(value, this.mBaseValue, this.mScopeValue);
//		log("setValue, mValue = " + mValue);
		mDegree = valueToDegree(mValue);
		
//		log("setValue, mDegree = " + mDegree);
		onMove(mDegree);
	}
	
	public int getValue() {
		return mValue;
	}
	
	
	public void setLimit(float baseDegree, float scope) {
		mBaseDegree = limit360(baseDegree);
		mScopeDegree = limit360(scope);;
	}
	
	public double getDegree() {
		return mDegree;
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		
    	float x = event.getX();
    	float y = event.getY();
    	log("onTouch, " + event.getAction());
    	
		switch(event.getAction()){
		case MotionEvent.ACTION_DOWN:
			
			if (x >= 0 && x < mBitmap.getWidth() && y >= 0
					&& y < mBitmap.getHeight() && mBitmap.getPixel((int)x, (int)y) == 0) {
				log("transparent area");
				return false;
			}
			
			mIsMoving = true;
			
			this.setPressed(true);
			
			mDegree = calcDegree(x, y);
			mValue = degreeToValue(mDegree);
			onMove(mDegree);
			if (mListener != null) {
				mListener.onValueChanging(mValue);
			}
			
			break;
			
		case MotionEvent.ACTION_MOVE:
			
			mDegree = calcDegree(x, y);
			mValue = degreeToValue(mDegree);
			onMove(mDegree);
//			if (mListener != null) {
//				mListener.onValueChanging(mValue);
//			}
		break;
		
		case MotionEvent.ACTION_UP:

			this.setPressed(false);
			mIsMoving = false;
//			mDegree = calcDegree(x, y);
			onChange(mDegree);
//			if (mListener != null) {
//				mListener.onValueChanged(mValue);
//			}
			
		break;
		}

		return true;
	}
	
	private float limit360(float degree) {
		
		float a = degree;
		while (a > 360) {
			a -= 360;
		}
		
		while (a < 0) {
			a += 360;
		}
		
		return a;
	}
	
	private float calcDegree(float x, float y) {
		double dx = mAxesX - x;
		double dy = mAxesY - y;
		if (0 == dx) {
			return 0;
		}
		
		double a = Math.atan(dy/dx) * 180 / Math.PI;
		
		if (dx < 0) {
			a += 180;
		} else if (a < 0) {
			a += 360;
		}
		log("1. a = " + a);
		a -=  mBaseDegree;
		
		log("2. a = " + a);
		
		a = limit360((float)a);
		
		log("3. a = " + a);
		if (a > mScopeDegree) {
			a = mDegree;
		}
		log("4. a = " + a);
		return (float)a;
	}
	
	private int degreeToValue(float degree) {
		log("degreeToValue, mBaseValue = " + mBaseValue + ", mScopeValue = " + mScopeValue + ", mScopeDegree = " + mScopeDegree);
		int value = (int)(mBaseValue + degree * mScopeValue / mScopeDegree);
		log("degreeToValue value = " + value);
		return FmUtils.tidyValue(value, this.mBaseValue, this.mScopeValue);
	}
	
	private float valueToDegree(float value) {
		float d = (value - mBaseValue) * mScopeDegree / mScopeValue;
		return limit360(d);
	}
	
    protected static Bitmap drawableToBitmap(Drawable drawable) {  
    	if (null == drawable) {
    		return null;
    	}
    	
        // get drawable width and height 
        int w = drawable.getIntrinsicWidth();  
        int h = drawable.getIntrinsicHeight();  
  
        // get drawable color format  
        Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888  
                : Bitmap.Config.RGB_565;  
        // create corresponding bitmap  
        Bitmap bitmap = Bitmap.createBitmap(w, h, config);  
        // build bitmap canvas  
        Canvas canvas = new Canvas(bitmap);  
        drawable.setBounds(0, 0, w, h);  
        // draw drawable to canvas of bitmap  
        drawable.draw(canvas);  
        return bitmap;  
    }
    
    private void log(String msg) {
    	FmUtils.log("DialPlate, " + this.hashCode() + " " + msg);
    }

}
