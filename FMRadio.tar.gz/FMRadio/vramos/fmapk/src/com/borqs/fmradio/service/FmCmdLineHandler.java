package com.borqs.fmradio.service;

import com.borqs.fmradio.utils.Consts;
import com.borqs.fmradio.utils.FmUtils;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public class FmCmdLineHandler extends Handler {
	
	private Object mLock;
	private Handler mWorkHandler;
	
	public FmCmdLineHandler(Looper l, Handler workHandler, Object lock) {
		super(l);
		mWorkHandler = workHandler;
		mLock = lock;
	}

	@Override
	public void handleMessage(Message msg) {
		synchronized (mLock) {
			try {
				msg.setTarget(mWorkHandler);
				msg.sendToTarget();
				log("befor wait, cmd = " + msg.getData().getInt(Consts.CMD_EXTRA));
				mLock.wait();
				log("after wait, cmd = " + msg.getData().getInt(Consts.CMD_EXTRA));
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	private static void log(String msg) {
		FmUtils.log("FmCmdLineHandler: " + msg);
	}
}
