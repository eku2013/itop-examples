package com.borqs.fmradio.utils;

public class Consts {
	
	public static int MAX_VOLUME;
	
	public static final String SP_NAME = "fmradio_data";
	
	public static final int FREQ_STEP = 100;
	
	public static final int TEST_MESSAGE = 11;
	
	public static final int MODE_FM_ON = 1;
	public static final int MODE_FM_OFF = 0;
	
	public static final int DEVICE_OFF = 0;
	public static final int DEVICE_ON = 1;
	public static final int DEVICE_SETTNG_FREQ = 2;
	public static final int DEVICE_SEARCHING = 3;
	public static final int DEVICE_SCANNING = 4;
	public static final int DEVICE_SCAN_ABORTING = 5;
	
	public static final int FREQ_DEVICE_BASE = 64000;
	public static final int FREQ_MIN = 87500;
	public static final int FREQ_MAX = 108000;
	
	public static final int  FM_SEARCH_DOWN = 0;
	public static final int  FM_SEARCH_UP = 1;
	
	public static final String CMD_EXTRA = "cmd";
	public static final String RESP_EXTRA = "resp";
	public static final String PARAM_0 = "param_0";
	public static final String PARAM_1 = "param_1";
	
	public static final int EXIT_THREAD = -1;
	public static final int CMD_INIT = 1010;
	public static final int CMD_START = 1020;
	public static final int CMD_STOP = 1025;
	public static final int CMD_PAUSE = 1030;
	public static final int CMD_RESUME = 1040;
	public static final int CMD_CLOSE = 1050;
	public static final int CMD_TUNE_FREQ = 1060;
	public static final int CMD_GET_FREQ = 1065;
	public static final int CMD_SCAN_ALL = 1070;
	public static final int CMD_SCAN_NEXT = 1080;
	public static final int CMD_SCAN_PREV = 1090;
	public static final int CMD_SCAN_ABORT = 1100;
	public static final int CMD_GET_POWER_STATE = 1110;
	public static final int CMD_SET_VOLUME = 1120;
	public static final int CMD_GET_VOLUME = 1130;
	public static final int CMD_SET_MUTE = 1140;
	public static final int CMD_SET_UNMUTE = 1150;
	
	public static final int RESP_CLOSE = 2050;
	public static final int RESP_CHANNEL_FREQ = 2060;
	public static final int RESP_SCAN_COMPLETE = 2070;
	public static final int RESP_SCAN_GOT_CHANNEL = 2075;
	public static final int RESP_POWER_STATE = 2110;
	public static final int RESP_GET_VOLUME = 2130;
	
	public static final int HEADSET_PLUGED = 1;
	public static final int HEADSET_LOST = 0;
}
