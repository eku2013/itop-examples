package com.borqs.fmradio.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import com.borqs.fmradio.R;
import com.borqs.fmradio.utils.FmUtils;

public class VolumePlate extends DialPlate {
	
	Bitmap mBlockBitmap = null;
	int mBlockCount = 0;
	float mStep = 0;
	
	public VolumePlate(Context context) {
		super(context);
	}
	
	public VolumePlate(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

	public VolumePlate(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FmView);
		
		Drawable blockDra = a.getDrawable(R.styleable.FmView_block_res);
		mBlockBitmap = ((BitmapDrawable)blockDra).getBitmap();
		mStep = a.getFloat(R.styleable.FmView_step, 0);
	}

	@Override
	void onChange(float degree) {
		onMove(degree);
	}
	
	@Override
	void onMove(float degree) {
		log("onMove, degree = " + degree + ", mSettingValue = " + mSettingValue);
		int prevCount = mBlockCount;
		mBlockCount = calcBlockCount();
		
		if (prevCount != mBlockCount) {
			this.invalidate();
		}
		if (mListener != null && !mSettingValue) {
			mListener.onValueChanged(mValue);
			mSettingValue = false;
		}
	}
	
	private int calcBlockCount() {
		int blockCount = (int)(super.mDegree / mStep);
		
		float t = super.mDegree % mStep;
		if ((0 == blockCount && t > 1) || ((blockCount > 0) && t > 0.1)) {
			blockCount ++;
		}
		
		return blockCount;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		
		canvas.save();
		
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		
		float x = - super.mRadius;
		float y = - mBlockBitmap.getHeight() / 2;
		
		log("onDraw, x = " + x + ", y = " + y + ", axesX = " + super.mAxesX + ", axesY = " + super.mAxesY);
		
		canvas.translate(super.mAxesX, super.mAxesY);
		
		canvas.rotate(super.mBaseDegree);
		
		for (int i=0; i<mBlockCount; i++) {
			
			canvas.drawBitmap(mBlockBitmap, x, y, paint);
			
			canvas.rotate(mStep);
		}

		canvas.restore();
	}
	
	private static void log(String msg) {
		FmUtils.log("VolumPlate, " + msg);
	}

}
