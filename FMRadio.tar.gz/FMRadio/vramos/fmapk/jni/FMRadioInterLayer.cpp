
#define LOG_TAG "FMRadioInterLayer"

#include "jni.h"
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <android/log.h>
#include <dlfcn.h>
#include "mylog.h"
#include "fmradio.h"
#include <linux/capability.h>

#define FREQ_BASE 64000 // KHz

//*********** for callback method **************

typedef struct {
	const char* name;
	const char* signature;
} FMCallbackMethod;

static jobject mjCbIns = NULL;
static JavaVM *mjVirMac = NULL;

static void *h_fm_lib = NULL;

static FMCallbackMethod callback_table[] = {
    	{"fm_get_region_tune_mode_callback",		 "(I)V"},
    	{"fm_get_channel_freq_callback",			 "(I)V"},
    	{"fm_get_current_rssi_callback",			 "(I)V"},
    	{"fm_get_current_snr_callback", 			 "(I)V"},
    	{"fm_get_search_steps_callback", 			 "(I)V"},
    	{"fm_get_mute_state_callback", 				"(I)V"},
    	{"fm_get_volume_gain_callback",				 "(I)V"},
    	{"fm_get_preset_channels_callback",			 "([I)V"},
    	{"fm_get_search_rssi_threshold_callback",	 "(I)V"},
    	{"fm_get_snr_threshold_callback", 			"(I)V"},
    	{"fm_get_stereo_mono_status_callback",		 "(I)V"},
    	{"fm_get_power_state_callback", 			"(I)V"},
};

static jmethodID getCallbackMethodID(JNIEnv *env, jobject obj, int index)
{
	log("index = %d, name = %s", index, callback_table[index].name);

	jclass jCbClass = env->GetObjectClass(obj);
	if (NULL == jCbClass) {
		LOGE("get onGetRdsPs methodID failure !");
		return NULL;
	}

	return env->GetMethodID(jCbClass, callback_table[index].name, callback_table[index].signature);
}

static void run_callback(int index, jvalue ValList[])
{
	log("index = %d", index);

	jmethodID jMethodID = NULL;
	JNIEnv *jEnv = NULL;

	mjVirMac->AttachCurrentThread(&jEnv, NULL);
	jMethodID = getCallbackMethodID(jEnv, mjCbIns, index);

	if (NULL == jMethodID) {
		LOGE("get callback methodID failure !");
		return;
	}

	jEnv->CallVoidMethodA(mjCbIns, jMethodID, ValList);
	mjVirMac->DetachCurrentThread();

	return;
}

static void run_callbackA(int index, jintArray freqs)
{
	log("index = %d", index);

	jmethodID jMethodID = NULL;
	JNIEnv *jEnv = NULL;

	mjVirMac->AttachCurrentThread(&jEnv, NULL);
	jMethodID = getCallbackMethodID(jEnv, mjCbIns, index);

	if (NULL == jMethodID) {
		LOGE("get callback methodID failure !");
		return;
	}

	jEnv->CallVoidMethod(mjCbIns, jMethodID, freqs);
	mjVirMac->DetachCurrentThread();

	return;
}



static void on_get_region_tune_mode(uint8_t mode)
{
	log("mode = %d", mode);

	jvalue ValList[1];
	ValList[0].i = (jint) mode;
	run_callback(0, ValList);

	return;
}

static void on_get_channel_freq(uint16_t freq)
{
	log(" freq = %d", freq);

	jvalue ValList[1];
	ValList[0].i = (jint) freq;
	run_callback(1, ValList);

	return;
}

static void on_get_current_rssi(uint8_t rssi)
{
	log(" rssi = %d", rssi);

	jvalue ValList[1];
	ValList[0].i = (jint) rssi;
	run_callback(2, ValList);

	return;
}

static void on_get_current_snr(uint8_t snr)
{
	log(" snr = %d", snr);

	jvalue ValList[1];
	ValList[0].i = (jint) snr;
	run_callback(3, ValList);

	return;
}

static void on_get_search_steps(uint8_t step)
{
	log(" step = %d", step);

	jvalue ValList[1];
	ValList[0].i = (jint) step;
	run_callback(4, ValList);

	return;
}

static void on_get_mute_state(uint8_t state)
{
	log(" state = %d", state);

	jvalue ValList[1];
	ValList[0].i = (jint) state;
	run_callback(5, ValList);

	return;
}

static void on_get_volume_gain(uint16_t gain)
{
	log(" gain = %d", gain);

	jvalue ValList[1];
	ValList[0].i = (jint) gain;
	run_callback(6, ValList);

	return;
}

typedef struct preset_channel_t {
	uint16_t freq;
	uint16_t reserved;
} PERSET_CHANNEL;

static void on_get_preset_channels(uint8_t plen, uint8_t *param)
{
	log(" param = 0x%x, len = %d\n", param, plen);

	jmethodID jMethodID = NULL;
	JNIEnv *jEnv = NULL;

	uint8_t *p;
	int count = plen >> 2;
	jint freqList[count];
	p = param;

	for (int i=0; i<count; i++) {
		freqList[i] = ((*(p+1))<<8) + (*p);
		log("%d. %d\n", i, freqList[i]);
		p +=4;
	}


	mjVirMac->AttachCurrentThread(&jEnv, NULL);
	jintArray freqs = jEnv->NewIntArray(count);

	jEnv->SetIntArrayRegion(freqs, 0, count, freqList);

	jMethodID = getCallbackMethodID(jEnv, mjCbIns, 7);

	if (NULL == jMethodID) {
		LOGE("get callback methodID failure !");
		return;
	}

	jEnv->CallVoidMethod(mjCbIns, jMethodID, freqs);
	mjVirMac->DetachCurrentThread();

	return;
}

static void on_get_search_rssi_threshold(uint8_t threshold)
{
	log(" threshold = %d", threshold);

	jvalue ValList[1];
	ValList[0].i = (jint) threshold;
	run_callback(8, ValList);

	return;
}

static void on_get_snr_threshold(uint8_t threshold)
{
	log(" threshold = %d", threshold);

	jvalue ValList[1];
	ValList[0].i = (jint) threshold;
	run_callback(9, ValList);

	return;
}

static void on_get_stereo_mono_status(uint8_t status)
{
	log(" status = %d", status);

	jvalue ValList[1];
	ValList[0].i = (jint) status;
	run_callback(10, ValList);

	return;
}

static void on_get_power_state(uint8_t state)
{
	log(" state = %d", state);
	jvalue ValList[1];
	ValList[0].i = (jint) state;
	run_callback(11, ValList);

	return;
}

static fm_callbacks low_layer_cb = {
		on_get_region_tune_mode,
		on_get_channel_freq,
		on_get_current_rssi,
		on_get_current_snr,
		on_get_search_steps,
		on_get_mute_state,
		on_get_volume_gain,
		on_get_preset_channels,
		on_get_search_rssi_threshold,
		on_get_snr_threshold,
		on_get_stereo_mono_status,
		on_get_power_state,
};

//**************  for native method *******************


static jint interlayer_fm_init(JNIEnv *env, jclass clazz, jobject callbacks)
{
	int ret = 0;
	log("");

	env->GetJavaVM(&mjVirMac);
	mjCbIns = env->NewGlobalRef(callbacks);

	if (NULL == mjCbIns) {
		LOGE("interlayer_fm_init has mjCbIns == NULL!");
		return (jint)-1;
	}

	fm_init_t fp = (fm_init_t)dlsym(h_fm_lib, "fm_init");

	ret = fp(&low_layer_cb);
	log("interlayer_fm_init return %d", ret);

	return ret;
}

static jint interlayer_fm_func_on(JNIEnv *env, jclass clazz)
{
	log("");
	int ret = -1;

	fm_func_on_t fp = (fm_func_on_t)dlsym(h_fm_lib, "fm_func_on");

	if (NULL == fp) {
		log("can not get method fm_func_on");
		return ret;
	}
	ret = fp();

	log("fm_func_on return %d", ret);

	return ret;
}

static jint interlayer_fm_get_region_tune_mode(JNIEnv *env, jclass clazz)
{
	log("");
//	return fm_get_region_tune_mode();
	return (jint)3;
}

static jint interlayer_fm_set_region_tune_mode(JNIEnv *env, jclass clazz, jint mode)
{
	log("mode = %d", mode);
	int ret = -1;

	fm_set_region_tune_mode_t fp = (fm_set_region_tune_mode_t)dlsym(h_fm_lib, "fm_set_region_tune_mode");

	if (NULL == fp) {
		log("can not get method fm_set_region_tune_mode");
		return ret;
	}
	ret = fp(mode);

	log("fm_set_region_tune_mode return %d", ret);

	return ret;
}

static jint interlayer_fm_tune_freq(JNIEnv *env, jclass clazz, jint freq)
{
	log(" freq = %d", freq);

	int ret = -1;

	fm_tune_freq_t fp = (fm_tune_freq_t)dlsym(h_fm_lib, "fm_tune_freq");

	if (NULL == fp) {
		log("can not get method fm_tune_freq");
		return ret;
	}
	ret = fp(freq);

	log("fm_tune_freq return %d", ret);

	return ret;
}

static jint interlayer_fm_get_current_freq(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_get_current_freq_t fp = (fm_get_current_freq_t)dlsym(h_fm_lib, "fm_get_current_freq");

	if (NULL == fp) {
		log("can not get method fm_tune_freq");
		return ret;
	}
	ret = fp();

	log("fm_get_current_freq return %d", ret);

	return ret;
}

static jint interlayer_fm_set_search_rssi_threshold(JNIEnv *env, jclass clazz, jint threshold)
{
	log(" threshold = %d", threshold);
	return (jint)3;
}

static jint interlayer_fm_get_search_rssi_threshold(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_get_current_rssi(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_set_snr_threshold(JNIEnv *env, jclass clazz, jint threshold)
{
	log(" threshold = %d", threshold);
	return (jint)3;
}

static jint interlayer_fm_get_snr_threshold(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_get_current_snr(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_search(JNIEnv *env, jclass clazz, jint direct, jint freq)
{
	log(" direct = %d, freq = %d", direct, freq);

	int ret = -1;

	fm_search_t fp = (fm_search_t)dlsym(h_fm_lib, "fm_search");

	if (NULL == fp) {
		log("can not get method fm_search");
		return ret;
	}

	log("fm_search, fp = 0x%x h_fm_lib = 0x%x", fp, h_fm_lib);
	ret = fp(direct, freq);

	log("fm_search return %d", ret);

	return ret;
}

static jint interlayer_fm_auto_search(JNIEnv *env, jclass clazz, jint direct, jint freq, jint num)
{
	log(" direct = %d, freq = %d, num = %d", direct, freq, num);

	int ret = -1;

	fm_auto_search_t fp = (fm_auto_search_t)dlsym(h_fm_lib, "fm_auto_search");

	if (NULL == fp) {
		log("can not get method fm_auto_search");
		return ret;
	}

	log("fm_auto_search, fp = 0x%x h_fm_lib = 0x%x", fp, h_fm_lib);
	ret = fp(direct, freq, num);

	log("fm_auto_search return %d", ret);

	return ret;
}

static jint interlayer_fm_searchabort(JNIEnv *env, jclass clazz)
{
	log("");
//	return fm_searchabort();
	return (jint)3;
}

static jint interlayer_fm_set_search_steps(JNIEnv *env, jclass clazz, jint step)
{
	log(" step = %d", step);

	int ret = -1;

	fm_set_search_steps_t fp = (fm_set_search_steps_t)dlsym(h_fm_lib, "fm_set_search_steps");

	if (NULL == fp) {
		log("can not get method fm_set_search_steps");
		return ret;
	}

	ret = fp(step);

	log("fm_set_search_steps_t return %d", ret);

	return ret;
}

static jint interlayer_fm_get_search_steps(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_mute(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_mute_t fp = (fm_mute_t)dlsym(h_fm_lib, "fm_mute");

	if (NULL == fp) {
		log("can not get method fm_mute");
		return ret;
	}

	ret = fp();

	log("fm_mute return %d", ret);

	return ret;
}

static jint interlayer_fm_unmute(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_unmute_t fp = (fm_mute_t)dlsym(h_fm_lib, "fm_unmute");

	if (NULL == fp) {
		log("can not get method fm_unmute");
		return ret;
	}

	ret = fp();

	log("fm_unmute return %d", ret);

	return ret;
}

static jint interlayer_fm_get_mute_state(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_set_volume(JNIEnv *env, jclass clazz, jint volume)
{
	log("");

	int ret = -1;

	fm_set_volume_t fp = (fm_set_volume_t)dlsym(h_fm_lib, "fm_set_volume");

	if (NULL == fp) {
		log("can not get method fm_set_volume");
		return ret;
	}
	ret = fp(volume);

	log("fm_set_volume return %d", ret);

	return ret;
}

static jint interlayer_fm_get_volume(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_func_off(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_func_off_t fp = (fm_func_off_t)dlsym(h_fm_lib, "fm_func_off");

	if (NULL == fp) {
		log("can not get method fm_func_off");
		return ret;
	}
	ret = fp();

	log("fm_func_off return %d", ret);

	return ret;
}

static jint interlayer_fm_close(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_close_t fp = (fm_close_t)dlsym(h_fm_lib, "fm_close");

	if (NULL == fp) {
		log("can not get method fm_close");
		return ret;
	}
	ret = fp();

	log("fm_close return %d", ret);

	return ret;
}

static jint interlayer_fm_get_stereo_mono_status(JNIEnv *env, jclass clazz)
{
	log("");
	return (jint)3;
}

static jint interlayer_fm_get_power_state(JNIEnv *env, jclass clazz)
{
	log("");

	int ret = -1;

	fm_get_power_state_t fp = (fm_get_power_state_t)dlsym(h_fm_lib, "fm_get_power_state");

	if (NULL == fp) {
		log("can not get method fm_get_power_state");
		return ret;
	}
	ret = fp();

	log("fm_get_power_state return %d", ret);

	return ret;

}

static JNINativeMethod method_table[] = {
		{"fm_init",		 					"(Ljava/lang/Object;)I", (void *)interlayer_fm_init},
		{"fm_func_on", 						"()I", 		(void *)interlayer_fm_func_on},
		{"fm_get_region_tune_mode", 		"()I", 		(void *)interlayer_fm_get_region_tune_mode},
		{"fm_set_region_tune_mode", 		"(I)I", 	(void *)interlayer_fm_set_region_tune_mode},
		{"fm_tune_freq", 					"(I)I", 	(void *)interlayer_fm_tune_freq},
		{"fm_get_current_freq", 			"()I", 		(void *)interlayer_fm_get_current_freq},
		{"fm_set_search_rssi_threshold", 	"(I)I", 	(void *)interlayer_fm_set_search_rssi_threshold},
		{"fm_get_search_rssi_threshold", 	"()I", 		(void *)interlayer_fm_get_search_rssi_threshold},
		{"fm_get_current_rssi", 			"()I", 		(void *)interlayer_fm_get_current_rssi},
		{"fm_set_snr_threshold", 			"(I)I", 	(void *)interlayer_fm_set_snr_threshold},
		{"fm_get_snr_threshold", 			"()I", 		(void *)interlayer_fm_get_snr_threshold},
		{"fm_get_current_snr", 				"()I", 		(void *)interlayer_fm_get_current_snr},
		{"fm_search", 						"(II)I", 	(void *)interlayer_fm_search},
		{"fm_auto_search", 					"(III)I", 	(void *)interlayer_fm_auto_search},
		{"fm_searchabort", 					"()I", 		(void *)interlayer_fm_searchabort},
		{"fm_set_search_steps", 			"(I)I", 	(void *)interlayer_fm_set_search_steps},
		{"fm_get_search_steps", 			"()I", 		(void *)interlayer_fm_get_search_steps},
		{"fm_mute", 						"()I", 		(void *)interlayer_fm_mute},
		{"fm_unmute", 						"()I", 		(void *)interlayer_fm_unmute},
		{"fm_get_mute_state", 				"()I", 		(void *)interlayer_fm_get_mute_state},
		{"fm_set_volume", 					"(I)I", 	(void *)interlayer_fm_set_volume},
		{"fm_get_volume", 					"()I", 		(void *)interlayer_fm_get_volume},
		{"fm_func_off", 					"()I", 		(void *)interlayer_fm_func_off},
		{"fm_close", 						"()I", 		(void *)interlayer_fm_close},
		{"fm_get_stereo_mono_status", 		"()I", 		(void *)interlayer_fm_get_stereo_mono_status},
		{"fm_get_power_state",				"()I",		(void *)interlayer_fm_get_power_state},
};

static const char *classPathName = "com/borqs/fmradio/service/FMNative";

/*
 * Register several native methods for one class.
 */
static int registerNativeMethods(JNIEnv* env, const char* className,
    JNINativeMethod* gMethods, int numMethods)
{
     jclass clazz;
 
     clazz = env->FindClass(className);
     if (clazz == NULL) {
        LOGE("Native registration unable to find class '%s'", className);
         return JNI_FALSE;
     }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
         LOGE("RegisterNatives failed for '%s'", className);
         return JNI_FALSE;
     }
 
     return JNI_TRUE;
}

/*
 * Register native methods for all classes we know about.
 *
 * returns JNI_TRUE on success.
 */
static int registerNatives(JNIEnv* env)
{
   if (!registerNativeMethods(env, classPathName, method_table,
                  sizeof(method_table) / sizeof(method_table[0]))) {
     return JNI_FALSE;
   }
 
   return JNI_TRUE;
}

typedef union {
     JNIEnv* env;
     void* venv;
} UnionJNIEnvToVoid;
 

void set_cap() {
	log("");
    struct __user_cap_header_struct header;
    struct __user_cap_data_struct cap;
    header.version = _LINUX_CAPABILITY_VERSION;
    header.pid = 0;
    cap.effective = cap.permitted = 1 << CAP_NET_RAW |
                    1 << CAP_NET_ADMIN |
                    1 << CAP_NET_BIND_SERVICE;
    cap.inheritable = 0;
    capset(&header, &cap);
}

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	UnionJNIEnvToVoid uenv;
	uenv.venv = NULL;
	jint result = -1;
	JNIEnv* env = NULL;

	log("JNI_OnLoad");

	if (vm->GetEnv(&uenv.venv, JNI_VERSION_1_4) != JNI_OK) {
	LOGE("ERROR: GetEnv failed");
	 goto bail;
	}

	env = uenv.env;
	if (registerNatives(env) != JNI_TRUE) {
	 LOGE("ERROR: registerNatives failed");
	 goto bail;
	}

	h_fm_lib = dlopen("/system/lib/libfmradio.so", RTLD_LAZY);
	if (NULL == h_fm_lib) {
		log("open libfmradio.so field");
		goto bail;
	}

	result = JNI_VERSION_1_4;

	set_cap();
 
bail:
     return result;
}

void JNI_OnUnload(JavaVM* vm, void* reserved)
{
	log("[JNI_OnUnload]");

	dlclose(h_fm_lib);
	h_fm_lib = NULL;
}

