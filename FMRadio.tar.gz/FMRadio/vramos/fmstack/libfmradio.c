/*********************************************************************
 *
 *  Copyright (c) 2010, Broadcom Corp., All Rights Reserved.
 *  Broadcom Bluetooth Core. Proprietary and confidential.
 *
 *********************************************************************/

#include <stdio.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/socket.h>
#include "bluetooth/bluetooth.h"
#include "bluetooth/hci.h"
#include "bluetooth/hci_lib.h"


#include "fmradio.h"
#include "bta_fm_hwhdr.h"

#define HCI_CMD_BUFSIZE	100

#define FM_WRITE	0x00
#define FM_READ		0x01

#define FM_DEBUG	1

static int dd=0;
static uint16_t expect_event;
static int fm_preset_search_flag=0;
static int fm_stereo_mono_flag=0;

static pthread_t recv_thread;
static pthread_t interrupt_thread;

static pthread_mutex_t	send_cmd_mutex;
static pthread_mutex_t	fm_interrupt_mutex;
static pthread_cond_t	send_cmd_cond;
static pthread_cond_t	fm_interrupt_cond;
static uint16_t fm_interrupt_num = 0;

static fm_callbacks fm_cbs;
static fm_ctrl_block fm_block;

static uint16_t fm_rds_flag=0;

static unsigned char snr_search_supported=0;

fm_ctrl_block fm_block_default = {
	26000, // start freq = 90MHz
	200,
	100,
	FM_TUNE_AUTOSTEREO | FM_REGION_EUR,	// default region FM_REGION_EUR
	0,	// rssi
	100,	// rssi_threshold
	0,	// snr
	7, 	// snr_threshold
	FM_MUTE_OFF
};

#ifdef	FM_DEBUG
void
dump(uint8_t *buf, int len)
{
	int i;

	for (i = 0; i < len; i++) {
		if (i && !(i % 16)) {
			fprintf(stderr, "\n");
		}

		fprintf(stderr, "%02x ", buf[i]);
	}

	fprintf(stderr, "\n");
}
#endif

static int
fm_sleep(int msecond)
{
		struct timeval timeout;
		int r;
		
		timeout.tv_sec = 0;
		timeout.tv_usec = msecond * 1000;
		
		r = select(0, NULL, NULL, NULL, &timeout);
		return r;
}

static int
fm_send_cmd(uint8_t i2caddr, uint8_t rw, uint8_t plen, uint8_t *param)
{
	uint8_t buf[HCI_CMD_BUFSIZE];
	int cmdlen = 0;
	int r;

	if (rw == FM_WRITE) {
		buf[0] = i2caddr;
		buf[1] = rw;
		cmdlen = plen + 2;
		if (param == NULL)
			return -1;
		memcpy((uint8_t *)buf+2, param, plen);
	}
	else if (rw == FM_READ) {
		buf[0] = i2caddr;
		buf[1] = rw;
		buf[2] = plen;
		cmdlen = 3;		
	}
#ifdef FM_DEBUG
	fprintf(stderr, "sent cmd %d\n", cmdlen);
	dump(buf, cmdlen);
#endif
	pthread_mutex_lock(&send_cmd_mutex);
	r = hci_send_cmd(dd, 0x3f, 0x15, cmdlen, &buf);
	pthread_cond_wait(&send_cmd_cond, &send_cmd_mutex);
	pthread_mutex_unlock(&send_cmd_mutex);

	return r;
}

static int fm_i2s_set_441(void)
{
	int ret = 0;
	unsigned char UIPC_OPEN_REQ[] = {0x08, 0x90, 0x00};
	unsigned char AUDIO_ROUTE_CONFIG_REQ[] = {0x05, 
				0x90, 0x17, 0x00, 0xff, 0x20, 0xff, 0x03, 0x06};

	ret= hci_send_cmd(dd, 0x3f, 0x8b, sizeof(UIPC_OPEN_REQ), UIPC_OPEN_REQ);
	//system("hcitool cmd 0x3f 0x8b 0x08 0x90 0x00");

	

	usleep(10000);
	//pthread_mutex_lock(&send_cmd_mutex);
	//system("hcitool cmd 0x3f 0x8b 0x05 0x90 0x17 0x00 0xff 0x20 0xff 0x03 0x06");

	ret= hci_send_cmd(dd, 0x3f, 0x8b, sizeof(AUDIO_ROUTE_CONFIG_REQ), AUDIO_ROUTE_CONFIG_REQ);
	//pthread_cond_wait(&send_cmd_cond, &send_cmd_mutex);
	//pthread_mutex_unlock(&send_cmd_mutex);

	return ret;
}

static int fm_i2s_disable_441(void)
{
	int ret = 0;
	unsigned char UIPC_CLOSE_REQ[] = {0x08, 0x90, 0x02};
	unsigned char AUDIO_ROUTE_CONFIG_REQ[] = {0x05, 
				0x90, 0x17, 0x80, 0xff, 0x00, 0xff, 0xff, 0x06};

	ret= hci_send_cmd(dd, 0x3f, 0x8b, sizeof(AUDIO_ROUTE_CONFIG_REQ), AUDIO_ROUTE_CONFIG_REQ);	

	usleep(10000);

	ret= hci_send_cmd(dd, 0x3f, 0x8b, sizeof(UIPC_CLOSE_REQ), UIPC_CLOSE_REQ);

	return ret;
}

static int
fm_set_channel_freq(uint16_t freq)
{
	uint8_t	fm_freq[2];
	int r;

	fm_freq[0] = freq & 0xFF;
	fm_freq[1] = freq >> 8;
	r = fm_send_cmd(I2C_FM_REG_FM_FREQ, FM_WRITE, 2, fm_freq);
	return r;
}

static int
fm_set_mask_bits(uint16_t mask)
{
	uint8_t fm_mask[2];
	int r;

	fprintf(stderr, "fm_set_mask_bits mask = %d\n", mask);

	fm_mask[0] = mask & 0xFF;
	fm_mask[1] = mask >> 8;
	r = fm_send_cmd(I2C_FM_REG_FM_RDS_MSK, FM_WRITE, 2, fm_mask);
	return r;
}

static int
fm_set_search_tune_mode(uint8_t mode)
{
	uint8_t tune_mode;
	int r;

	tune_mode = mode & 0x3;
	r = fm_send_cmd(I2C_FM_REG_SCH_TUNE, FM_WRITE, 1, &tune_mode);
	return r;
}

static int
fm_set_search_method(uint8_t method)
{
	uint8_t search_method;
	int r;

	search_method = method;
	r = fm_send_cmd(I2C_FM_SEARCH_METHOD, FM_WRITE, 1, &search_method);
	return r;
}

static int
fm_set_audio_ctrl_flag(uint16_t flag)
{
	uint8_t ctrl_flag[2];
	int r;

	ctrl_flag[0] = flag & 0xFF;
	ctrl_flag[1] = flag >> 8;

	r = fm_send_cmd(I2C_FM_REG_AUD_CTL0, FM_WRITE, 2, ctrl_flag);
	return r;
}

static int
fm_set_max_preset_channels(uint8_t num)
{
	uint8_t preset_channels;
	int r;

	preset_channels = num;
	r = fm_send_cmd(I2C_FM_REG_PRESET_MAX, FM_WRITE, 1, &preset_channels);
	return r;
}

static int
fm_set_search_ctrl(uint8_t ctrl)
{
	uint8_t search_ctrl;
	int r;

	search_ctrl = ctrl;
	r = fm_send_cmd(I2C_FM_REG_SCH_CTL0, FM_WRITE, 1, &search_ctrl);
	return r;
}

static int
fm_set_fm_rds_reg(uint8_t fm_rds_reg)
{
	uint8_t fm_rds[1];
	int r;

	fm_rds[0] = fm_rds_reg;
	r = fm_send_cmd(I2C_FM_REG_RDS_SYS, FM_WRITE, 1, fm_rds);

	// delay 20 millisecond
	fm_sleep(20);
	return r;
}

void *
fm_recv_thread(void *arg)
{
	int len = 3;
	int count;
	int fd = (int)arg;
	uint8_t buf[1024];
	struct iovec iv;
	struct msghdr msg;
	uint8_t ctrl[100];

	iv.iov_base = buf;
	iv.iov_len = 1024 + 4;

	msg.msg_iov = &iv;
	msg.msg_iovlen = 1;
	msg.msg_control = ctrl;
	msg.msg_controllen = 100;

	while ((count = recvmsg(fd, &msg, 0)) > 0) {
#ifdef FM_DEBUG
		fprintf(stderr, "received %d\n", count);
		dump(buf, count);
#endif

		if (buf[1] == 0xff) {	// VSE event
			// check the VSE is FM interrupt, 0x04 0xff 0x01 0x08
			if ((buf[2] == 0x01)&&(buf[3] == 0x08)) {
#ifdef FM_DEBUG
				fprintf(stderr, "recv fm interrupt\n");
#endif		
				pthread_mutex_lock(&fm_interrupt_mutex);
				fm_interrupt_num ++;
#ifdef FM_DEBUG
				if (fm_interrupt_num >= 2)
					fprintf(stderr, "fm interrupt num = %d\n", fm_interrupt_num);
#endif
				pthread_cond_signal(&fm_interrupt_cond);
				pthread_mutex_unlock(&fm_interrupt_mutex);
			}
		}
		else if (buf[1] == 0x0e) {	// command complete
			// check event start with 0xXX(param lenth) 0x01 0x15 0xfc
			if ((buf[2] == (count - 3))&&(buf[3] == 0x01)
				&&(buf[4] == 0x15)&&(buf[5] == 0xfc))
			{
				// check event status and read event
				if ((buf[6] == 0x0)&&(buf[8] == 0x01)){
					switch(buf[7]){
					case I2C_FM_REG_FM_RDS_FLAG:
						fm_rds_flag = ((uint16_t)buf[10]<<8)|buf[9];
						if (fm_stereo_mono_flag == 1) {
							if (fm_rds_flag & I2C_MASK_STEREO_DETC_BIT) {
								if (fm_cbs.stereo_mono_status_cb != NULL)
									(*fm_cbs.stereo_mono_status_cb)(FM_AUDIO_STEREO);
							} else {
								if (fm_cbs.stereo_mono_status_cb != NULL)
									(*fm_cbs.stereo_mono_status_cb)(FM_AUDIO_MONO);
							}
							fm_stereo_mono_flag = 0;
						}
						break;
					case I2C_FM_REG_RDS_SYS:
						if (fm_cbs.region_tune_cb != NULL)
							(*fm_cbs.power_state_cb)(buf[9] & I2C_FM_ON);
						break;
					case I2C_FM_REG_FM_CTRL: // region, stereo&mono
						fm_block.region_tune_mode = (buf[9]&0x3);
						if (fm_cbs.region_tune_cb != NULL)
							(*fm_cbs.region_tune_cb)(fm_block.region_tune_mode);
						break;
					case I2C_FM_REG_AUD_CTL0: // mute_state
						fm_block.mute_state = ((buf[9]&0x2) >>1);
						if (fm_cbs.mute_state_cb != NULL)
							(*fm_cbs.mute_state_cb)(fm_block.mute_state);
						break;
					case I2C_FM_REG_SCH_CTL0: // threshold
						fm_block.rssi_thresh = buf[9]&0x7f;
						if (fm_cbs.rssi_threshold_cb != NULL)
							(*fm_cbs.rssi_threshold_cb)(fm_block.rssi_thresh);
						break;
					case I2C_FM_SEARCH_SNR: // SNR threshold
						fm_block.snr_thresh = buf[9]&0x7f;
						if (fm_cbs.snr_threshold_cb !=NULL)
							(*fm_cbs.snr_threshold_cb)(fm_block.snr_thresh);
						break;
					case I2C_FM_REG_FM_FREQ: // freq, 0x0a
						fm_block.freq = ((uint16_t)buf[10]<<8)|buf[9];
						if (fm_cbs.channel_freq_cb != NULL)
							(*fm_cbs.channel_freq_cb)(fm_block.freq);
						break;
					case I2C_FM_REG_RSSI: // rssi, 0x0f
						fm_block.rssi = buf[9];
						if (fm_cbs.current_rssi_cb != NULL)
							(*fm_cbs.current_rssi_cb)(fm_block.rssi);
						break;
					case I2C_FM_REG_SNR: // snr, 0xdf
						fm_block.snr = buf[9];
						if (fm_cbs.current_snr_cb != NULL);
							(*fm_cbs.current_snr_cb)(fm_block.snr);
						break;
					case I2C_FM_REG_VOLUME_CTRL: // volume, 0xf8
						fm_block.volume = ((uint16_t)buf[10]<<8)|buf[9];
						if (fm_cbs.volume_gain_cb != NULL)
							(*fm_cbs.volume_gain_cb)(fm_block.volume);
						break;
					case I2C_FM_REG_SCH_STEP: // step, 0xfd
						fm_block.steps = buf[9];
						if (fm_cbs.search_steps_cb != NULL)
							(*fm_cbs.search_steps_cb)(fm_block.steps);
						break;
					case I2C_FM_REG_PRESET_STA: // preset, 0xff
						if (fm_cbs.preset_channel_cb != NULL)
							(*fm_cbs.preset_channel_cb)(count-9, &buf[9]);
						break;
					}
				}
				pthread_mutex_lock(&send_cmd_mutex);
				pthread_cond_signal(&send_cmd_cond);
				pthread_mutex_unlock(&send_cmd_mutex);

				if (buf[6] != 0x0) {
#ifdef FM_DEBUG
					fprintf(stderr, "fm ic2 addr %d status error, %d\n",
						buf[7], buf[6]);
#endif
				}
			}
			else if ((buf[2] == (count - 3))&&(buf[3] == 0x01)
				&&(buf[4] == 0x79)&&(buf[5] == 0xfc)) {
				unsigned char chip_id = 0;
				
				chip_id = buf[7];	
				switch(chip_id) {
				case 0x29: // BCM4329B1
					snr_search_supported = 0;
					break;
				case 0x3B: // BCM2049C0
				case 0x3E: // BCM4330B1
				case 0x43: // BCM4330B2
					snr_search_supported = 1;
					break;
				default:
#ifdef FM_DEBUG
					fprintf(stderr, "unlisted chip.\n");
#endif
					break;
				}
			}

		}
		else {
			// not expected event
		}
	}
	return 0;
}

void *
fm_interrupt_thread(void *arg)
{
	for (;;) {
		pthread_mutex_lock(&fm_interrupt_mutex);
		if (fm_interrupt_num <= 0)
			pthread_cond_wait(&fm_interrupt_cond, &fm_interrupt_mutex);
		fm_interrupt_num --;
		pthread_mutex_unlock(&fm_interrupt_mutex);

		fprintf(stderr, "fm_interrupt_thread, got interrupt\n");

		fm_send_cmd(I2C_FM_REG_FM_RDS_FLAG, FM_READ, 2, NULL);
	
		if (fm_rds_flag & (I2C_MASK_SRH_TUNE_CMPL_BIT | I2C_MASK_SRH_TUNE_FAIL_BIT)) {
			fprintf(stderr, "fm_interrupt_thread, fm_rds_flag = %d\n", fm_rds_flag);
			//search finish
			if (fm_preset_search_flag != 0) {
				fm_send_cmd(I2C_FM_REG_PRESET_STA, FM_READ, 120, NULL); // read 40 channels
				fm_preset_search_flag = 0;
			}

			// read FM freq
			fm_get_current_freq();

			// read rssi
			fm_get_current_rssi();
			
			fm_unmute();		

			if (snr_search_supported == 1) {
				// delay 800ms to get the stable snr
				fm_sleep(800);
				// read snr
				fm_get_current_snr();
			}
		}
	}

	return 0;
}

int 
fm_init(fm_callbacks *cbs)
{
	fprintf(stderr, "libfmradio: fm_init, cbs = 0x%x\n", cbs);
	int dev_id;
	int policy;
	struct sched_param param;
	
	pthread_attr_t thread_attr0;
	pthread_attr_t thread_attr1;

	struct hci_filter flt;

	memcpy(&fm_cbs, cbs, sizeof(fm_callbacks));
	dev_id = hci_get_route(NULL);
	if (dev_id < 0) {
#ifdef FM_DEBUG
		fprintf(stderr, "fm_init failed, dev_id=%d\n", dev_id);
		perror("hci_get_route failed");
#endif
		return -1;
	}

	dd = hci_open_dev(dev_id);
	if (dd == -1) {
		return -2;
	}

	hci_filter_clear(&flt);
	hci_filter_set_ptype(HCI_VENDOR_PKT, &flt);
	hci_filter_set_ptype(HCI_EVENT_PKT, &flt);
	hci_filter_set_event(EVT_CMD_COMPLETE, &flt);
	hci_filter_set_event(EVT_VENDOR, &flt);

	if (setsockopt(dd, SOL_HCI, HCI_FILTER, &flt, sizeof(flt)) < 0) {
		perror("HCI filter setup failed");
		return -3;
	}
	
	pthread_mutex_init(&send_cmd_mutex, NULL);
	pthread_mutex_init(&fm_interrupt_mutex, NULL);
	pthread_cond_init(&send_cmd_cond, NULL);
	pthread_cond_init(&fm_interrupt_cond, NULL);
	fm_interrupt_num = 0;

	// create the FM recv thread
	pthread_attr_init(&thread_attr0);
	pthread_attr_setdetachstate(&thread_attr0, PTHREAD_CREATE_DETACHED);

	pthread_create(&recv_thread, &thread_attr0, fm_recv_thread, (void *)dd);

	// create the FM interrupt handle thread
	pthread_attr_init(&thread_attr1);
	pthread_attr_setdetachstate(&thread_attr1, PTHREAD_CREATE_DETACHED);

	pthread_create(&interrupt_thread, &thread_attr1, fm_interrupt_thread, (void *)NULL);

	// read the chip id info
#ifdef FM_DEBUG
	fprintf(stderr,"read the chip id info.\n");
#endif
	hci_send_cmd(dd, 0x3f, 0x79, 0, NULL);

	return 0;
}

int
fm_func_on(void)
{
	fprintf(stderr, "libfmradio: fm_func_on\n");
	uint8_t fm_rds[1];
	uint8_t fm_rds_ctrl;
	uint8_t reg_fm_ctrl;
	uint8_t audio_ctrl[2];
	uint8_t fm_mask[2];
	uint8_t search_mode;
	int8_t fm_stereo_blend_reg[8];
	int r;

	memcpy(&fm_block, &fm_block_default, sizeof(fm_block));
	// enable FM and RDS function, hardcode to FM_ON only
	fm_set_fm_rds_reg(I2C_FM_ON);
//	fm_set_fm_rds_reg(0x03);

//	fm_rds_ctrl = 0x03;
//	fm_send_cmd(I2C_FM_REG_RDS_CTL0, FM_WRITE, 1, &fm_rds_ctrl);

	fm_set_region_tune_mode(fm_block_default.region_tune_mode);

	// set FM audio ctrl flag
	//fm_set_audio_ctrl_flag(I2C_RF_MUTE | I2C_Z_MUTE_LEFT_OFF | I2C_Z_MUTE_RITE_OFF | I2C_AUDIO_DAC_ON | I2C_DEEMPHA_75_ON);
	//fm_set_audio_ctrl_flag(I2C_RF_MUTE | I2C_Z_MUTE_LEFT_OFF | I2C_Z_MUTE_RITE_OFF | I2C_AUDIO_I2S_ON | I2C_DEEMPHA_75_ON);
	fm_set_audio_ctrl_flag(I2C_Z_MUTE_LEFT_OFF | I2C_Z_MUTE_RITE_OFF | I2C_AUDIO_DAC_ON | I2C_DEEMPHA_75_ON);

	fm_i2s_disable_441();
	fm_i2s_set_441();
	
	// set the I2C_FM_REG_BLEND_MUTE
	fm_stereo_blend_reg[0] = 43; //30;  // start SNR, default is 43
	fm_stereo_blend_reg[1] = 20;  // stop SNR, default is 26
	fm_stereo_blend_reg[2] = -56;  // 0xC8
	fm_stereo_blend_reg[3] = -100; // default is -85;  // 0xAB
	fm_stereo_blend_reg[4] = 10; // start mute, 0x0A
	fm_stereo_blend_reg[5] = 0x1E;
	fm_stereo_blend_reg[6] = 0x09;
	fm_stereo_blend_reg[7] = -81; // 0xAF
	fm_send_cmd(I2C_FM_REG_BLEND_MUTE, FM_WRITE, 8, fm_stereo_blend_reg);
	
	// tune to freq
	r = fm_tune_freq(fm_block_default.freq);
		
	//fm_i2s_set_441();

	return r;
}

int
fm_get_power_state(void) {

	int r;
	r = fm_send_cmd(I2C_FM_REG_RDS_SYS, FM_READ, 1, NULL);

	// delay 20 millisecond
//	fm_sleep(20);
	return r;
}

int
fm_get_region_tune_mode(void)
{
	int r;
	
	r = fm_send_cmd(I2C_FM_REG_FM_CTRL, FM_READ, 1, NULL);
	return r;
}

int
fm_set_region_tune_mode(uint8_t mode)
{
	uint8_t reg_ctrl;
	int r;

	switch (mode & 0x3) {
	case 0:	// europe mono
		reg_ctrl = I2C_BAND_REG_WEST;
		break;
	case 1:	// japan mono
		reg_ctrl = I2C_BAND_REG_EAST;
		break;
	case 2:	// europe stereo
		reg_ctrl = I2C_BAND_REG_WEST | I2C_STEREO_AUTO; // blend
		break;
	case 3: // japan stereo
		reg_ctrl = I2C_BAND_REG_EAST | I2C_STEREO_AUTO; // blend
		break;
	}
	r = fm_send_cmd(I2C_FM_REG_FM_CTRL, FM_WRITE, 1, &reg_ctrl);
	return r;
}

int 
fm_tune_freq(uint16_t freq)
{
	int r;

	fm_set_channel_freq(freq);
	
	fm_set_mask_bits(I2C_MASK_SRH_TUNE_CMPL_BIT | I2C_MASK_SRH_TUNE_FAIL_BIT);

	r = fm_set_search_tune_mode(I2C_FM_SEARCH_PRESET); 
	return r;
}

int
fm_get_current_freq(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_FM_FREQ, FM_READ, 2, NULL);
	return r;
}

int
fm_set_search_rssi_threshold(uint8_t threshold)
{
	int r;

	fm_block.rssi_thresh = threshold;
	r = fm_set_search_ctrl(threshold);
	return r;
}

int
fm_get_search_rssi_threshold(void)
{
	int r;
	
	r = fm_send_cmd(I2C_FM_REG_SCH_CTL0, FM_READ, 1, NULL);
	return r;
}

int
fm_get_current_rssi(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_RSSI, FM_READ, 1, NULL);
	return r;
}

int
fm_set_snr_threshold(uint8_t threshold)
{
	uint8_t snr_thresh = threshold;
	int r;

	fm_block.snr_thresh = threshold;
	r = fm_send_cmd(I2C_FM_SEARCH_SNR, FM_WRITE, 1, &snr_thresh);
	return r;
}

int
fm_get_snr_threshold()
{
	int r;

	r = fm_send_cmd(I2C_FM_SEARCH_SNR, FM_READ, 1, NULL);
	return r;
}

int
fm_get_current_snr(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_SNR, FM_READ, 1, NULL);
	return r;
}

int
fm_search(uint8_t direct, uint16_t freq)
{
	uint8_t search_ctrl;
	uint8_t snr_threshold[1];
	int r;

	fm_set_search_method(I2C_FM_SEARCH_NORMAL);
	
	if (snr_search_supported == 1) {
		snr_threshold[0] = fm_block.snr_thresh; // SNR search threshold, for 4330
		fm_send_cmd(I2C_FM_SEARCH_SNR, FM_WRITE, 1, snr_threshold);
	}

	fm_mute();

	fm_set_max_preset_channels(0);

	search_ctrl = fm_block.rssi_thresh;
	if (direct == FM_SEARCH_UP)
		search_ctrl |= 0x80;

	fm_set_search_ctrl(search_ctrl);

	fm_set_channel_freq(freq);

	fm_set_mask_bits(I2C_MASK_SRH_TUNE_CMPL_BIT | I2C_MASK_SRH_TUNE_FAIL_BIT);

	r = fm_set_search_tune_mode(I2C_AUTO_SCH_MODE);
	return r;
}

int
fm_auto_search(uint8_t direct, uint16_t freq, uint8_t num)
{
	fprintf(stderr, "libfmradio: fm_auto_search, direct = %d, freq = %d, num = %d\n", direct, freq, num);
	uint8_t search_ctrl;
	uint8_t pre_quality[1];
	uint8_t max_channel[1];
	uint8_t snr_threshold[1];
	int r;

	fm_preset_search_flag = 1;
	fm_set_search_method(I2C_FM_SEARCH_PRESET);
	
	pre_quality[0] = 35; // hardcode 0x46
	fm_send_cmd(I2C_FM_RES_PRESCAN_QUALITY, FM_WRITE, 1, pre_quality);

	if (snr_search_supported == 1) {
		snr_threshold[0] = fm_block.snr_thresh; // 0x07; //SNR search threshold, for 4330
		fm_send_cmd(I2C_FM_SEARCH_SNR, FM_WRITE, 1, snr_threshold);
	}

	fm_mute();

	max_channel[0] = num;
	fm_send_cmd(I2C_FM_REG_PRESET_MAX, FM_WRITE, 1, max_channel);

	search_ctrl = fm_block.rssi_thresh;
	if (direct == FM_SEARCH_UP)
		search_ctrl |= 0x80;
	fm_set_search_ctrl(search_ctrl);

	fm_set_channel_freq(freq);

	fm_set_mask_bits(I2C_MASK_SRH_TUNE_CMPL_BIT | I2C_MASK_SRH_TUNE_FAIL_BIT);

	r = fm_set_search_tune_mode(I2C_AUTO_SCH_MODE);

	return r;
}

int
fm_searchabort(void)
{
	int r;

	r = fm_set_search_tune_mode(I2C_IDLE_MODE);

	return r;
}

int
fm_set_search_steps(uint8_t steps)
{
	uint8_t search_steps[2];
	int r;

	search_steps[0] = steps;
	search_steps[1] = 0;
	r = fm_send_cmd(I2C_FM_REG_SCH_STEP, FM_WRITE, 2, search_steps);

	return r;
}

int
fm_get_search_steps(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_SCH_STEP, FM_READ, 2, NULL);

	return r;
}

int
fm_mute(void)
{
	int r;

	r = fm_set_audio_ctrl_flag(I2C_RF_MUTE | I2C_MANUAL_MUTE | I2C_Z_MUTE_LEFT_OFF |
				I2C_Z_MUTE_RITE_OFF | I2C_AUDIO_DAC_ON | I2C_DEEMPHA_75_ON);

	return r;
}

int
fm_unmute(void)
{
	int r;

	r = fm_set_audio_ctrl_flag(I2C_RF_MUTE | I2C_Z_MUTE_LEFT_OFF | I2C_Z_MUTE_RITE_OFF |
				I2C_AUDIO_DAC_ON | I2C_DEEMPHA_75_ON);

	return r;
}

int
fm_get_mute_state(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_AUD_CTL0, FM_READ, 2, NULL);

	return r;
}

int
fm_set_volume(uint16_t volume)
{
	uint8_t fm_volume[2];
	int r;

	fm_volume[0] = volume & 0xFF;
	fm_volume[1] = volume >> 8;
	r = fm_send_cmd(I2C_FM_REG_VOLUME_CTRL, FM_WRITE, 2, fm_volume);
	return r;
}

int
fm_get_volume(void)
{
	int r;

	r = fm_send_cmd(I2C_FM_REG_VOLUME_CTRL, FM_READ, 2, NULL);

	return r;
}

int
fm_func_off(void)
{
	uint8_t audio_ctrl[2];
	int r;

    fm_i2s_disable_441();
	// set FM audio to manual mute state
	audio_ctrl[0] = I2C_MANUAL_MUTE;
	audio_ctrl[1] = 0;
	fm_send_cmd(I2C_FM_REG_AUD_CTL0, FM_WRITE, 2, audio_ctrl);

	// disable FM function
	r = fm_set_fm_rds_reg(0);

	return r;
}

int
fm_close(void)
{
	// kill threads, close socket
	pthread_detach(recv_thread);
	pthread_detach(interrupt_thread);

	hci_close_dev(dd);

	return 0;
}

int
fm_get_stereo_mono_status(void)
{
	fm_stereo_mono_flag = 1;
	int r;
		
	r = fm_send_cmd(I2C_FM_REG_FM_RDS_FLAG, FM_READ, 2, NULL);
		
	return r;
}
