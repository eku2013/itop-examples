package com.borqs.fmradio.unittests.model;

import com.borqs.fmradio.model.ChannelHolder;

import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.MediumTest;
/**
 * Test class ChannelHolder.
 * @author b523
 *
 */
public class ChannelHolderTest extends InstrumentationTestCase{

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	// test cases
	
	/**
	 * Test getInstance() method.
	 */
	@MediumTest
	public void testGetInstance() throws Exception{
		assertNotNull(ChannelHolder.getInstance());
	}
}
