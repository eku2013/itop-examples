package com.borqs.fmradio.unittests.testutil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

/**
 * This class encapsulate some public static method.
 * 
 * @author maying
 */
public class Helper {
	public static final int WAIT_FOR_LLONGTIME = 10000;// wait for long time
	public static final int WAIT_FOR_LONGTIME = 4000;// wait for long time
	public static final int WAIT_FOR_MORELONGTIME = 5000;// wait for medium time
	public static final int WAIT_FOR_MIDDLETIME = 2000;// wait for medium time
	public static final int WAIT_FOR_SHORTTIME = 1000;// wait for short time

	public static final boolean LOG_CTR = true;// for output log info
	public static final String SDCARDPATH = "/tmp";

	
	public static class HardKey {
		public static void down(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_DOWN);
			inst.waitForIdleSync();
		}

		public static void up(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_UP);
			inst.waitForIdleSync();
		}

		public static void enter(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_ENTER);
			inst.waitForIdleSync();
		}

		public static void left(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_LEFT);
			inst.waitForIdleSync();
		}

		public static void right(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_RIGHT);
			inst.waitForIdleSync();
		}

		public static void center(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_CENTER);
			inst.waitForIdleSync();
		}

		public static void back(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
			inst.waitForIdleSync();
		}

		public static void call(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_CALL);
			inst.waitForIdleSync();
		}

		public static void endCall(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_ENDCALL);
			inst.waitForIdleSync();
		}

		public static void space(Instrumentation inst) {
			inst.sendKeyDownUpSync(KeyEvent.KEYCODE_SPACE);
			inst.waitForIdleSync();
		}
	}

	// catch the new start Activity
	public static Activity waitForActivity(
			Instrumentation.ActivityMonitor monitor) {
		Activity act = monitor.getLastActivity();
		int timeElapsed = 0;
		while ((act == null) && (timeElapsed < WAIT_FOR_LONGTIME)) {
			SystemClock.sleep(100);
			timeElapsed += 100;
			act = monitor.getLastActivity();
		}
		return act;

	}

	public static int removeMonitor(Instrumentation inst,
			Instrumentation.ActivityMonitor monitor) {
		int filterCount = monitor.getHits();
		int timeElapsed = 0;
		while ((filterCount == 0) && (timeElapsed < WAIT_FOR_LONGTIME)) {
			SystemClock.sleep(100);
			timeElapsed += 100;
			filterCount = monitor.getHits();
		}
		inst.removeMonitor(monitor);
		return filterCount;
	}

	/**
	 * Click on the center point of the view
	 * 
	 * @param inst
	 *            Instrumentation object.
	 * @param v
	 *            The view to be clicked on.
	 */
	// some times not work
	public static void clickOn(Instrumentation inst, View v) {
		int[] location = { 0, 0 };
		v.getLocationOnScreen(location);

		location[0] += (v.getWidth() / 2);
		location[1] += (v.getHeight() / 2);

		long downTime = SystemClock.uptimeMillis();
		MotionEvent mv = MotionEvent.obtain(downTime, SystemClock
				.uptimeMillis(), KeyEvent.ACTION_DOWN, location[0],
				location[1], 0);
		inst.sendPointerSync(mv);
		SystemClock.sleep(300);
		mv = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(),
				KeyEvent.ACTION_UP, location[0], location[1], 0);
		inst.sendPointerSync(mv);
		inst.waitForIdleSync();
		SystemClock.sleep(2000);
	}
	/**
	 * This method copy file from asserts to sdcard.
	 * 
	 * @param mContext
	 * @param filename
	 * @throws Exception
	 */
	public static void createFileToSdcard(Context mContext, String filename,
			String srcFolder) {
		AssetManager a = mContext.getAssets();
		InputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = a.open(filename);

			File myFilePath = new File(srcFolder);
			if (!myFilePath.exists()) {
				myFilePath.mkdir();
			}

			String src = srcFolder + "/" + filename;
			fos = new FileOutputStream(src);
			byte[] buff = new byte[1024];
			int readed = -1;
			while ((readed = fis.read(buff)) > 0) {
				fos.write(buff, 0, readed);
			}
			fos.flush();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	// delete file
	/**
	 * This method can delete file and folder.
	 */
	public static void deleteFileAndFolder(String path) {
		File file = new File(path);
		if (file.isDirectory()) {
			for (File f : file.listFiles()) {
				if (f.isDirectory()) {
					deleteFileAndFolder(f.getAbsolutePath());
				} else {
					f.delete();
				}
			}
		}
		file.delete();
	}

	/**
	 * This method will delete all file and folder in path,no delete path
	 * 
	 * @param path
	 */
	public static void deleteAllFileAndFolderExceptSelf(String path) {
		File file = new File(path);
		if (file.isDirectory()) {
			for (File f : file.listFiles()) {
				if (f.isDirectory()) {
					deleteFileAndFolder(f.getAbsolutePath());
				} else {
					f.delete();
				}
			}
		}
	}
	
	/**
	 * This method can create a folder.
	 * @param path
	 */
	public static void createFolder(String path) {
		try{
			File file = new File(path);
			if (!file.exists()) {
				file.mkdir();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
