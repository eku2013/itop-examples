/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.util;

public class Constants {
    //service intent
	public static final String RT_CHANGED = "borqs.fmradio.intent.RT_CHANGED";
	public static final String PS_CHANGED = "borqs.fmradio.intent.PS_CHANGED";
	public static final String STEREO_CHANGED = "borqs.fmradio.intent.STEREO_CHANGED";
    public static final String GET_FM_STATUS = "borqs.fmradio.intent.GET_FM_STATUS";
    public static final String ENABLE_FM = "borqs.fmradio.intent.ENABLE_FM";
    public static final String DISABLE_FM = "borqs.fmradio.intent.DISABLE_FM";
    public static final String ADD_STATION = "borqs.fmradio.intent.ADD_STATION";
    public static final String FM_FORWARD = "borqs.fmradio.intent.FM_FORWARD";
    public static final String FM_NEXT = "borqs.fmradio.intent.FM_NEXT";
    public static final String FM_PREV = "borqs.fmradio.intent.FM_PREV";
    public static final String FM_REW = "borqs.fmradio.intent.FM_REW";
    public static final String START_SCAN_ALL = "borqs.fmradio.intent.START_SCAN_ALL";
    public static final String SET_CHANNEL = "borqs.fmradio.intent.SET_CHANNEL";
    public static final String SET_SCROLL_CHANNEL = "borqs.fmradio.intent.SET_SCROLL_CHANNEL";
    public static final String MUTE_PHONE = "borqs.fmradio.intent.MUTE_PHONE";
    public static final String ALARM_PHONE = "borqs.fmradio.intent.ALARM_PHONE";
    public static final String GET_CHANNEL = "borqs.fmradio.intent.GET_CHANNEL";
    public static final String SCAN_FINISH = "borqs.fmradio.intent.SCAN_FINISH";
    public static final String FOUND_CHANNEL = "borqs.fmradio.intent.FOUND_CHANNEL";
    public static final String STOP_SCAN = "borqs.fmradio.intent.STOP_SCAN";
    public static final String STOP_SEEK = "borqs.fmradio.intent.STOP_SEEK";
    public static final String SPEAKER_CHANGE_ACTION = "borqs.fmradio.intent.SPEAKER_CHANGE_ACTION";
    public static final String SET_SPEAKER = "borqs.fmradio.intent.SET_SPEAKER";
    public static final String SET_TIME = "borqs.fmradio.intnet.SET_TIME";
    public static final String FINISH_FM = "borqs.fmradio.intent.FINISH_FM";
    public static final String SET_MUTE = "borqs.fmradio.intent.SET_MUTE";
    public static final String SET_UNMUTE = "borqs.fmradio.intent.SET_UNMUTE";
    public static final String SET_MONO = "borqs.fmradio.intent.SET_MONO";
    public static final String SET_STEREO = "borqs.fmradio.intent.SET_STEREO";
    public static final String UPDATE_CONFIGURE = "borqs.fmradio.intent.UPDATE_CONFIGURE";

    public static final String SCAN_ALREADY_STOP = "borqe.fmradio.intent.SCAN_ALREADY_STOP";
    public static final String FM_AUDIOFOCUS = "borqs.fmradio.intent.FM_AUDIOFOCUS";
    public static final String ADD_CHANNEL_FROM_CALLBACK = "borqs.fmradio.intent.ADD_CHANNEL_FROM_CALLBACK";
    public static final String FM_HEADSET_STATE_CHANGED = "borqs.fmradio.intent.FM_HEADSET_STATE_CHANGED";
    public static final String REFRESH_LISTVIEW = "borqs.fmradio.intent.REFRESH_LISTVIEW";
    public static final String NO_HEADSET_PLUG = "borqs.fmradio.intent.NO_HEADSET_PLUG";
    public static final String PRESS_VOLUMEKEY_ENABLE_FM = "borqs.fmradio.volume.press";
    public static final String MUSIC_SERVICE_COMMAND = "com.android.music.musicservicecommand";
    public static final String HEADSET_PLUG_FAST = "android.intent.action.HEADSET_PLUG_FAST";

    //Handler message
    public static final int MSG_FM_STATUS = 0;
    public static final int MSG_ENABLE_SUCCESSFUL = 1;
    public static final int MSG_ENABLE_FAILED = 2;
    public static final int MSG_DISABLE_SUCCESSFUL = 3;
    public static final int MSG_DISABLE_FAILED = 4;
    public static final int MSG_SCAN_FINISH = 5;
    public static final int MSG_CHECK_HEADSET = 6;
    public static final int MSG_SET_CHANNEL = 7;
    public static final int MSG_HEADSET_STATE = 8;
    public static final int MSG_UPDATE_VIEW = 9;
    public static final int MSG_HEADSET_INFO = 10;
    public static final int CHECK_SERVICE_HANDLER = 11;
    public static final int MSG_ADD_STATION = 12;
    public static final int MSG_STOP_SCAN = 13;
    public static final int MSG_DIALOG_CHECK = 14;

    public static final int MSG_FM_ENABLE = 14;
    public static final int MSG_FM_DISABLE = 15;
    public static final int MSG_FM_ACTIVE = 16;
    public static final int MSG_FM_IDLE = 17;
    public static final int MSG_FM_SET_CHANNEL = 18;
    public static final int MSG_FM_FORWARD = 19;
    public static final int MSG_FM_NEXT = 20;
    public static final int MSG_FM_PREV = 21;
    public static final int MSG_FM_REW = 22;
    public static final int MSG_FM_SCAN_ALL = 23;
    public static final int MSG_FM_GET_CHANNEL = 24;
    public static final int MSG_FM_ADD_STATION = 25;
    public static final int MSG_FM_STOP_SCAN = 26;
    public static final int MSG_FM_SET_SPEAKER = 27;
    public static final int MSG_SERVICE_HEADSET = 28;
    public static final int MSG_FM_CLOSE = 29;
    public static final int MSG_CLOSE_SUCCESSFUL = 30;
    public static final int MSG_FM_AUDIOFOCUS = 31;
    public static final int MSG_FINISH_ACTIVITY = 32;
    public static final int MSG_CHANGE_POWER_BTN = 33;
    
    public static final int MSG_SET_FAVORITE_BTN = 34;

    public static final int MSG_SET_TIME = 35;
    //DIALOG ID
    public static final int DIALOG_SET_CHANNEL = 0;
    public static final int DIALOG_POWER_ON = 1;
    public static final int DIALOG_POWER_OFF = 2;
    public static final int DIALOG_SCAN = 3;
    public static final int DIALOG_SET_TIME = 4;

	/********************************************
	 * Message Code
	 ********************************************/
	public static final int EVENT_FM_ENABLED = 51;
	public static final int EVENT_FM_DISABLED = 52;
	public static final int EVENT_MONO_STEREO_CHANGE = 53;
	public static final int EVENT_SEEK_STARTED = 54;
	public static final int EVENT_VOLUME_CHANGE = 55;
	public static final int EVENT_TUNE_COMPLETE = 56;
	public static final int EVENT_MUTE_CHANGE = 57;
	public static final int EVENT_SEEK_STOPPED = 58;
	public static final int EVENT_RDS_TEXT = 59;
	public static final int EVENT_BAND_CHANGE = 60;
	public static final int EVENT_MONO_STEREO_DISPLAY = 61;
	public static final int EVENT_ENABLE_RDS = 62;
	public static final int EVENT_SET_RDS_SYSTEM = 63;
	public static final int EVENT_SET_RDS_AF = 64;
	public static final int EVENT_DISABLE_RDS = 65;
	public static final int EVENT_SET_DEEMP_FILTER = 66;
	public static final int EVENT_PS_CHANGED = 67;
	public static final int EVENT_SET_RSSI_THRESHHOLD = 68;
	public static final int EVENT_SET_RF_DEPENDENT_MUTE = 69;
	public static final int EVENT_MASTER_VOLUME_CHANGED = 70;
	public static final int EVENT_SET_CHANNELSPACE = 71;
	public static final int EVENT_COMPLETE_SCAN_DONE = 72;
	public static final int EVENT_COMPLETE_SCAN_STOP = 73;
	public static final int EVENT_GET_CHANNEL_SPACE_CHANGE = 74;
	public static final int EVENT_PI_CODE = 75;
	public static final int EVENT_GET_RDS_AF_SWITCHMODE = 76;
	public static final int EVENT_GET_BAND = 77;
	public static final int EVENT_GET_VOLUME = 78;
	public static final int EVENT_GET_MODE = 79;
	public static final int EVENT_GET_MUTE_MODE = 80;
	public static final int EVENT_GET_RF_MUTE_MODE =81 ;
	public static final int EVENT_GET_RSSI_THRESHHOLD =82 ;
	public static final int EVENT_GET_DEEMPHASIS_FILTER = 83;
	public static final int EVENT_GET_RSSI =84 ;
	public static final int EVENT_GET_RDS_SYSTEM =85 ;
	public static final int EVENT_GET_RDS_GROUPMASK = 86;
	public static final int EVENT_GET_FREQUENCY = 87;
	public static final int EVENT_COMPLETE_SCAN_PROGRESS = 88;
	public static final int EVENT_ACTION_HEADSET_PLUG = 89;
	public static final int EVENT_PTY_CODE = 90;
	public static final int EVENT_RADIO_ENABLE_BEGIN = 91;
	public static final int EVENT_RADIO_CHANGE_FREQ = 92;
	public static final int FM_ERROR = 93;
	
	
	public static final int FM_SEEK_UP = 1;
	public static final int FM_SEEK_DOWN = 0;
	
	/* Rssi range */

	public static final int RSSI_MIN = 1;
	public static final int RSSI_MAX = 127;
	/* Preference save keys */

	public static final String BAND = "BAND";
	public static final String VOLUME = "VOLUME";
	public static final String FREQUENCY = "FREQUENCY";
	public static final String MODE = "MODE";
	public static final String RDS = "RDS";
	public static final String RDSSYSTEM = "RDSSYSTEM";
	public static final String DEEMP = "DEEMP";
	public static final String RDSAF = "RDSAF";
	public static final String RSSI = "RSSI";
	public static final String RSSI_STRING = "RSSI_STRING";
	public static final String DEF_RSSI_STRING = "7";
	public static final String CHANNELSPACE = "CHANNELSPACE";
	public static final String MUTE = "MUTE";
	
	/* default values */
	public static final int DEF_VOLUME = 10;
	public static final float DEFAULT_FREQ_EUROPE = (float) 87500 / 1000;
	public static final float DEFAULT_FREQ_JAPAN = (float) 76000 / 1000;
	public static final int DEFAULT_BAND = 0; // EuropeUS
	public static final int DEFAULT_MODE = 0; // Stereo
	public static final boolean DEFAULT_RDS = true;
	public static final int DEFAULT_DEEMP = 0;
	public static final int DEFAULT_RDS_SYSTEM = 0;
	public static final boolean DEFAULT_RDS_AF = true;
	public static final int DEFAULT_RSSI = 7;
	public static final int DEFAULT_CHANNELSPACE = 2;
	/* Initial values */
	public static final int INITIAL_VAL = 5;
	public static final int INITIAL_RSSI = 0;
	/* seek states */
	public static final boolean SEEK_REQ_STATE_IDLE = true;
	public static final boolean SEEK_REQ_STATE_PENDING = false;
	public static final int EUROPE_MAX_FREQ = 108000;
	public static final int EUROPE_MIN_FREQ = 87500;
	public static final int JAPAN_MAX_FREQ = 90000;
	public static final int JAPAN_MIN_FREQ = 76000;
	
	public static final int EUROPE_BAND = 0;
	public static final int JAPAN_BAND = 1;
}
