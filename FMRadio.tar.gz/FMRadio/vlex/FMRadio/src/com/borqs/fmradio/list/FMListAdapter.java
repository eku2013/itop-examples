/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.list;

import java.util.List;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.util.LogUtils;
import com.borqs.fmradio.AllActivity;
import com.borqs.fmradio.R;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.borqs.fmradio.FavoriteActivity;

public class FMListAdapter extends BaseAdapter {
    private static final String TAG = FMListAdapter.class.getSimpleName();
    private List<Station> mList = null;
    private LayoutInflater mInflater = null;
    private static FMListAdapter fa= null;
    private Context mContext = null;
    private ChannelHolder mChannelHolder;
    private ListView mListView = null;
    private Dialog mUpdateChannelDialog = null;
    private EditText mUpdateNameField;
    
    private FMListAdapter(Context context, List<Station> list,ListView listView) {
        mList = list;
        mListView = listView;
        LogUtils.d(TAG,"list size is " + list.size());
        mInflater = LayoutInflater.from(context);
        mContext = context;
        mChannelHolder = ChannelHolder.getInstance();
    }
    
	public void clear() {
        mList = null;
        mListView = null;
        mChannelHolder = null;
        mInflater = null;
        mContext = null;
    }
    
    public static FMListAdapter getInstance(Context context, List<Station> list,ListView listView) {
        fa = null;
        fa = new FMListAdapter(context, list,listView);
        fa.mList = list;
		return fa;
    }
    
    public void delete(Station sta) {
        ChannelHolder channelHolder = ChannelHolder.getInstance();
        int index1 = channelHolder.binarySearch(channelHolder.getFavoriteStationList(), sta.getFreq());
        mList.remove(index1);
        List<Station> list = channelHolder.getStationList();
        int index2 = channelHolder.binarySearch(list, sta.getFreq());
        Station st = list.get(index2);
        st.setFavorStatus(String.valueOf(false));
        LogUtils.d(TAG,"delete station freq #" + sta.getFreq());
        notifyDataSetChanged();
    }

    public void add(Station sta) {
        ChannelHolder channelHolder = ChannelHolder.getInstance();
        mList =  channelHolder.getFavoriteStationList();
        notifyDataSetChanged();
    }
    
    public int getCount() {
        LogUtils.d(TAG,"getCount() : " + mList.size());
        return mList.size();
    }

    public Object getItem(int position) {
        LogUtils.d(TAG, "getItem(position) #position:"+position);
        return mList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        LogUtils.d(TAG,"getView position:"+position+",convertView:"+convertView+",parent:"+parent);
        View view = convertView;
        TextView mFreq = null;
        TextView mName = null;
        ImageView mImage = null;
        ImageView mEditImage = null;
		Drawable starHoloDrak = mContext.getResources().getDrawable(
				R.drawable.ic_menu_star_holo_dark);
		Drawable starHoloLight = mContext.getResources().getDrawable(
				R.drawable.ic_menu_star_holo_light);
		Drawable editChannelDrak = mContext.getResources().getDrawable(
				R.drawable.menu_set_channel_dark);
		Drawable editChannelLight = mContext.getResources().getDrawable(
				R.drawable.menu_set_channel_light);
        if (null == convertView || null == convertView.getTag()) {
            view = mInflater.inflate(R.layout.browser_station_item, null);
            mFreq = (TextView) view.findViewById(R.id.freq_mhz);
            mName = (TextView) view.findViewById(R.id.freq_name);
            mImage = (ImageView) view.findViewById(R.id.favor_view);
            mEditImage = (ImageView) view.findViewById(R.id.edit_channel);
        } else {
            mFreq = (TextView) view.findViewById(R.id.freq_mhz);
            mName = (TextView) view.findViewById(R.id.freq_name);
            mImage = (ImageView) view.findViewById(R.id.favor_view);
            mEditImage = (ImageView) view.findViewById(R.id.edit_channel);
        }
        if (mChannelHolder.isAndroidTheme()){
        	mEditImage.setImageDrawable(editChannelDrak);
        } else {
        	mEditImage.setImageDrawable(editChannelLight);
        }
        final Station item = (Station) getItem(position);
        if (item != null) {
            mFreq.setText(Double.valueOf(item.getFreq())/1000+" MHz");
            String name = item.getName();
            if (TextUtils.isEmpty(name)){
            	mName.setText(R.string.unknown_name);
            } else {
            	mName.setText(name);
            } 
            if (Boolean.valueOf(item.getFavorStatus())) {
                mImage.setImageResource(R.drawable.cmcc_radio_icon_new_hl);
            } else {
            	if (mChannelHolder.isAndroidTheme()){
            		mImage.setImageDrawable(starHoloDrak);
            	} else {
            		mImage.setImageDrawable(starHoloLight);
            	}
            }
            mImage.setOnClickListener(new OnClickListener(){
    			public void onClick(View v) {
    				if (Boolean.valueOf(item.getFavorStatus())) {
   					 if (mChannelHolder.isNormalChannelMax()){
						 Toast.makeText(mContext, R.string.favorite_max_info, Toast.LENGTH_SHORT).show();
						 return;
					 }
    					item.setPosition(0);
    					item.setFavorStatus(String.valueOf(false));
    				} else {
    					 if (mChannelHolder.isFavoriteMax()) {
    						 Toast.makeText(mContext, R.string.favorite_max_info, Toast.LENGTH_SHORT).show();
    						 return;
    					 }
    					 int pos = ChannelHolder.getInstance().getAvailableFav();
    					 LogUtils.d(TAG," add getAvailableFav pos = " + pos);
    					 if (pos != 0){
	    					 item.setFavorStatus(String.valueOf(true));
	    					 item.setPosition(pos);
    					 } else {
    						 Toast.makeText(mContext, R.string.favorite_max_info, Toast.LENGTH_SHORT).show();
    						 return;
    					 }
    				}
    				if (mContext instanceof FavoriteActivity) {
    					mList.remove(position);
    				}
					notifyDataSetChanged();
    			}
    	    	
    	    });
        }
        
        mEditImage.setOnClickListener(new OnClickListener(){

			public void onClick(View v) {
				updateChannelName(item);
				
			}
        });
        
        mEditImage = null;
        mName = null;
        mFreq = null;
        mImage = null;
        return view;
    }
    
	private void updateChannelName(final Station item) {
		LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = (View)inflater.inflate(R.layout.update_channel_content,null);
		mUpdateNameField = (EditText) view.findViewById(R.id.name);
		if (!TextUtils.isEmpty(item.getName())) {
			mUpdateNameField.setText(item.getName());
			mUpdateNameField.setSelection(item.getName().length());
		}
		mUpdateChannelDialog = new AlertDialog.Builder(mContext)
					.setIcon(R.drawable.fm_app_icon)
					.setTitle(R.string.update_name)
					.setView(view)
					.setPositiveButton(R.string.ok,
							new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface arg0,
										int arg1) {
									updateName(item);
								}

							})
					.setNegativeButton(R.string.cancel,
							new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub

								}
							}).create();
		mUpdateChannelDialog.show();
	}

	private void updateName(Station item) {
		String name = mUpdateNameField.getText().toString().trim();
		if(!TextUtils.isEmpty(name)) {
			item.setName(name);
			notifyDataSetChanged();
		} else {
			Toast.makeText(mContext, R.string.name_empty, Toast.LENGTH_SHORT).show();
		}
	}
 
}
