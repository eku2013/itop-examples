/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;
import java.lang.reflect.Method;

import com.borqs.fmradio.util.LogUtils;
import com.borqs.fmradio.xml.XmlConst;
import com.borqs.fmradio.xml.XmlParser;
import com.borqs.fmradio.xml.XmlSerial;


import android.text.TextUtils;
//import android.os.SystemProperties;
import android.app.Activity;

public class ChannelHolder {
    private static final String TAG = ChannelHolder.class.getSimpleName();
    
    public static final int WORK_FREQ = 88500;
    
    private int mWorkFreq = 0;
    private String mLauncher = XmlConst.VALUE_ALL_ACTIVITY;
    private static final int FAVORITE_LIST_MAX =  systemProperties_getInt("fm_favor_max", 6);
    private static final int ALL_LIST_MAX = systemProperties_getInt("fm_all_max", 80);
    private static final int NORMAL_LIST_MAX =  ALL_LIST_MAX - FAVORITE_LIST_MAX;
    private XmlParser mXmlParser = null;
    private XmlSerial mXmlSerial = null;
    private boolean run = false;
    private boolean speakOn = false;
    private boolean isCancel = false;
    private boolean isAudioFocus = false;
    private boolean mIsForegroundActivity = false;
    
    private List<Station> mStationList = null;
    private List<Station> notFavorStationList = null;
    
    private static ChannelHolder mInstance = null;

    private InputStream is = null;
    private int item = 0;
    
    public static ChannelHolder getInstance() {
        if (null == mInstance) {
            mInstance = new ChannelHolder();
        }
        return mInstance;
    }
    
    private ChannelHolder() {

        mStationList = new ArrayList<Station>(80);
        notFavorStationList = new ArrayList<Station>();
        mXmlParser = new XmlParser();
        mXmlSerial = new XmlSerial();
        File dir = new File(XmlConst.FILE_DIR);
        if (! dir.exists()) {
            dir.mkdir();
        }
        
        File file = new File(XmlConst.FILE_DIR + XmlConst.FILE_NAME);
        if (!file.exists()) {
            mWorkFreq = WORK_FREQ;
//            mLauncher = XmlConst.VALUE_ALL_ACTIVITY;
            return;
        }
        if (!mXmlParser.parseXml(this)) {
            LogUtils.d(TAG, "Failed to parse file");
        } else {
            LogUtils.d(TAG, "channel count: " + mStationList.size());
        }
        if (0 == mWorkFreq) {
            mWorkFreq = WORK_FREQ;
        } 
//        if (TextUtils.isEmpty(mLauncher) || 
//            !XmlConst.VALUE_ALL_ACTIVITY.equalsIgnoreCase(mLauncher)||
//            !XmlConst.VALUE_FAVORITE_ACTIVITY.equalsIgnoreCase(mLauncher)) {
//            mLauncher = XmlConst.VALUE_ALL_ACTIVITY;
//        }
    }
    
    public int add(Station sta) {
        if (null == sta || TextUtils.isEmpty(sta.getFreq())) {
            LogUtils.d(TAG, "Command name/content mustn't be empty!");
            return -1;
        }

        boolean existFavorite = false;
        int currentPosition = 0;
        String name = sta.getName();
        LogUtils.d(TAG, "add channel name:" + name);
        int pos = binarySearch(mStationList, sta.getFreq());
        
        if (pos <= mStationList.size() - 1 && mStationList.get(pos).getFreq().equals(sta.getFreq())) {
        	if (Boolean.valueOf(mStationList.get(pos).getFavorStatus())){
        		existFavorite = true;
        		currentPosition = mStationList.get(pos).getPosition();
     
        	}
        	if (!TextUtils.isEmpty(mStationList.get(pos).getName())) {
           		name = mStationList.get(pos).getName();
        	}
        	LogUtils.d(TAG, "delete channel name:" + mStationList.get(pos).getFreq() 
        			+ ",fre: " + mStationList.get(pos).getFreq() + ", fav:" 
        			+ mStationList.get(pos).getFavorStatus());
            delete(mStationList.get(pos));
        } else {
            if (mStationList.size() >= ALL_LIST_MAX) {
                LogUtils.d(TAG,"list achieve max num,cancel to be added ");
                return -1;
            }
            
            if (sta.getFavorStatus() == String.valueOf(true)) {
                if (isFavoriteMax()) {
                    LogUtils.d(TAG,"Favorite is max");
                    return -1;
                }
            } else {
                int div = mStationList.size() - getFavoriteStationList().size();
                if (div >= NORMAL_LIST_MAX) {
                    return -1;
                }
            }
        }
        if (existFavorite) {
        	 sta.setFavorStatus("true");
        	 sta.setPosition(currentPosition);
        }
        sta.setName(name);
        mStationList.add(pos, sta);
        existFavorite = false;
        currentPosition = 0;
        name = null;
        return pos;
    }
    
    public int update(Station sta){
        if (null == sta || TextUtils.isEmpty(sta.getFreq())) {
            LogUtils.d(TAG, "Command name/content mustn't be empty!");
            return -1;
        }
        int pos = binarySearch(mStationList, sta.getFreq());

        if (pos <= mStationList.size() - 1 && mStationList.get(pos).getFreq().equals(sta.getFreq())) {
            int div = mStationList.size() - getFavoriteStationList().size();
            delete(mStationList.get(pos));
            if (div >= NORMAL_LIST_MAX) {
                return pos;
            } 
        } else {
            if (mStationList.size() >= ALL_LIST_MAX) {
                LogUtils.d(TAG,"list achieve max num,cancel to be added ");
                return -1;
            }
            
            if (sta.getFavorStatus() == String.valueOf(true)) {
                if (isFavoriteMax()) {
                    LogUtils.d(TAG,"Favorite is max");
                    return -1;
                }
            } else {
                int div = mStationList.size() - getFavoriteStationList().size();
                if (div >= NORMAL_LIST_MAX) {
                    return -1;
                }
            }
        }
        mStationList.add(pos, sta);
        return pos;
    }
    
//    public int edit(int index, Station sta) {
//        delete(index);
//        return add(sta);
//    }
    public int getAvailableFav(){
    	int pos = 0;
    	int[] bipmap = new int[FAVORITE_LIST_MAX + 1];
    	for (Station sta : mStationList) {
    		bipmap[sta.getPosition()] = 1;
    	}
    	for (int i = 0; i<=FAVORITE_LIST_MAX; i++){
    		 LogUtils.d(TAG," i = " + i + " bipmap = " + bipmap[i]);
    	}
    	for (int i = 1; i<=FAVORITE_LIST_MAX; i++){
    		if (bipmap[i] == 0){
    			return i;
    		}
    	}
    	return pos;
    }
    
    public void delete(Station sta) {
        if (sta == null || isInList(Integer.valueOf(sta.getFreq())) == -1) {
            LogUtils.d(TAG,"sta is null or the sta is not in mStationList");
            return;            
        }
        mStationList.remove(sta);
        LogUtils.d(TAG,"delete workfreq is "+sta.getFreq());
    }
    
    public void deleteAll() {
        if (mStationList.size()==0) {
            return;
        }
        for (int i = 0; i < mStationList.size(); i++) {
            LogUtils.d(TAG,"the mStationList size is "+mStationList.size());
            Station sta = mStationList.get(i);
            if (String.valueOf(false).equals(sta.getFavorStatus()) && TextUtils.isEmpty(sta.getName())) {
                notFavorStationList.add(sta);       
            }
        }
        LogUtils.d(TAG,"notFavorStationList size is " + notFavorStationList.size());
        for (Station sta : notFavorStationList){
            delete(sta);
        }
        notFavorStationList.clear();
    }
    
    public void flush() {
        LogUtils.d(TAG,"go to flush");
        mXmlSerial.flush(this);
    }
    
    public static int binarySearch(List<Station> list, String freq) {
        if (0 == list.size()) {
            return 0;
        }
        
        int left = 0;
        int right = list.size() - 1;
        Station sta = list.get(0);
        
        if (compare(freq, sta.getFreq()) < 0) {
            return 0;
        }
        
        sta = list.get(right);
        
        if (compare(freq, sta.getFreq()) > 0) {
            return list.size();
        }
        
        while (left <= right) {
            int middle = (left + right) / 2;
            sta = list.get(middle);
            
            if (compare(freq, sta.getFreq()) > 0) {
                left = middle + 1;
            } else 
                right = middle - 1;
        }
        
        return left;
    }
    
    private static int compare(String value1, String value2) {
        int v1 = Integer.valueOf(value1);
        int v2 = Integer.valueOf(value2);
        return v1 - v2;
    }
    
    public int getCount() {
        return mStationList.size();
    }
    
    public Station getItem(int index) {
        if (index < 0 || mStationList.size() <= index) {
            LogUtils.d(TAG, "Index " + index + "is invalid, it must between 0 and " + (mStationList.size() - 1));
            return null;
        }
        
        LogUtils.d(TAG,"getItemFreq " + index);
        return mStationList.get(index);
    }
    
    public int getWorkFreq() {
        return mWorkFreq;
    }

    public void setWorkFreq(int workFreq) {
        mWorkFreq = workFreq;
    }
    
    public String getChannelName(int workFreq){
    	for (Station sta : mStationList) {
    		if (sta.getFreq().equalsIgnoreCase(String.valueOf(workFreq))) {
    			return sta.getName();
    		}
    	}
    	return null;
    }

    public int getPositionByChannel(int workFreq){
    	for (Station sta : mStationList) {
    		if (sta.getFreq().equalsIgnoreCase(String.valueOf(workFreq))) {
    			return sta.getPosition();
    		}
    	}
    	return 0;
    }
    
    public String getLauncher() {
        return mLauncher;
    }
    
    public void setLauncher(String launcher) {
        mLauncher = launcher;
    }
    
    public List<Station> getStationList() {
        return mStationList;
    }

    public void setIsCancel(boolean cancel){
        this.isCancel = cancel;
    }

    public boolean getIsCancel(){
        return isCancel;
    }

    public void setIsAudioFocus(boolean isFocus){
        this.isAudioFocus = isFocus;
    }

    public boolean getIsAudioFocus(){
        return isAudioFocus;
    }
    
    public void setIsForegroundActivity(boolean isForeground) {
    	this.mIsForegroundActivity = isForeground;
    }
    
    public boolean getIsForegroundActivity(){
    	return mIsForegroundActivity;
    }
    
    public  boolean isAndroidTheme () {
		String usingTheme = systemProperties_get("sys.theme.default", "android");
		return "android".equals(usingTheme);
	}
    
    public List<Station> getFavoriteStationList() {
        List<Station> favoriteList = new ArrayList<Station>(mStationList.size());
        for(Station sta : mStationList) {
            if (String.valueOf(true).equals(sta.getFavorStatus())) {
                favoriteList.add(sta);
            }
        }
        return favoriteList;
    }
    
    public void setStationList(List<Station> stationList) {
        this.mStationList = stationList;
    }

    public boolean isWorkFreqFavorite() {
        LogUtils.d(TAG,"isWorkFreqFavorite # mWorkFreq is " + mWorkFreq);
        if (mStationList.size() != 0) {
            int index = isInList(mWorkFreq);
            if (index == -1 ) {
                LogUtils.d(TAG,"mWorkFreq is not in list");
                return false;
            }
            Station sta = mStationList.get(index);
            LogUtils.d(TAG,"mFreq is " + sta.getFreq());
            LogUtils.d(TAG,"favorite status is " + sta.getFavorStatus());
            return Boolean.valueOf(sta.getFavorStatus());
        }    
        return false;
    }
    
    public int isInList(int freq) {
        for(int i = 0; i < mStationList.size(); i++) {
            Station sta = mStationList.get(i);
            if (Integer.valueOf(sta.getFreq()) == freq) {
                return i;
            }
        } 
        return -1;
    }

    public boolean isFavoriteMax() {
        List<Station> favoriteList = getFavoriteStationList();
        return (favoriteList.size() >= FAVORITE_LIST_MAX) ? true : false;
    }
    
    public boolean isAllMax() {
        return (mStationList.size() >= ALL_LIST_MAX) ? true : false;
    }
    
    public boolean isNormalChannelMax(){
    	return (mStationList.size() -getFavoriteStationList().size() >= NORMAL_LIST_MAX) ? true : false;
    }
    public void setRun(boolean isRun) {
        this.run = isRun;
    }
    
    public boolean getRun() {
        return run;
    }

    public void setSpeakerOn(boolean speakerOn) {
        this.speakOn = speakerOn;
    }

    public boolean getSpeakerOn() {
        return speakOn;
    }

    public InputStream getInputStream() {
        return is;
    }

    public void setInputStream(InputStream inputStream) {
        this.is = inputStream;
    }
    
    public int getItem() {
        return item;
    }
    
    public void setItem(int value) {
        this.item = value;
    }
    
    public static int systemProperties_getInt(String key, int defValue) {
    	int ret = 0;
    	try {
	    	Class<?> c = Class.forName("android.os.SystemProperties");
	    	Method method = c.getMethod("getInt", String.class, int.class);
	    	ret = (Integer)method.invoke(null, key, defValue);
    	} catch (Exception ex) {
    		LogUtils.d(TAG,"systemProperties_getBoolean, " + ex);
    	}
    	return ret;
    }
    
    public static String systemProperties_get(String key, String defValue) {
    	String ret = defValue;
    	try {
	    	Class<?> c = Class.forName("android.os.SystemProperties");
	    	Method method = c.getMethod("get", String.class, String.class);
	    	ret = (String)method.invoke(null, key, defValue);
    	} catch (Exception ex) {
    		LogUtils.d(TAG,"systemProperties_get, " + ex);
    	}
    	return ret;
    }
    
}
