/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.xml;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


import org.xmlpull.v1.XmlSerializer;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.util.LogUtils;

import android.text.TextUtils;
import android.util.Xml;

public class XmlSerial {
    private static final String TAG = XmlSerial.class.getSimpleName();
    
    private XmlSerializer mXmlSerializer = null;
    File newXmlFile = new File(XmlConst.FILE_DIR + XmlConst.FILE_NAME);
    public XmlSerial() {
        mXmlSerializer = Xml.newSerializer();
    }
    
    public void flush(ChannelHolder holder) {
        try {
            write(holder);
        } catch (Exception e) {
            exception(e,holder);
        }
    }

    private void exception(Exception e,ChannelHolder holder) {
        LogUtils.d(TAG,"Exception stack trace"+ e);
        if (newXmlFile != null) {
            newXmlFile.delete();
        } else {
            newXmlFile = new File(XmlConst.FILE_DIR + XmlConst.FILE_NAME);
        }
        flush(holder);
    }

    private void write(ChannelHolder holder) {
        try {
            LogUtils.i(TAG,"xml serial is " + mXmlSerializer);
            
            newXmlFile.createNewFile();
            FileOutputStream fileos = new FileOutputStream(newXmlFile);

            mXmlSerializer.setOutput(fileos, "UTF-8");
            mXmlSerializer.startDocument(null, null);

            mXmlSerializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);
            mXmlSerializer.startTag(null, XmlConst.TAG_ROOT);
            mXmlSerializer.startTag(null, XmlConst.TAG_LIST);

            for (int i = 0; i < holder.getStationList().size(); i++) {
                Station sta = holder.getStationList().get(i);
                String name = sta.getName();
                if (TextUtils.isEmpty(name)){
                	name = "";
                }
                mXmlSerializer.startTag(null, XmlConst.TAG_STATION);
                try {
                    mXmlSerializer.attribute(null, XmlConst.ATTR_FREQ, sta.getFreq());
                    mXmlSerializer.attribute(null, XmlConst.ATTR_NAME, name);
                    mXmlSerializer.attribute(null, XmlConst.ATTR_FAVOR, sta.getFavorStatus());
                    mXmlSerializer.attribute(null, XmlConst.ATTR_POSITION, String.valueOf(sta.getPosition()));
                } catch (IllegalStateException e) {
                    LogUtils.d(TAG,"IllegalStateException in XmlSerial occur.");
                }
                mXmlSerializer.endTag(null, XmlConst.TAG_STATION);
            }
            mXmlSerializer.endTag(null, XmlConst.TAG_LIST);
            
            mXmlSerializer.startTag(null, XmlConst.TAG_WORK);
            mXmlSerializer.attribute(null, XmlConst.ATTR_FREQ, String.valueOf(holder. getWorkFreq()));
            mXmlSerializer.attribute(null, XmlConst.ATTR_RUN, String.valueOf(holder.getRun()));
            mXmlSerializer.endTag(null, XmlConst.TAG_WORK);    
            
            mXmlSerializer.startTag(null, XmlConst.TAG_LAUNCHER);
            mXmlSerializer.attribute(null, XmlConst.ATTR_LAUNCHER_NAME, holder.getLauncher());
            mXmlSerializer.endTag(null, XmlConst.TAG_LAUNCHER);
            
            mXmlSerializer.endTag(null, XmlConst.TAG_ROOT);
            mXmlSerializer.endDocument();

            mXmlSerializer.flush();
            fileos.close();
        } catch (IOException e) {
            LogUtils.d(TAG, "Failed to save data to " + XmlConst.FILE_DIR + XmlConst.FILE_NAME);
        }
    }
}
