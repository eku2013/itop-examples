package com.borqs.fmradio;

import com.borqs.fmradio.util.LogUtils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SaveFavoriteChannelLayout extends LinearLayout {
	private static final String TAG = FMRadioActivity.class.getSimpleName();
	private ImageView mFavoritehp;
	private ImageView mFavoritetp;
	private ImageView mFavoriteUnit;
	private ImageView mFavoritePoint;
	private ImageView mFavoritesn;
	private LinearLayout mLinearLayout;
	
    private static final int[] mFavoriteDrawableID = {
        R.drawable.favoritechannel_0,
        R.drawable.favoritechannel_1,
        R.drawable.favoritechannel_2,
        R.drawable.favoritechannel_3,
        R.drawable.favoritechannel_4,
        R.drawable.favoritechannel_5,
        R.drawable.favoritechannel_6,
        R.drawable.favoritechannel_7,
        R.drawable.favoritechannel_8,
        R.drawable.favoritechannel_9,
        R.drawable.favoritechannel_point,
    };
    
    private static final Drawable[] mFavoriteDraws = new Drawable[11];
    
    
    private static final int[] mDefaultDrawableID = {
        R.drawable.default_channel_0,
        R.drawable.default_channel_1,
        R.drawable.default_channel_2,
        R.drawable.default_channel_3,
        R.drawable.default_channel_4,
        R.drawable.default_channel_5,
        R.drawable.default_channel_6,
        R.drawable.default_channel_7,
        R.drawable.default_channel_8,
        R.drawable.default_channel_9,
        R.drawable.default_channel_point,
    };
    
    private static final Drawable[] mDefaultDraws = new Drawable[11];
	
	protected OnClickListener mClickListener = new ButtonClickListener();
	protected OnLongClickListener mLongClickListener = new ButtonLongClickListener();
	
	public SaveFavoriteChannelLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		inflateFavoriteChannelLayout(this);
	}

	private View inflateFavoriteChannelLayout(
			SaveFavoriteChannelLayout parent) {
		if (parent == null) {
			throw new AssertionError("argument could not be null");
		}
		
		LayoutInflater viewInflater = LayoutInflater.from(parent.getContext());
		if (viewInflater == null) {
			throw new AssertionError("fail to retrieve ViewInflate object");
		}
		
		SaveFavoriteChannelLayout layout = null;
		
		layout = (SaveFavoriteChannelLayout)viewInflater.inflate(
				R.layout.favorite_channel_view,
				parent,
				true);
		
		layout.init();

		return layout;
	}

	
	/**
	 *  initialize the click listener for each button
	 */
	private void init() {
		mFavoritehp = (ImageView) this.findViewById(R.id.hp_1);
		mFavoritetp = (ImageView) findViewById(R.id.tp_1);
		mFavoriteUnit = (ImageView) findViewById(R.id.unit_1);
		mFavoritePoint = (ImageView) findViewById(R.id.point_1);
		mFavoritesn = (ImageView) findViewById(R.id.sn_1);
		mLinearLayout = (LinearLayout)findViewById(R.id.channel_id);
		initFavoriteChannelDrawables();
		initDefaultChannelDrawables();
	}
	
	private void initFavoriteChannelDrawables() {
		for (int i = 0; i < mFavoriteDrawableID.length; i++) {
			mFavoriteDraws[i] = getResources().getDrawable(
					mFavoriteDrawableID[i]);
		}
	}

	private void initDefaultChannelDrawables() {
		for (int i = 0; i < mDefaultDrawableID.length; i++) {
			mDefaultDraws[i] = getResources().getDrawable(
					mDefaultDrawableID[i]);
		}
	}
	 
	public void updateDrawableByChannel(int freq) {
		LogUtils.d(TAG,"updateDrawableByChannel: " + freq);
		mLinearLayout.setBackgroundDrawable(null);
		mFavoritetp.setImageDrawable(mFavoriteDraws[(freq % 100000) / 10000]);
		mFavoriteUnit.setImageDrawable(mFavoriteDraws[(freq % 10000) / 1000]);
		mFavoritePoint.setImageDrawable(mFavoriteDraws[10]);
		mFavoritesn.setImageDrawable(mFavoriteDraws[(freq % 1000) / 100]);
		if (freq / 100000 == 1) {
			mFavoritehp.setVisibility(View.VISIBLE);
			mFavoritehp.setImageDrawable(mFavoriteDraws[1]);
		} else {
			mFavoritehp.setVisibility(View.INVISIBLE);
		}
		mFavoritehp.invalidate();
		mFavoritetp.invalidate();
		mFavoriteUnit.invalidate();
		mFavoritesn.invalidate();

	}
	 
	
	public void updateDefaultDrawableByChannel(int freq){
		mLinearLayout.setBackgroundDrawable(null);
		mFavoritetp.setImageDrawable(mDefaultDraws[(freq % 100000) / 10000]);
		mFavoriteUnit.setImageDrawable(mDefaultDraws[(freq % 10000) / 1000]);
		mFavoritePoint.setImageDrawable(mDefaultDraws[10]);
		mFavoritesn.setImageDrawable(mDefaultDraws[(freq % 1000) / 100]);
		if (freq / 100000 == 1) {
			mFavoritehp.setVisibility(View.VISIBLE);
			mFavoritehp.setImageDrawable(mDefaultDraws[1]);
		} else {
//			mFavoritehp.setImageResource(R.drawable.gray_8);
			mFavoritehp.setVisibility(View.INVISIBLE);
		}
		mFavoritehp.invalidate();
		mFavoritetp.invalidate();
		mFavoriteUnit.invalidate();
		mFavoritesn.invalidate();
		
	}
	
	
	public void updateDrawableNoChannel(){
		mLinearLayout.setBackgroundResource(R.drawable.plus);
//		mFavoriteUnit.setImageResource(R.drawable.gray_8);
//		mFavoritePoint.setImageResource(R.drawable.dot);
//		mFavoritesn.setImageResource(R.drawable.gray_8);
//		mFavoritehp.setImageResource(R.drawable.gray_8);
		mFavoriteUnit.setImageDrawable(null);
		mFavoritePoint.setImageDrawable(null);
		mFavoritesn.setImageDrawable(null);
		mFavoritehp.setImageDrawable(null);
		mFavoritetp.setImageDrawable(null);
		mFavoritehp.invalidate();
		mFavoritetp.invalidate();
		mFavoriteUnit.invalidate();
		mFavoritesn.invalidate();
	}
	protected class ButtonClickListener implements OnClickListener {

		public void onClick(View v) {
			if (v == null) {
				return;
			}
			
			
			

			
        }
		
	};
	
	
	protected class ButtonLongClickListener implements OnLongClickListener {

		public boolean onLongClick(View v) {
			if (v == null) {
				return false;
			}
			return false;
			
			
		}
		
	}
	
}
