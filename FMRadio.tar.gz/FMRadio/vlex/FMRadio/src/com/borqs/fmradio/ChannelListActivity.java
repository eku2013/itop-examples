/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.borqs.fmradio.xml.XmlConst;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.widget.TabHost;
import android.view.Window;

public class ChannelListActivity extends TabActivity {
    private static final String TAG = ChannelListActivity.class.getSimpleName();
    private TabHost mListTabHost;
    private static final String FAVORITE_TAG = "favoritelist";
    private static final String ALL_TAG = "alllist";
    private ChannelHolder mChannelHolder = null;
    private AlertDialog mDialog = null;
    
    BroadcastReceiver receiver = new BroadcastReceiver(){

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if (Constants.NO_HEADSET_PLUG.equals(intent.getAction())) {
				mDialog = new AlertDialog.Builder(ChannelListActivity.this)
				.setTitle(R.string.no_headset)
				.setIcon(R.drawable.art_dialog_notice)
				.setMessage(R.string.no_headset)
				.setNegativeButton(R.string.cancel,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								noHeadsetDisableFM();
							}
						}).setOnCancelListener(new OnCancelListener() {
					public void onCancel(DialogInterface dialog) {
						noHeadsetDisableFM();
					}
				}).show();
			} else {
				if (null != mDialog) {
					mDialog.dismiss();
				}
			}
			
		}
    	
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
       
        mListTabHost = getTabHost();
        Intent favorIntent = new Intent(this, FavoriteActivity.class);  
        mListTabHost.addTab(mListTabHost.newTabSpec(FAVORITE_TAG).setIndicator(getString(R.string.favorite_list), getResources     ().getDrawable(R.drawable.cmcc_tab_favorite_hl)).setContent(favorIntent));
        
        Intent allIntent = new Intent(this, AllActivity.class);
        mListTabHost.addTab(mListTabHost.newTabSpec(ALL_TAG).setIndicator(getString(R.string.all_list), getResources().getDrawable (R.drawable.cmcc_tab_all_channel_list_hl)).setContent(allIntent));
        ChannelHolder channelHolder = ChannelHolder.getInstance();
        String launcher = channelHolder.getLauncher();
        mListTabHost.setCurrentTabByTag(XmlConst.VALUE_FAVORITE_ACTIVITY.equalsIgnoreCase(launcher) ? FAVORITE_TAG : ALL_TAG);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.NO_HEADSET_PLUG);
        filter.addAction(Constants.FM_HEADSET_STATE_CHANGED);
        registerReceiver(receiver,filter);
        
    }

	private void noHeadsetDisableFM() {
		if (null == mChannelHolder) {
			mChannelHolder = ChannelHolder.getInstance();
		}
		mChannelHolder.setIsAudioFocus(false);
		 Intent intent = new Intent(this, FMService.class);
	     this.stopService(intent);
	     mChannelHolder.flush();
	     finish();
	    LogUtils.d(TAG,"ChannelListActivity noHeadsetDisableFM...");
		
	}
    
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(receiver);
		if (null != mDialog) {
			mDialog.dismiss();
		}
	}
    
    
}
