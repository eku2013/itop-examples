/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.xml;

public class XmlConst {
    public final static String FILE_DIR = "/data/data/com.borqs.fmradio/files/";
    public final static String FILE_NAME = "channels.xml";
    
    public final static String TAG_ROOT = "FMRadio";
    public final static String TAG_LIST = "List";
    
    public final static String TAG_STATION = "Station";
    public final static String ATTR_FREQ = "freq";
    public final static String ATTR_RUN = "run";
    public final static String ATTR_FAVOR = "favor";
    public final static String ATTR_NAME = "name";
    public final static String ATTR_POSITION = "position";
    
    
    public final static String TAG_WORK = "Work";
    public final static String TAG_LAUNCHER = "Launcher";
    public final static String ATTR_LAUNCHER_NAME = "name";
    public final static String VALUE_ALL_ACTIVITY = "AllActivity";
    public final static String VALUE_FAVORITE_ACTIVITY = "FavoriteActivity";
}
