/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.util;

import android.util.Log;

public class LogConfig {
	public static final String TAG = "FMRadioApp";
	public static boolean DEBUG = android.os.Build.TYPE.equals("user") ? Log
			.isLoggable(TAG, Log.DEBUG) : true;

}
