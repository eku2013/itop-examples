/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio;

import static com.borqs.fmradio.util.Constants.DIALOG_SET_CHANNEL;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.RelativeLayout;
import android.graphics.drawable.Drawable;
import java.util.List;

import com.borqs.fmradio.list.FMListAdapter;
import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.borqs.fmradio.xml.XmlConst;

import android.text.TextUtils;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public class FavoriteActivity extends Activity implements OnItemClickListener{
    
    private static final String TAG = FavoriteActivity.class.getSimpleName();
    private ListView mListView = null;
    private FMListAdapter mAdapter = null;
    private ChannelHolder mChannelHolder = null;
    private Station dSta = null;
//    private ImageButton mTitleBtn = null;
//    private TextView mTitleText = null;
    
    private BroadcastReceiver mBr = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Constants.FINISH_FM.equals(action)) {
                finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mChannelHolder = ChannelHolder.getInstance();
        setupViews();
        IntentFilter intentFilter = new IntentFilter(Constants.FINISH_FM);
        registerReceiver(mBr, intentFilter);
    }

    protected void onResume() {
        mChannelHolder = ChannelHolder.getInstance();
        setupViews();
        super.onResume();
    }

    protected void onPause() {
        super.onPause();
        if (mAdapter != null) {
        	mAdapter.notifyDataSetChanged();
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mBr);
    }

    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        List<Station> list = mChannelHolder.getFavoriteStationList();
        if (list !=null && list.size() == 0) return;
        Station sta = list.get(position);
        Intent intent = new Intent(this, FMService.class);
        intent.setAction(Constants.SET_CHANNEL);
        intent.putExtra("channel",Double.valueOf(sta.getFreq())/1000);
        startService(intent);
        mChannelHolder.setLauncher(XmlConst.VALUE_FAVORITE_ACTIVITY);
        over();
    }
    
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            mChannelHolder.setLauncher(XmlConst.VALUE_FAVORITE_ACTIVITY);
            over();
        }
        return super.onKeyDown(keyCode, event);
    }
    
    private void over() {
//        startActivity(new Intent(this, FMRadioActivity.class));
        finish();
    }
    
    private void setupViews() {
        int count = mChannelHolder.getFavoriteStationList().size();
        if (count == 0) {
            setContentView(R.layout.favor_empty);
//            prepareTitle();
        } else {
            prepareAdapter();
        }
//        RelativeLayout title = (RelativeLayout)findViewById(R.id.oms_screen_viewtitle);
//        title.setBackgroundDrawable(Drawable.createFromStream(mChannelHolder.getInputStream(),null));
    }

/*    private void prepareTitle() {
        mTitleBtn = (ImageButton) findViewById(R.id.title_image);
        mTitleBtn.setBackgroundResource(R.drawable.title_bar_set_channel);
        mTitleBtn.setVisibility(View.VISIBLE);
        mTitleBtn.setOnClickListener(new View.OnClickListener() {
             public void onClick(View view) {
                 ((ChannelListActivity)getParent()).getTabHost().getTabWidget().setEnabled(false);
                 showDialog(DIALOG_SET_CHANNEL);
             }
        });
        mTitleText = (TextView) findViewById(R.id.title_text);
        mTitleText.setText(R.string.favorite_label);
    }
*/
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
        ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
        dSta = (Station)mListView.getItemAtPosition(((AdapterView.AdapterContextMenuInfo) menuInfo).position);

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.delete_channel:
            deleteChannel();
            mChannelHolder.flush();
            return true;
        default:
            return super.onContextItemSelected(item);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch(id) {
        case DIALOG_SET_CHANNEL:
            return createSetChannelDialog();
        }
        return null;
    }

    private void prepareAdapter() {
        setContentView(R.layout.browser_station_list);
//        prepareTitle();
        mListView = (ListView) findViewById(R.id.listview);
        mAdapter = FMListAdapter.getInstance(this, mChannelHolder.getFavoriteStationList(),mListView);
        mListView.setAdapter(mAdapter);
        LogUtils.d(TAG, "List view size is : " + mListView.getCount());
        mListView.setOnItemClickListener(this);
        registerForContextMenu(mListView);
        mAdapter.notifyDataSetChanged();
    }

    private Dialog createSetChannelDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        View v = inflater.inflate(R.layout.dialog_set_channel, null);
        final EditText et = (EditText)v.findViewById(R.id.channel);
        alertDialog.setView(v);
        alertDialog.setTitle(R.string.dialog_set_channel);
        final Context context = this;
        alertDialog.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                ((ChannelListActivity)getParent()).getTabHost().getTabWidget().setEnabled(true);
                if (mAdapter == null) {
                    prepareAdapter();
                }
                setupViews();
                String tem = et.getText().toString();
                double mTem;
                try {
                    mTem = Double.valueOf(tem);
                    if ((mTem * 1000 % 100) > 0) {
                        Toast.makeText(context, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (mTem > 108.1 || mTem < 87.5) {
                        Toast.makeText(context, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (mChannelHolder.isFavoriteMax()) {
                        Toast.makeText(context, R.string.favorite_max_info, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (mChannelHolder.isAllMax()) {
                        Toast.makeText(context, R.string.all_max_info, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int channel = (int)(mTem * 1000);
                    Station sta = new Station(String.valueOf(channel));
                    List<Station> list = mChannelHolder.getFavoriteStationList();
                    int pos = mChannelHolder.binarySearch(list, String.valueOf(channel));
                    if (pos <= list.size() - 1 && list.get(pos).getFreq().equals(sta.getFreq())) {
                        Toast.makeText(context, R.string.add_station_already, Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        sta.setFavorStatus(String.valueOf(true));
                    }
                    mChannelHolder.add(sta);
                    if (list.size() == 0) {
                        setupViews();
                    }
                    mAdapter.add(sta);
                    if (!TextUtils.isEmpty(et.getText().toString())) {
                        et.setText("");
                    }
                    mChannelHolder.flush();
                } catch(NumberFormatException e) {
                    Toast.makeText(context, R.string.channel_wrong_format, Toast.LENGTH_LONG).show();
                    return;
                }
            }
        });
        alertDialog.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id) {
                ((ChannelListActivity)getParent()).getTabHost().getTabWidget().setEnabled(true);
            }
        });
        return alertDialog.create();
    }
    
    private void deleteChannel() {
        if (dSta != null) {
            mAdapter.delete(dSta);
            setupViews();
        }
    }
}
