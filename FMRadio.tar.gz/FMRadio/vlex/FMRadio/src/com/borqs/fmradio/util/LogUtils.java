/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.util;

import android.util.Log;

public class LogUtils {
    public static final String APP_TAG = "FMRadioApp";
    
    public static boolean mDebug = LogConfig.DEBUG;
    
    private LogUtils() {}
    
    public static void d(String tag, String msg)
    {
        if (mDebug)
            Log.d(APP_TAG, "[" + tag + "]" + msg);
    }
    


    public static void i(String tag, String msg)
    {
        if (mDebug)
            Log.i(APP_TAG, "[" + tag + "]" + msg);
    }



    public static void e(String tag, String msg)
    {
        if (mDebug)
            Log.e(APP_TAG, "[" + tag + "]" + msg);
    }



    public static void w(String tag, String msg)
    {
        if (mDebug)
            Log.w(APP_TAG, "[" + tag + "]" + msg);
    }



    public static void e(String tag, String msg, Throwable tr)
    {
        if (mDebug)
            Log.e(APP_TAG, "[" + tag + "]" + msg, tr);
    }

}
