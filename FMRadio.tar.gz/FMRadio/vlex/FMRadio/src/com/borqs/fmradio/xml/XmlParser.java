/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.xml;

import java.io.FileInputStream;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;

import android.text.TextUtils;

public class XmlParser {

    private static final String TAG = XmlParser.class.getSimpleName();
    
    private XmlPullParserFactory mXmlFactory = null;
    
    private XmlPullParser mXmlParser = null;
    
    public XmlParser() {
        try {
            mXmlFactory = XmlPullParserFactory.newInstance();
            mXmlFactory.setNamespaceAware(true);
            mXmlParser = mXmlFactory.newPullParser();
        } catch (XmlPullParserException e) {
            LogUtils.d(TAG, "XmlPullParserException occured!");
            e.printStackTrace();
        }
        
    }
    
    public boolean parseXml(ChannelHolder holder) {

        try {
            return read(holder);
        } catch(Exception e) {
            return exception(e, holder);
        }
    }

    private boolean exception(Exception e, ChannelHolder holder) {
        LogUtils.d(TAG,"exception is " + e);
        return parseXml(holder);
    }

    private boolean read(ChannelHolder holder) throws Exception{
        
        String path = XmlConst.FILE_DIR + XmlConst.FILE_NAME;
        boolean mTagRoot = false;
        boolean mTagList = false;
        boolean mTagStation = false;
        boolean mTagWork = false;
        boolean mTagLauncher = false;
        Station sta = null;
        int mWorkFreq = 0;
        boolean mRun = false;
        String mLauncher = null;
        
        LogUtils.d(TAG, "Parse file: " + path);
        
        if (null == mXmlFactory || null == mXmlParser) {
            return false;
        }
        
        mXmlParser.setInput(new FileInputStream(path), "UTF-8");
        String tagName = null;
        
        int eventType = mXmlParser.getEventType();
        while (true) {
            switch (eventType) {
            case XmlPullParser.START_DOCUMENT:
                LogUtils.d(TAG, "START_DOCUMENT");
                break;
            case XmlPullParser.START_TAG:
                LogUtils.d(TAG, "START_TAG");
                
                tagName = mXmlParser.getName();
                LogUtils.d(TAG, "tagName:" + tagName);
                
                if (XmlConst.TAG_ROOT.equals(tagName)) {
                    mTagRoot = true;
                    break;
                }
                
                if (XmlConst.TAG_LIST.equals(tagName)) {
                    mTagList = true;
                    break;
                }
                if (XmlConst.TAG_STATION.equals(tagName)) {
                    String freq = mXmlParser.getAttributeValue(null, XmlConst.ATTR_FREQ).trim();
                    int number = Integer.valueOf(freq);
                    if (TextUtils.isEmpty(freq) || (number < 76000 || 108000 < number)) {
                        sta = null;
                        break;
                    }
                    mTagStation = true;
                    sta = new Station();
                    
                    sta.setFreq(freq);
                    sta.setName(mXmlParser.getAttributeValue(null, XmlConst.ATTR_NAME).trim());
                    sta.setFavorStatus(mXmlParser.getAttributeValue(null, XmlConst.ATTR_FAVOR));
                    sta.setPosition(Integer.parseInt(mXmlParser.getAttributeValue(null, XmlConst.ATTR_POSITION).trim()));
                    LogUtils.d(TAG, XmlConst.TAG_STATION + " freq : " + sta.getFreq());
                    break;
                }
                
                if (tagName.equals(XmlConst.TAG_WORK)) {
                    String freq = mXmlParser.getAttributeValue(null, XmlConst.ATTR_FREQ).trim();
                    mWorkFreq = Integer.valueOf(freq);
                    if (TextUtils.isEmpty(freq) || (mWorkFreq < Constants.JAPAN_MIN_FREQ || Constants.EUROPE_MAX_FREQ < mWorkFreq)) {
                        mWorkFreq = 87500;
                        break;
                    }
                    mTagWork = true;
                    
                    String r = mXmlParser.getAttributeValue(null, XmlConst.ATTR_RUN).trim();
                    mRun = Boolean.valueOf(r);
                    if (TextUtils.isEmpty(r)) {
                        mRun = false;
                    }
                    break;
                }
                
                if (tagName.equals(XmlConst.TAG_LAUNCHER)) {
                    String launcher = mXmlParser.getAttributeValue(null, XmlConst.ATTR_LAUNCHER_NAME).trim();
                    mLauncher = launcher;
                    mTagLauncher = true;
                    if (TextUtils.isEmpty(launcher) || !XmlConst.VALUE_FAVORITE_ACTIVITY.equalsIgnoreCase(launcher)
                        || !XmlConst.VALUE_ALL_ACTIVITY.equalsIgnoreCase(launcher)) {
                        mLauncher = XmlConst.VALUE_ALL_ACTIVITY;
                        break;
                    }
                }
                break;
            case XmlPullParser.TEXT:
                String tagContent = mXmlParser.getText().trim();
                LogUtils.d(TAG, "tagContent : " + tagContent);
                
                if (TextUtils.isEmpty(tagContent)) {
                    break;
                }
                
                if (XmlConst.TAG_STATION.equals(tagName)) {
                    LogUtils.d(TAG, XmlConst.TAG_STATION);
                    break;
                }
                
                break;
            case XmlPullParser.END_TAG:
                tagName = mXmlParser.getName();
                LogUtils.d(TAG,"tagName : " + tagName);
                
                if (XmlConst.TAG_ROOT.equals(tagName)) {
                    LogUtils.d(TAG, XmlConst.TAG_ROOT);
                    break;
                }
                
                if (XmlConst.TAG_LIST.equals(tagName)) {
                    LogUtils.d(TAG, XmlConst.TAG_LIST);
                    break;
                }
                
                if (XmlConst.TAG_STATION.equals(tagName) && null != sta) {
                    int pos = ChannelHolder.binarySearch(holder.getStationList(), sta.getFreq());
                    holder.getStationList().add(pos, sta);
                    LogUtils.d(TAG, XmlConst.TAG_STATION);
                    break;
                }
                
                if (XmlConst.TAG_WORK.equals(tagName)) {
                    holder.setWorkFreq(mWorkFreq);
                    holder.setRun(mRun);
                    break;
                }
                
                if (XmlConst.TAG_LAUNCHER.equals(tagName)) {
                    holder.setLauncher(mLauncher);
                    break;
                }
                break;
            case XmlPullParser.END_DOCUMENT:
                LogUtils.d(TAG, "END_DOCUMENT");
                if (! mTagRoot) {
                    LogUtils.d(TAG, "Failed to find tag: " + XmlConst.TAG_ROOT);
                    return false;
                }
                
                if (! mTagList) {
                    LogUtils.d(TAG, "Failed to find tag: " + XmlConst.TAG_LIST);
                    return false;
                }
                
                if (! mTagStation) {
                    LogUtils.d(TAG, "Failed to find tag: " + XmlConst.TAG_STATION);
                    return false;
                }
                
                if (! mTagWork) {
                    LogUtils.d(TAG, "Filed to find tag: " + XmlConst.TAG_WORK);
                    LogUtils.d(TAG, "We ignore work freq");
                    return false;
                }
                
                if (! mTagLauncher) {
                    LogUtils.d(TAG, "Filed to find tag: " + XmlConst.TAG_LAUNCHER);
                    LogUtils.d(TAG, "We ignore work freq");
                    return false;
                }
                
                return true;
             }
            eventType = mXmlParser.next();
        }
    }
}
