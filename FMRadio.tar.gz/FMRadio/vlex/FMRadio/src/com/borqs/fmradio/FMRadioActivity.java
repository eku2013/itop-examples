
/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio;

import static com.borqs.fmradio.util.Constants.DIALOG_POWER_OFF;
import static com.borqs.fmradio.util.Constants.DIALOG_POWER_ON;
import static com.borqs.fmradio.util.Constants.DIALOG_SCAN;
import static com.borqs.fmradio.util.Constants.DIALOG_SET_CHANNEL;
import static com.borqs.fmradio.util.Constants.DIALOG_SET_TIME;

import java.lang.reflect.Method;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.ti.fm.FmRadio;

public class FMRadioActivity extends Activity {

    private static final String TAG = FMRadioActivity.class.getSimpleName();
    private int UNITDIP;
    private float MIN_CHANNEL;
    private float MAX_CHANNEL;
    private ImageView v1 = null;
    private ImageView v2 = null;
    private ImageView v3 = null;
    private ImageView vPoint = null;
    private ImageView v4 = null;
    private ImageView vMhz = null;
    private ImageView vScale = null;
    private ImageButton mPowerBtn = null;
    private ImageButton btnForward = null;
    private ImageButton btnRew = null;
    private ImageButton btnList = null;
    private ImageButton btnSpeaker = null;
    private ImageButton btnMute = null;
    private ImageButton btnSearchBack = null;
    private ImageButton btnSearchNext = null;
    private TextView tvPSInfo = null;
    private TextView tvStereoInfo = null;
    private TextView ptyInfo = null;
    private TextView tvRadioText = null;
    private ImageView signalView = null;
    private ImageView soundView = null;
    private GestureDetector mGestureDetector = null;
    
    private AudioManager am = null;
    private TelephonyManager tm = null;
    private ProgressDialog mPowerOnDialog = null;
    private ProgressDialog mPowerOffDialog = null;
    private AlertDialog mScanDialog = null;
    private ProgressDialog cancelScanDialog = null;
    private AlertDialog mSetTimeDialog = null;
    private AlertDialog mNoHeadsetDialog = null;
    private ChannelHolder mChannelHolder = null;
    private boolean status = false;
    private boolean isHeadsetOn = false;
    private float lastX = 0;
    private float startX = 0;
    private float endX = 0;
    public static boolean isClickPowerBtn = false;
    private boolean holdAdd = false;
    private boolean isRegister = false;
    private boolean isClickSingleScanBtn = false;
    private String psText = null;
    private boolean mIsForegroundActivity = false;
    private boolean mToggleMute = false; // To toggle between the mute/unmute
	private int mStereoMono = 0;//stereo
	private int mBand;
	

	public static final int CONFIGURATION_STATE_IDLE = 1;
	public static final int CONFIGURATION_STATE_PENDING = 2;
	public static final String INTENT_RDS_CONFIG = "android.intent.action.RDS_CONFIGURATION";
	public static final int ACTIVITY_CONFIG = 2;
	public static int configurationState = CONFIGURATION_STATE_IDLE;
	
	private  List<Station> mFavoriteChannelList = null;
	
	private static final int BTN_POSITION_1 = 1;
	private static final int BTN_POSITION_2 = 2;
	private static final int BTN_POSITION_3 = 3;
	private static final int BTN_POSITION_4 = 4;
	private static final int BTN_POSITION_5 = 5;
	private static final int BTN_POSITION_6 = 6;
	
	private SharedPreferences mSharedpreference = null;
	private List<Station> mFavoriteList = null;
	
    private static final int [] mButtonID = {
        R.id.search_btn_forward,R.id.search_btn_rew,
        R.id.btn_list
    };
    
    private  final SaveFavoriteChannelLayout [] mChannelLayout = new SaveFavoriteChannelLayout[6];
    private static final int[] mDrawableID = {
        R.drawable.art_radio_number_0,
        R.drawable.art_radio_number_1,
        R.drawable.art_radio_number_2,
        R.drawable.art_radio_number_3,
        R.drawable.art_radio_number_4,
        R.drawable.art_radio_number_5,
        R.drawable.art_radio_number_6,
        R.drawable.art_radio_number_7,
        R.drawable.art_radio_number_8,
        R.drawable.art_radio_number_9,
        R.drawable.art_radio_number_point,
        R.drawable.art_radio_number_mhz
    };
    
    private static final int[] mSoundID = {
        R.drawable.sound_0,
        R.drawable.sound_1,
        R.drawable.sound_2,
        R.drawable.sound_3,
        R.drawable.sound_4,
        R.drawable.sound_5,
        R.drawable.sound_6,
        R.drawable.sound_7,
        R.drawable.sound_8,
    };
    
    private static final int[] mSignalID = {
    	R.drawable.signal_0,
    	R.drawable.signal_1,
    	R.drawable.signal_2,
    	R.drawable.signal_3,
    	R.drawable.signal_4,
    	R.drawable.signal_5
    };
    
	private static final Drawable[] mbtnDraws = new Drawable[6];
	private static final int[] mbtnDrawableID = { R.drawable.btn1,
			R.drawable.btn2, R.drawable.btn3, R.drawable.btn4, R.drawable.btn5,
			R.drawable.btn6, };

	private static final Drawable[] mbtnDraws_press = new Drawable[6];
	private static final int[] mbtnDrawableID_press = { R.drawable.btn1_press,
			R.drawable.btn2_press, R.drawable.btn3_press,
			R.drawable.btn4_press, R.drawable.btn5_press,
			R.drawable.btn6_press, };

    private static final Drawable[] mDraws = new Drawable[12];
    private static final Drawable[] mSoundDraws = new Drawable[9];
    private static final Drawable[] mSignalDraws = new Drawable[6];
	private ProgressDialog pd = null;
	private ProgressDialog configPd = null;
	 
    private BroadcastReceiver mBr = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            LogUtils.d(TAG, "FMRadioActivity enter onReceive" + action);
            if (Constants.SCAN_FINISH.equals(action)) {
//            	setPsName("");
            	if (!checkWorkFreqChange()) {
                    LogUtils.d(TAG,"SCAN_FINISH checkWorkFreqChange is different");
	            	setPSText("");
	            	ptyInfo.setText("");
	           	    tvPSInfo.setText("");
	           	    tvRadioText.setText("");
	            	setStereoState(0);
            	}
                handleScanFinish();
            } else if (Constants.SPEAKER_CHANGE_ACTION.equals(action)) {
                if (mChannelHolder == null) {
                    mChannelHolder = ChannelHolder.getInstance();
                }
            } else if (Constants.SCAN_ALREADY_STOP.equals(action)) {
                scanAlreadyStop(intent);
                LogUtils.d(TAG,"reviced scan_already_stop intent");
            } /*else if (Constants.FINISH_FM.equals(action)) {
                finish();
            }*/ else if (Constants.STEREO_CHANGED.equals(action)) {
            	mStereoMono = intent.getIntExtra("stereo", 0);
            	setStereoState(mStereoMono);
            } else if (Constants.PS_CHANGED.equals(action)) {
            	String ps = intent.getStringExtra("ps");
            	setPSText(ps);
            	setPsName(mChannelHolder.getWorkFreq());
            } else if (Constants.RT_CHANGED.equals(action)) {
            	String rt = intent.getStringExtra("rt");
            	setRTInfos(rt);
            } 
        }
        
    };

    private void setPSText(String rt) {
    	LogUtils.d(TAG, "rt = " + rt);
    	psText = rt;
    }
    
    private void setRTInfos(String rt){
    	LogUtils.d(TAG, "radio text is  " + rt);
    	if (null != tvRadioText && !TextUtils.equals(rt, tvRadioText.getText())) {
    		StringBuilder sb= new StringBuilder();
//    		sb.append(tvPSInfo.getText());
//    		sb.append("  ");
    		sb.append(rt);
    		tvRadioText.setText(sb.toString());
    		tvRadioText.setFocusable(true);
		}
    }
    //if radioText is not null, show radioText else if has channel name ,set it as channel name,
    //else show unkown channel
    private void setPsName(int fre) {
    	LogUtils.d(TAG, "ps = " + fre);
    	String channelName = mChannelHolder.getChannelName(fre);
//    	if(TextUtils.isEmpty(channelName)) {
//    		channelName = FMRadioActivity.this.getString(R.string.unknown_name);
//    	}
    	if (!TextUtils.isEmpty(psText)) {
    		channelName = psText;
    	}
    	
    	if (TextUtils.isEmpty(channelName)){
    		channelName = "";
    	}
    	LogUtils.d(TAG, "channelName = " + channelName);
    	StringBuilder sb= new StringBuilder();
    	sb.append(channelName);
		if (null != tvPSInfo) {
			if (!TextUtils.isEmpty(psText) && !getRDSState()) {
				LogUtils.d(TAG, "tvPSInfo set null... " + psText);
				tvPSInfo.setText("");
			} else {		
				tvPSInfo.setText(sb.toString());
				LogUtils.d(TAG, "tvPSInfo set: " + sb.toString());
			}
		}
    }
    
    private boolean getRDSState(){
        SharedPreferences fmConfigPreferences = getSharedPreferences(
				"fmConfigPreferences", MODE_PRIVATE);
       return fmConfigPreferences.getBoolean(Constants.RDS, Constants.DEFAULT_RDS);
    }
    private void setStereoState(int stereoState) {
    	String ST = FMRadioActivity.this.getString(R.string.stereo);
    	String str = stereoState == 1 ? "" : ST;
    	mStereoMono = stereoState;
    	LogUtils.d(TAG, "stereoState = " + stereoState);
		if (null != tvStereoInfo) {
			tvStereoInfo.setText(str);
		}
    }
    
    private void handleScanFinish() {
        LogUtils.d(TAG,"mScanDialog " + mScanDialog);
        if (mScanDialog != null && mScanDialog.isShowing()) {
            mScanDialog.dismiss();
            mScanDialog = null;
            setBtnEnable();
        } else {
        	if (cancelScanDialog != null && cancelScanDialog.isShowing()){
                cancelScanDialog.dismiss();
                cancelScanDialog = null;
            }
        	setBtnEnable();
            LogUtils.d(TAG,"scan dialog is not showing");
            return;
        }
        mChannelHolder.flush();
        if (!checkWorkFreqChange()) {
            LogUtils.d(TAG,"checkWorkFreqChange is different");
            setFrequencyView();
        }
        if (isClickSingleScanBtn) {
            isClickSingleScanBtn = false;
        }
        if (cancelScanDialog != null && cancelScanDialog.isShowing()){
            cancelScanDialog.dismiss();
            cancelScanDialog = null;
        }
        Toast.makeText(FMRadioActivity.this, R.string.scan_finish, Toast.LENGTH_SHORT).show();
    }
    
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            LogUtils.d(TAG, "msg is " + msg);
            switch (msg.what) {
            case Constants.MSG_HEADSET_STATE:
                isHeadsetOn = (msg.arg1==0 ? false : true);
                LogUtils.d(TAG, "FMRadioActivity isFinishing  " + FMRadioActivity.this.isFinishing());
                if (FMRadioActivity.this.isFinishing())
                	return;
                setFrequencyView();
                if (!isHeadsetOn) {
                	if(mChannelHolder.getIsForegroundActivity()){
                		handleNoHeadsetDialog();
//                		enableSpeaker(false);
                	} else {
                		Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                	}
                }else{
                	if (mNoHeadsetDialog != null) {
            			mNoHeadsetDialog.dismiss();
            		}
                }
                break;
            case Constants.MSG_FM_STATUS:
                status = (msg.arg1==1 ? true : false);
                if (!status) {
                    enableFM();
                }
                break;
            case Constants.EVENT_RADIO_ENABLE_BEGIN:
            	createWaitDialog();
            	break;
            case Constants.MSG_ENABLE_SUCCESSFUL:
            	if (pd != null){
					pd.dismiss();
					pd = null;
				}
                handleEnableFMResult(true);
                break;
            case Constants.MSG_ENABLE_FAILED:
            	if (pd != null){
					pd.dismiss();
					pd = null;
				}
                handleEnableFMResult(false);
                LogUtils.d(TAG,"MSG_ENABLE_FAILED !!");
                handleDisableFMResult();
                break;
            case Constants.MSG_DISABLE_SUCCESSFUL:
                handleDisableFMResult();
                break;
            case Constants.MSG_SET_CHANNEL:
            	if (!checkWorkFreqChange()) {
                    LogUtils.d(TAG,"MSG_SET_CHANNEL checkWorkFreqChange is different");
	            	ptyInfo.setText("");
	           	 	tvPSInfo.setText("");
	           	 	tvRadioText.setText("");
	            	setPSText("");
	            	setRTInfos("");
            	}
                setFrequencyView();
                break;
            case Constants.MSG_HEADSET_INFO:
                if (!isHeadsetOn) {
                	Intent intent = new Intent(Constants.NO_HEADSET_PLUG);
        			sendBroadcast(intent);
                }
                break;
            case Constants.MSG_DIALOG_CHECK:
                if (mPowerOnDialog != null && mPowerOnDialog.isShowing()) {
                    mPowerOnDialog.dismiss();
                }
                if (mPowerOffDialog != null && mPowerOffDialog.isShowing()) {
                    handleDisableFMResult();
                }
                break;
            case Constants.CHECK_SERVICE_HANDLER:
                Handler h = FMService.getHandler();
                if (h == null) {
                    LogUtils.d(TAG,"Handle handler is null");
                    FMService.setHandler(mHandler);
                    mHandler.sendMessage(Message.obtain(mHandler, Constants.CHECK_SERVICE_HANDLER));
                } 
                break;
            case Constants.MSG_FINISH_ACTIVITY:
            	finish();
            	break;
           case Constants.MSG_CHANGE_POWER_BTN:
        	   isClickPowerBtn = true;
        	   if (mChannelHolder.getSpeakerOn()) {
               	setFmSpeaker(false);
               }
         		break;
             case Constants.MSG_ADD_STATION:
                boolean flag = (msg.arg1 == 0 ? false : true);
                if (flag) {
                    Toast.makeText(FMRadioActivity.this, R.string.add_channel, 500).show();
                } else {
                    Toast.makeText(FMRadioActivity.this, R.string.cancel_channel, 500).show();
                }
                setFrequencyView();
                mChannelHolder.flush();
                holdAdd = false;
                break;
             case Constants.EVENT_MUTE_CHANGE:
            	 int muteStatus = (Integer) msg.obj;
            	 LogUtils.d(TAG,"EVENT_MUTE_CHANGE...  " + muteStatus);
            	 if (muteStatus == 0)
            		 mToggleMute = !mToggleMute;
            	 break;
             case Constants.EVENT_GET_MUTE_MODE:
            	 int mutemode = (Integer) msg.obj;
            	 LogUtils.d(TAG,"EVENT_GET_MUTE_MODE...  " + mutemode);
            	 mToggleMute = (mutemode == 0);
            	 break;
             case Constants.EVENT_MASTER_VOLUME_CHANGED:
            	 int volumn = (Integer)msg.obj;
            	 LogUtils.d(TAG,"EVENT_MASTER_VOLUME_CHANGED...  " + volumn);
            	 updateSoundView(volumn);
            	 break;
             case Constants.EVENT_GET_RSSI:
            	 int gRssi = (Integer)msg.obj;
            	 LogUtils.d(TAG,"EVENT_MASTER_VOLUME_CHANGED...  " + gRssi);
            	 updateSignalView(gRssi);
            	 break;

             case Constants.MSG_SET_FAVORITE_BTN:
            	 int req = msg.arg1;
            	 LogUtils.d(TAG, "set favorite btn channel is " + req);
            	 resetFavoriteChannelBtn(req);
            	 break;
             case Constants.EVENT_PTY_CODE:
					String pty = (String) msg.obj;

					LogUtils.d(TAG, "enter handleMessage ----EVENT_PTY_CODE " + pty);
					int ptyValue = Integer.parseInt(pty);
					String[] ptyCodes;

					ptyCodes = (FMService.mRdsSystem == Constants.DEFAULT_RDS_SYSTEM) ?
						    getResources().getStringArray(R.array.ptyEU) : getResources().getStringArray(R.array.ptyNA);

				    StringBuilder sb = new StringBuilder();
					/* First PTY code is undefined */
					if (ptyValue > 0 && ptyValue < ptyCodes.length) {
						sb = new StringBuilder();
						sb.append(ptyCodes[ptyValue]);
						LogUtils.d(TAG, "enter handleMessage ----EVENT_PTY_CODE sb.toString()" + sb.toString());
					}
					ptyInfo.setText(sb.toString());
					break;
             case Constants.EVENT_RADIO_CHANGE_FREQ:
            	 mBand = (Integer)msg.obj;
            	 LogUtils.d(TAG, "enter handleMessage ----EVENT_RADIO_CHANGE_FREQ band = " + mBand);
            	 if (mBand == 0){//EUROPE band
            		 vScale.getDrawable().setLevel(4);
            	 } else {//Japan band
            		 vScale.getDrawable().setLevel(14);
            	 }
            	 lastX = 0;
            	 break;
             case Constants.EVENT_SET_RSSI_THRESHHOLD:
            	 configurationState = CONFIGURATION_STATE_IDLE;
            	 break;
             case Constants.EVENT_DISABLE_RDS:
            	 ptyInfo.setText("");
            	 setPSText("");
            	 setPsName(mChannelHolder.getWorkFreq());
            	 tvRadioText.setText("");
            	 break;
             case Constants.FM_ERROR:
            	 String errormsg = (String) msg.obj;
            	 LogUtils.d(TAG, " FM_ERROR  " + errormsg);
            	 showErrorDialog(errormsg);
            	 break;
             case  Constants.MSG_STOP_SCAN:
            	 scanAlreadyStop(null);
            	 break;
             case Constants.MSG_SET_TIME:
            	 int time = msg.arg1;
            	 LogUtils.d(TAG, "handle message set time is: " + time);
                 Intent intent = new Intent(Constants.SET_TIME);
                 intent.putExtra("time", time);
                 FMRadioActivity.this.sendBroadcast(intent);
                 LogUtils.d(TAG, "set time intent send successfully...");
                 break;
            }
        }
    };

    private void scanAlreadyStop(Intent intent) {
        mChannelHolder.flush();
        
        if (cancelScanDialog != null && cancelScanDialog.isShowing()){
            cancelScanDialog.dismiss();
            cancelScanDialog = null;
            Toast.makeText(FMRadioActivity.this, R.string.stop_scan_success, 500).show();
        }
        setBtnEnable();
        if (isClickSingleScanBtn) {
            isClickSingleScanBtn = false;
        }
    }
    
    private boolean checkWorkFreqChange() {
        int freq = mChannelHolder.getWorkFreq();
        Drawable d1 = v1.getDrawable();
        Drawable d2 = v2.getDrawable();
        Drawable d3 = v3.getDrawable();
        Drawable d4 = v4.getDrawable();
        int nFreq = 0;
        for (int i=0; i < 10; i++) {
             if (mDraws[i].equals(d1) && v1.getVisibility() == View.VISIBLE) {
                 nFreq += i*100000;
             }
             if (mDraws[i].equals(d2)) {
                 nFreq += i*10000;
             }
             if (mDraws[i].equals(d3)) {
                 nFreq += i*1000;
             }
             if (mDraws[i].equals(d4)) {
                 nFreq += i*100;
             }
        }
        LogUtils.d(TAG,"freq is "+ freq + ",nFreq is " + nFreq);
        return freq == nFreq ? true : false;
    }
    
    private void handleNoHeadsetDialog(){
//		startServiceByAction(Constants.DISABLE_FM);
		if (!isFinishing()) {
			if (null == mNoHeadsetDialog) {
				mNoHeadsetDialog = new AlertDialog.Builder(this)
						.setTitle(R.string.no_headset)
						.setIcon(R.drawable.art_dialog_notice)
						.setMessage(R.string.no_headset)
						.setNegativeButton(R.string.cancel,
								new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										noHeadsetDisableFM();
									}
								}).setOnCancelListener(new OnCancelListener() {
							public void onCancel(DialogInterface dialog) {
								noHeadsetDisableFM();
							}
						}).create();
			}
			mNoHeadsetDialog.show();
		} else {
			Intent intent = new Intent(Constants.NO_HEADSET_PLUG);
			sendBroadcast(intent);
		}
    }


	private void handleEnableFMResult(boolean isSuccessful) {
        if (mPowerOnDialog != null && mPowerOnDialog.isShowing()) {
            mPowerOnDialog.dismiss();
        }
        LogUtils.d(TAG,"handleEnableFMResult state " + isSuccessful);
        if (isSuccessful) {
        	//reset mute status
        	mToggleMute = false;
        	btnMute.setImageResource(R.drawable.mute_on);
        	mChannelHolder.setSpeakerOn(isFmSpeakerOn());
            
        	if (!isHeadsetOn){
        		handleNoHeadsetDialog();
        	} else {
        		if (mNoHeadsetDialog != null) {
        			mNoHeadsetDialog.dismiss();
        			mNoHeadsetDialog = null;
        		}
        	}
            if (!mChannelHolder.getIsAudioFocus()) {
                setBtnEnable();
            }
            status = true;
            setFrequencyView();
            if (isClickSingleScanBtn) {
                isClickSingleScanBtn = false;
            }
        } else {
            status = false;
        }
    }
    
	private void noHeadsetDisableFM(){
		LogUtils.d(TAG,"noHeadsetDisableFM... sFmRadio = " + FMService.sFmRadio);
		if (null == FMService.sFmRadio)
			return;
		LogUtils.d(TAG,"noHeadsetDisableFM..." + FMService.sFmRadio.rxGetFMState());
		if (FMService.sFmRadio.rxGetFMState() == FmRadio.STATE_ENABLED){
			disableFM();
		} else {
			mChannelHolder.setIsAudioFocus(false);
			Intent intent = new Intent(FMRadioActivity.this, FMService.class);
			FMRadioActivity.this.stopService(intent);
			isClickPowerBtn = false;
			if (mChannelHolder == null){
				mChannelHolder = ChannelHolder.getInstance();
			}
			mChannelHolder.flush();
			finish();
		}
        LogUtils.d(TAG,"noHeadsetDisableFM...");
	}
    private void handleDisableFMResult() {
    	 if (mChannelHolder == null) {
             mChannelHolder = ChannelHolder.getInstance();
         }
         if (mChannelHolder.getSpeakerOn()) {
         	setFmSpeaker(false);
         }
        if (mScanDialog != null && mScanDialog.isShowing()) {
            mScanDialog.dismiss();
            mScanDialog = null;
            setBtnEnable();
        }
        if (mPowerOffDialog != null && mPowerOffDialog.isShowing()) {
            mPowerOffDialog.dismiss();
        }
        status = false;
        
//        
            
		mChannelHolder.setIsAudioFocus(false);
		Intent intent = new Intent(FMRadioActivity.this, FMService.class);
		FMRadioActivity.this.stopService(intent);

		mChannelHolder.flush();
		
		LogUtils.d(TAG, "click isClickPowerBtn button isClickPowerBtn " + isClickPowerBtn);

        if (isClickSingleScanBtn) {
            isClickSingleScanBtn = false;
        }
		finish();
//        } else {
//            LogUtils.d(TAG,"Not click isClickPowerBtn button");
//        }

    }

    private void enableFM() {
    	LogUtils.d(TAG,"begin to enableFM isHeadsetOn " + isHeadsetOn);
    	if (isHeadsetOn)
    		startServiceByAction(Constants.ENABLE_FM);
    }
    
    private void disableFM() {
    	LogUtils.d(TAG,"disableFM");
        isClickPowerBtn = true;
        startServiceByAction(Constants.DISABLE_FM);
        if (mChannelHolder.getSpeakerOn()) {
        	setFmSpeaker(false);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtils.d(TAG, "onCreate!");
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        boolean validm = (dm.widthPixels ==480 && dm.heightPixels == 320) || (dm.widthPixels == 320 || dm.heightPixels == 480);
        boolean validh = (dm.widthPixels ==480 && dm.heightPixels == 800) || (dm.widthPixels == 800 || dm.heightPixels == 480);
        boolean valid = (validm || validh);
        if (!valid) {
            Toast.makeText(this, R.string.pixes_warning, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        if (tm.getCallState() != TelephonyManager.CALL_STATE_IDLE) {
            Toast.makeText(this, R.string.call_warning, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
		if (isAirplaneMode(getApplicationContext())) {
			Toast.makeText(this, R.string.airplane_mode, Toast.LENGTH_SHORT)
					.show();
			finish();
			return;
		}
        setContentView(R.layout.main_ui);
        /*try {
            LogUtils.d(TAG,"begin to set the background");
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inDither = true;
            TypedValue tv = new TypedValue();
            Resources resources = getResources();
            InputStream is = resources.openRawResource(R.drawable.cmcc_radio_bg,tv);
            String file = tv.string.toString();
            Drawable back = Drawable.createFromResourceStream(resources, tv, is, file, opt);
            findViewById(R.id.background).setBackgroundDrawable(back);
            is.close();
            LogUtils.d(TAG,"set background successful");
        } catch(Exception e) {
            LogUtils.d(TAG,"set background failed");
        }*/
        FMService.setHandler(mHandler);
        mHandler.sendMessage(Message.obtain(mHandler, Constants.CHECK_SERVICE_HANDLER));
        mChannelHolder = ChannelHolder.getInstance();
        initDrawables();
        initBtnDrawables();
        initBtn_pressDrawables();
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        isHeadsetOn = am.isWiredHeadsetOn();

        v1 = (ImageView) findViewById(R.id.hp);
        v2 = (ImageView) findViewById(R.id.tp);
        v3 = (ImageView) findViewById(R.id.unit);
        vPoint = (ImageView) findViewById(R.id.point);
        v4 = (ImageView) findViewById(R.id.sn);
        vMhz = (ImageView) findViewById(R.id.mhz);
        mPowerBtn = (ImageButton) findViewById(R.id.btn_exit);
        OnClickListener listener = new FMOnClickListener();
        btnForward = (ImageButton)findViewById(R.id.search_btn_forward);
        btnForward.setOnClickListener(listener);
        btnRew = (ImageButton)findViewById(R.id.search_btn_rew);
        btnRew.setOnClickListener(listener);
        btnSearchBack = (ImageButton)findViewById(R.id.search_btn_back);
        btnSearchBack.setOnClickListener(listener);
        btnSearchNext = (ImageButton)findViewById(R.id.search_btn_next);
        btnSearchNext.setOnClickListener(listener);

        vScale = (ImageView) findViewById(R.id.scale);
        SharedPreferences fmConfigPreferences = getSharedPreferences(
				"fmConfigPreferences", MODE_PRIVATE);
        mBand = fmConfigPreferences.getInt(Constants.BAND, Constants.DEFAULT_BAND);
        if (mBand == Constants.DEFAULT_BAND){
			vScale.getDrawable().setLevel(4);
			UNITDIP = 7;
			MIN_CHANNEL = -22f;
			MAX_CHANNEL = MIN_CHANNEL-UNITDIP*(Constants.EUROPE_MAX_FREQ-Constants.EUROPE_MIN_FREQ)/100f;
        }
        else {
        	vScale.getDrawable().setLevel(14);
			UNITDIP = 7;
			MIN_CHANNEL = -22f;
			MAX_CHANNEL = MIN_CHANNEL-UNITDIP*(Constants.JAPAN_MAX_FREQ-Constants.JAPAN_MIN_FREQ)/100f;
        }
        mPowerBtn.setOnClickListener(listener);
        btnList = (ImageButton)findViewById(R.id.btn_list);
        btnSpeaker = (ImageButton)findViewById(R.id.btn_speaker);
        btnSpeaker.setOnClickListener(listener);
        btnMute = (ImageButton) findViewById(R.id.btn_mute);
        btnMute.setOnClickListener(listener);
        tvPSInfo = (TextView) findViewById(R.id.ps_info);
        tvStereoInfo = (TextView) findViewById(R.id.stereo_info);
        ptyInfo = (TextView) findViewById(R.id.pty_info);
        soundView = (ImageView) findViewById(R.id.sound_view);
        signalView = (ImageView) findViewById(R.id.signal_view);
        tvRadioText = (TextView) findViewById(R.id.rt_info);
        int lastVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        updateSoundView(lastVolume);
        
        for (int i = 0; i < mButtonID.length; i++) {
            ImageButton btn = (ImageButton)findViewById(mButtonID[i]);
            btn.setOnClickListener(listener);
        }

		vScale.setLongClickable(true);
		mGestureDetector = new GestureDetector(this, new ScrolGestureListener());
        OnTouchListener onTouchListener = new FMOnTouchListener();
//        vScale.setOnTouchListener(onTouchListener);
        mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_HEADSET_INFO));
        mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DIALOG_CHECK),8000);
        startServiceByAction(Constants.GET_FM_STATUS);
        mChannelHolder.setIsForegroundActivity(true);
        
        initFavoriteChannel();
        if (!isRegister) {
            IntentFilter intentFilter = new IntentFilter(Constants.SCAN_FINISH);
            intentFilter.addAction(Constants.SPEAKER_CHANGE_ACTION);
            intentFilter.addAction(Constants.SCAN_ALREADY_STOP);
//            intentFilter.addAction(Constants.FINISH_FM);
            intentFilter.addAction(Constants.STEREO_CHANGED);
            intentFilter.addAction(Constants.PS_CHANGED);
            intentFilter.addAction(Constants.RT_CHANGED);
            registerReceiver(mBr, intentFilter);
            isRegister = true;
        }
        mSharedpreference = getSharedPreferences("fmConfigPreferences",MODE_PRIVATE);
        int time = mSharedpreference.getInt("set_time", 0);
        LogUtils.d(TAG,"get time is " + time);
        if (0 != time) {
        	Message msg = Message.obtain(mHandler, Constants.MSG_SET_TIME);
        	msg.arg1 = time;
            mHandler.sendMessageDelayed(msg,2000);
            LogUtils.d(TAG, "set time handle send success...");
        }
        LogUtils.d(TAG,"FM has been opened successful + lastVolume " + lastVolume);
    }

    
	private void initFavoriteChannel() {
		mFavoriteList = mChannelHolder.getFavoriteStationList();
		LogUtils.d(TAG,"initFavoriteChannel mFavoriteList: " + mFavoriteList.size());
		OnClickListener SaveListener = new SaveFavoriteChannel();
		OnLongClickListener saveLongListener = new SaveChannelLongClick();
		
		mChannelLayout[0] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_1);
		mChannelLayout[0].setOnClickListener(SaveListener);
		mChannelLayout[0].setOnLongClickListener(saveLongListener);
		
		mChannelLayout[1] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_2);
		mChannelLayout[1].setOnClickListener(SaveListener);
		mChannelLayout[1].setOnLongClickListener(saveLongListener);
		
		mChannelLayout[2] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_3);
		mChannelLayout[2].setOnClickListener(SaveListener);
		mChannelLayout[2].setOnLongClickListener(saveLongListener);
		
		mChannelLayout[3] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_4);
		mChannelLayout[3].setOnClickListener(SaveListener);
		mChannelLayout[3].setOnLongClickListener(saveLongListener);
		
		mChannelLayout[4] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_5);
		mChannelLayout[4].setOnClickListener(SaveListener);
		mChannelLayout[4].setOnLongClickListener(saveLongListener);
		
		
		mChannelLayout[5] = (SaveFavoriteChannelLayout) this
				.findViewById(R.id.save_channel_6);
		mChannelLayout[5].setOnClickListener(SaveListener);
		mChannelLayout[5].setOnLongClickListener(saveLongListener);
		
		
		setDefaultChannelValues();

	}
	
	private  boolean isExistFavoriteChannel(int req) {
		LogUtils.d(TAG, "isExistFavoriteChannel req: " + req);
		List<Station> list = mChannelHolder.getStationList();
		for (Station sta : list) {
			if (String.valueOf(req).equals(sta.getFreq())
					&& String.valueOf(true).equals(sta.getFavorStatus())) {
				return true;
			}
		}
		return false;
	}
	
	private void setDefaultChannelValue(int position, int freq) {
		if (isWorkFre(freq)){
			mChannelLayout[position-1].updateDrawableByChannel(freq);
			mChannelLayout[position-1].setBackgroundDrawable(mbtnDraws_press[position-1]);
		} else {
			if (0 == freq) {
				mChannelLayout[position-1].updateDrawableNoChannel();
				mChannelLayout[position-1].setBackgroundDrawable(mbtnDraws[position - 1]);
			} else {
				mChannelLayout[position-1].updateDefaultDrawableByChannel(freq);
				mChannelLayout[position-1].setBackgroundDrawable(mbtnDraws[position - 1]);
			}

		}
	}
	
	private void setDefaultChannelValues () {
		LogUtils.d(TAG,"setDefaultChannelValue mFavoriteList: " + mFavoriteList);
		if (null != mFavoriteList) {
			for (Station sta : mFavoriteList) {
				int position = sta.getPosition();
				int fre = Integer.valueOf(sta.getFreq());
				if (0 != position) {
					setDefaultChannelValue(position, fre);
				}
			}
		}
	}
	private boolean isWorkFre(int fre) {
		int workFre = mChannelHolder.getWorkFreq();
		LogUtils.d(TAG, "isWorkFre: " + workFre + ", fre: " + fre);
		if (fre == workFre) {
			return true;
		}
		return false;
	}

	private void resetFavoriteChannelBtn(int freq) {
		int position = mChannelHolder.getPositionByChannel(freq);
		LogUtils.d(TAG, "resetFavoriteChannelBtn: " + position);
//		if (0 == position) {
		  restoreOtherButtons(position);
//			return;
//		}		

	}
	
	private void refreshFavoriteChannelValues () {
		List<Station> list = mChannelHolder.getStationList();
		for  (Station sta : list){
			if (String.valueOf(true).equals(sta.getFavorStatus())) {
				int position = sta.getPosition();
				int fre = Integer.valueOf(sta.getFreq());
				if (0 != position) {
					setDefaultChannelValue(position, fre);
				}
			}
		}
	}
	private int getExistFavoriteChannelPosition(int i) {
		mFavoriteChannelList = mChannelHolder.getStationList();
		for (Station sta : mFavoriteChannelList) {
			if (i == sta.getPosition()
					&& String.valueOf(true).equals(sta.getFavorStatus())) {
				return Integer.valueOf(sta.getFreq());
			}
		}
		return 0;

	}
	

	private void sendSetChannelIntent(int channel) {
		LogUtils.d(TAG,"sendSetChannelIntent: " + channel);
		Intent intent = new Intent(FMRadioActivity.this, FMService.class);
        intent.setAction(Constants.SET_CHANNEL);
        LogUtils.d(TAG, "Double.valueOf(channel/1000): " + Double.valueOf(channel)/1000);
        intent.putExtra("channel",Double.valueOf(channel)/1000);
        FMRadioActivity.this.startService(intent);
	}

	private void handleButtonOnClickEvent(int position) {
		int freq = getExistFavoriteChannelPosition(position);
		if (0 == freq) {
			return;
		}
		if (isWorkFre(freq)) {
			return;
		}
		mChannelLayout[position-1].updateDrawableByChannel(freq);
		mChannelLayout[position-1]
				.setBackgroundDrawable(mbtnDraws_press[position-1]);
		restoreOtherButtons(position);
		LogUtils.d(TAG, "send intent2: " + freq);
		sendSetChannelIntent(freq);
	}
	class SaveFavoriteChannel implements OnClickListener {
		int freq = 0;
		@Override
		public void onClick(View v) {
			 LogUtils.d(TAG, "save channel on click.........");
			switch (v.getId()) {
			case R.id.save_channel_1:
				handleButtonOnClickEvent(BTN_POSITION_1);
				break;
			case R.id.save_channel_2:
				handleButtonOnClickEvent(BTN_POSITION_2);
				break;
			case R.id.save_channel_3:
				handleButtonOnClickEvent(BTN_POSITION_3);
				break;
			case R.id.save_channel_4:
				handleButtonOnClickEvent(BTN_POSITION_4);
				break;
			case R.id.save_channel_5:
				handleButtonOnClickEvent(BTN_POSITION_5);
				break;
			case R.id.save_channel_6:
				handleButtonOnClickEvent(BTN_POSITION_6);
				break;

			}

		}

	}
	
	private void handleOnLongClickEvent(int position){
		int channel = getExistFavoriteChannelPosition(position);
		int workFreq = mChannelHolder.getWorkFreq();
		String name = mChannelHolder.getChannelName(workFreq);
		if (channel == workFreq){
			return;
		}
		if (0 != channel) {
			updateChannel(mChannelHolder.getChannelName(channel),String.valueOf(channel),position);
		}
		saveChannel(name,String.valueOf(workFreq),position);

		mChannelLayout[position-1].updateDrawableByChannel(workFreq);
		mChannelLayout[position-1].setBackgroundDrawable(mbtnDraws_press[position-1]);
		
		restoreOtherButtons(position);
	}
	
	private void restoreOtherButtons(int position){
		LogUtils.d(TAG, "resoreOtherButtons i : " + position);
		for (int i = 0; i < mChannelLayout.length; i ++) {
			LogUtils.d(TAG, "restoreOtherButtons.....: " + i);
			int fre = getExistFavoriteChannelPosition(i+1);
			if (i == position-1) {
				LogUtils.d(TAG, "not restore i : " + i);
				if (0 != fre) {
					mChannelLayout[i].updateDrawableByChannel(fre);
					mChannelLayout[i].setBackgroundDrawable(mbtnDraws_press[i]);		
				} else {
					mChannelLayout[i].updateDrawableNoChannel();
					mChannelLayout[i].setBackgroundDrawable(mbtnDraws[i]);
				}
			} else {
				LogUtils.d(TAG, "restore i: " + i + ", fre: " + fre);
				if (0 != fre) {
					mChannelLayout[i].updateDefaultDrawableByChannel(fre);
					mChannelLayout[i].setBackgroundDrawable(mbtnDraws[i]);
				} else {
					mChannelLayout[i].updateDrawableNoChannel();
					mChannelLayout[i].setBackgroundDrawable(mbtnDraws[i]);
				}
			}
		}
	}
	class SaveChannelLongClick implements OnLongClickListener{
		int Workfrq = 0;
		int channelByPosition = 0;
		String name = "";
		 
		@Override
		public boolean onLongClick(View v) {
			 LogUtils.d(TAG,"save channel on long click Listener.........");
			Workfrq = mChannelHolder.getWorkFreq();
			name = mChannelHolder.getChannelName(Workfrq);
			if (isExistFavoriteChannel(Workfrq)) {
				Toast.makeText(FMRadioActivity.this, R.string.favorite_channel_exist, Toast.LENGTH_SHORT).show();
				return true;
			}
			if(mChannelHolder.isNormalChannelMax()
					&& mChannelHolder.isFavoriteMax()){
				Toast.makeText(
						FMRadioActivity.this,
						R.string.all_channel_max_info,
						Toast.LENGTH_LONG)
						.show();
				return true;
			}
			switch (v.getId()) {
			case R.id.save_channel_1:
				handleOnLongClickEvent(BTN_POSITION_1);
				break;
			case R.id.save_channel_2:
				handleOnLongClickEvent(BTN_POSITION_2);
				break;
			case R.id.save_channel_3:
				handleOnLongClickEvent(BTN_POSITION_3);
				break;
			case R.id.save_channel_4:
				handleOnLongClickEvent(BTN_POSITION_4);
				break;
			case R.id.save_channel_5:
				handleOnLongClickEvent(BTN_POSITION_5);
				break;
			case R.id.save_channel_6:
				handleOnLongClickEvent(BTN_POSITION_6);
				break;
				
			}
			return false;
		}
		
	}
	
	
	private void saveChannel(String name, String channel, int position) {
		 LogUtils.d(TAG, "saveChannel name: " + name + ", channel: " + channel
				+ ",position: " + position);
		Station station = new Station();
		station.setName(name);
		station.setFreq(channel);
		station.setFavorStatus(String.valueOf(true));
		station.setPosition(position);
		int i = mChannelHolder.add(station);
		Toast.makeText(FMRadioActivity.this, R.string.save_channel_success, Toast.LENGTH_SHORT).show();
		 LogUtils.d(TAG, "saveChannel: " + i);
	}
	
	private void updateChannel(String name,String channel,int position){
		LogUtils.d(TAG, "updateChannel name: " + name + ", channel: " + channel
				+ ",position: " + position);
		Station station = new Station();
		station.setName(name);
		station.setFreq(channel);
		station.setFavorStatus(String.valueOf(false));
		station.setPosition(0);
		mChannelHolder.update(station);
		
	}
	
	public static boolean isAirplaneMode(Context context) {
		return Settings.System.getInt(context.getContentResolver(),
				Settings.System.AIRPLANE_MODE_ON, 0) > 0;
	}
	
	@Override
    protected void onResume() {
        super.onResume();
        LogUtils.d(TAG,"FMRadioActivity onResume()......: " + mChannelHolder.getIsForegroundActivity() 
        		+ ",isHeadsetOn: " + isHeadsetOn);
        if (tm.getCallState() != TelephonyManager.CALL_STATE_IDLE) {
            Toast.makeText(this, R.string.call_warning, Toast.LENGTH_SHORT).show();
            moveTaskToBack(true);
            return;
        }
        
        startServiceByAction(Constants.GET_FM_STATUS);
        if (null != mHandler) {      	
        	mHandler.sendMessage(Message.obtain(mHandler, Constants.CHECK_SERVICE_HANDLER));
        }
        if(!mChannelHolder.getIsForegroundActivity()){
        	 mChannelHolder.setIsForegroundActivity(true);
        }
		if (!isHeadsetOn) {
			if (null != mHandler) {		
				mHandler.sendMessage(Message.obtain(mHandler,
						Constants.MSG_HEADSET_STATE, 0, 0));
				return;
			}
		}
        setFrequencyView();
        refreshFavoriteChannelValues();
//        setRadioText("");
        setStereoState(0);

//        if (mChannelHolder.getIsAudioFocus()) {
//            LogUtils.d(TAG,"set button disable");
//            setButtonDisable();
//        } else {
//        	 LogUtils.d(TAG,"getIsAudioFocus: " + mChannelHolder.getIsAudioFocus());
//            boolean isNativeSpeakerOn = FMNative.isSpeakerOn();
//            boolean isSpeakerOn = mChannelHolder.getSpeakerOn();
//            if (isNativeSpeakerOn != isSpeakerOn){
//                LogUtils.d(TAG,"Speaker status has changed by other application");
//                mChannelHolder.setSpeakerOn(!mChannelHolder.getSpeakerOn());
//            }
//            setButtonEnable();
//        }

        enableFM();
        updateControlIcon();
    }
    
	protected void onPause() {
		super.onPause();
		if (mChannelHolder.getIsForegroundActivity()) {
			mChannelHolder.setIsForegroundActivity(false);
		}
		if (pd != null){
			pd.dismiss();
			pd = null;
		}
	}

	private void updateControlIcon(){
		boolean enable = this.isFmSpeakerOn();
		LogUtils.d(TAG,"updateControlIcon , speaker "+ enable);
		mChannelHolder.setSpeakerOn(enable);
		if (enable) {
    		btnSpeaker.setImageResource(R.drawable.speaker_off);
    	} else {
    		btnSpeaker.setImageResource(R.drawable.speaker_on);
    	}
	}
    protected void onDestroy() {
        super.onDestroy();
        if (isRegister) {
            unregisterReceiver(mBr);
            isRegister = false;
        }
        setPSText("");
        setStereoState(0);
        if (mNoHeadsetDialog != null) {
			mNoHeadsetDialog.dismiss();
		}
        mNoHeadsetDialog = null;
        if (mPowerOnDialog != null){
        	mPowerOnDialog.dismiss();
        }
        mPowerOnDialog = null;
        if (mScanDialog != null) {
            mScanDialog.dismiss();
        }
        mScanDialog = null;
        if (cancelScanDialog != null){
        	cancelScanDialog.dismiss();
        }
        cancelScanDialog = null;
        if (mPowerOffDialog != null){
        	mPowerOffDialog.dismiss();
        }
        mPowerOffDialog = null;
        if (mSetTimeDialog != null){
        	mSetTimeDialog.dismiss();
        }
        mSetTimeDialog = null;
        if (null != tvPSInfo) {
			tvPSInfo.setText("");
		}
        if (null != tvRadioText) {
        	tvRadioText.setText("");
        }
        if (vScale != null)
            vScale.setOnTouchListener(null);
        for (int i = 0; i< mChannelLayout.length;i++){
        	//if mChannelLayout[i] is null, it means all mChannelLayout are not initialized
        	//no need to check other mChannelLayout, so no continue here, break is ok
        	if (mChannelLayout[i] == null)
        		break;
        	mChannelLayout[i].setOnClickListener(null);
        	mChannelLayout[i].setOnLongClickListener(null);
        	mChannelLayout[i] = null;
        }
        
        mGestureDetector = null;
        isClickPowerBtn = false;
        mSharedpreference = null;
        LogUtils.d(TAG,"onDestroy");
    }
    
    private void initDrawables() {
        for(int i = 0; i < mDrawableID.length ; i++) {
            mDraws[i] = getResources().getDrawable(mDrawableID[i]);
        }
        for (int i = 0; i < mSoundID.length; i++){
        	mSoundDraws[i] = getResources().getDrawable(mSoundID[i]);
        }
        for (int i = 0; i < mSignalID.length; i++){
        	mSignalDraws[i] = getResources().getDrawable(mSignalID[i]);
        }
    }

    private void initBtnDrawables() {
    	for(int i = 0; i < mbtnDrawableID.length ; i++) {
    		mbtnDraws[i] = getResources().getDrawable(mbtnDrawableID[i]);
        }
    }
    
    private void initBtn_pressDrawables() {
    	for(int i = 0; i < mbtnDrawableID_press.length ; i++) {
    		mbtnDraws_press[i] = getResources().getDrawable(mbtnDrawableID_press[i]);
        }
    }
    private void setButtonEnable(){
        for (int i = 0; i < mButtonID.length - 1; i++) {
            ImageButton btn = (ImageButton)findViewById(mButtonID[i]);
            btn.setEnabled(true);
        }    
    }

    private void setButtonDisable(){
        for (int i = 0; i < mButtonID.length - 1; i++) {
        	ImageButton btn = (ImageButton)findViewById(mButtonID[i]);
            btn.setEnabled(false);
        }
    }
    
    private void setFrequencyView() {
        int freq = mChannelHolder.getWorkFreq();
        boolean isFavorite = mChannelHolder.isWorkFreqFavorite();
//        int tem = isHeadsetOn? View.VISIBLE : View.INVISIBLE;
        int tem = View.VISIBLE;
        v2.setVisibility(tem);
        v3.setVisibility(tem);
        v4.setVisibility(tem);
        vPoint.setVisibility(tem);
        vMhz.setVisibility(tem);
        
        LogUtils.d(TAG,"setFrequencyView#workFreq is " + freq + " lastX = " + lastX );
        v2.setImageDrawable(mDraws[(freq%100000)/10000]);
        v3.setImageDrawable(mDraws[(freq%10000)/1000]);
        vPoint.setImageDrawable(mDraws[10]);
        v4.setImageDrawable(mDraws[(freq%1000)/100]);
        vMhz.setImageDrawable(mDraws[11]);
        doTranslateAnimation(lastX, freqCaculateX(), 0, 0);
        if (freq/100000 == 1){
            v1.setVisibility(tem);
            v1.setImageDrawable(mDraws[1]);
        } else {
//            v1.setVisibility(View.INVISIBLE);
        	v1.setImageResource(R.drawable.frequency_8_gray);
        }
        v1.invalidate();
        v2.invalidate();
        v3.invalidate();
        v4.invalidate();
        
        setPsName(freq);
        resetFavoriteChannelBtn(freq);
    }
    
    private void startServiceByAction(String action) {
        Intent intent = new Intent(this, FMService.class);
        intent.setAction(action);
        this.startService(intent);
    }
    
    class FMOnClickListener implements OnClickListener {
        public void onClick(View v) {
        	LogUtils.d(TAG,"onClick..................");
            switch (v.getId()) {
            case R.id.btn_speaker:
            	boolean isSpeakerOn = isFmSpeakerOn();
            	if (isSpeakerOn) {
            		enableSpeaker(false);
            	} else {
            		enableSpeaker(true);
            	}
                break;
            case R.id.btn_mute:
            	if (!mToggleMute) {
            		startServiceByAction(Constants.SET_MUTE);
            		btnMute.setImageResource(R.drawable.mute_off);
            	} else {
            		startServiceByAction(Constants.SET_UNMUTE);
            		btnMute.setImageResource(R.drawable.mute_on);
            	}
            	break;
            case R.id.btn_exit:
            	LogUtils.d(TAG,"onClick.................. isClickPowerBtn " + isClickPowerBtn);
            	if (!isClickPowerBtn)
            		disableFM();
                break;
            /*case R.id.btn_add:
                if (!isHeadsetOn) {
                    Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                    break;
                }
                int freq = mChannelHolder.getWorkFreq();
                int index = mChannelHolder.isInList(freq);
                boolean isFavor = mChannelHolder.isWorkFreqFavorite();
                LogUtils.d(TAG,"isFavor : " + isFavor);
                if (mChannelHolder.isFavoriteMax() && !isFavor) {
                    Toast.makeText(FMRadioActivity.this, R.string.favorite_max_info, Toast.LENGTH_SHORT).show();
                    break;
                }
                if (mChannelHolder.isAllMax() && index == -1) {
                    Toast.makeText(FMRadioActivity.this, R.string.all_max_info, Toast.LENGTH_SHORT).show();
                    break;
                }
                if (holdAdd) {
                    LogUtils.d(TAG,"FM is adding station now , please wait.");
                    return;
                }
                holdAdd = true;
                startServiceByAction(Constants.ADD_STATION);
                break;*/
            case R.id.search_btn_back:
                if (!isHeadsetOn) {
                    Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                    break;
                }
                startServiceByAction(Constants.FM_PREV);
                break;
                
            case R.id.search_btn_rew:
                if (!isHeadsetOn) {
                    Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                    break;
                }
                if (mChannelHolder.getIsCancel())
                    mChannelHolder.setIsCancel(false);
                if (!isClickSingleScanBtn) {
                	createSeekDialog();
                    startServiceByAction(Constants.FM_REW);
                    isClickSingleScanBtn = true;      
                }
                break;
                
			case R.id.btn_list:
				LogUtils.d(TAG, "FMOnClickListener:btn_list");
				if (!isHeadsetOn) {
					Toast.makeText(FMRadioActivity.this, R.string.no_headset,
							Toast.LENGTH_SHORT).show();
					break;
				}
				Intent intent = new Intent();
				intent.setClass(FMRadioActivity.this, AllActivity.class);
				FMRadioActivity.this.startActivity(intent);
				break;
				
            case R.id.search_btn_forward:
            	 LogUtils.d(TAG,"FMOnClickListener:search_btn_forward");
                if (!isHeadsetOn) {
                    Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                    break;
                }
                if (mChannelHolder.getIsCancel())
                    mChannelHolder.setIsCancel(false);
                if (!isClickSingleScanBtn) {
                	createSeekDialog();
                    startServiceByAction(Constants.FM_FORWARD);
                    isClickSingleScanBtn = true;
                }
                break;
            
            case R.id.search_btn_next:
            	 LogUtils.d(TAG,"FMOnClickListener:search_btn_next");
                if (!isHeadsetOn) {
                    Toast.makeText(FMRadioActivity.this, R.string.no_headset, Toast.LENGTH_SHORT).show();
                    break;
                }
                startServiceByAction(Constants.FM_NEXT);
                break;
            
            
            }
        } 
    }
    
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_ui, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (isHeadsetOn) {
            if (mChannelHolder.getIsAudioFocus()){
                menu.findItem(R.id.menu_set_channel).setEnabled(false);
                menu.findItem(R.id.menu_scan).setEnabled(false);
            } else {
                menu.findItem(R.id.menu_set_channel).setEnabled(true);
                menu.findItem(R.id.menu_scan).setEnabled(true);
            }

            /*if (mChannelHolder.getSpeakerOn()) {
           	 menu.findItem(R.id.menu_trun_off_speaker).setVisible(true);
           	 menu.findItem(R.id.menu_trun_on_speaker).setVisible(false);
           	
           } else {
           	menu.findItem(R.id.menu_trun_off_speaker).setVisible(false);
           	menu.findItem(R.id.menu_trun_on_speaker).setVisible(true);
           }*/
        } else {
            menu.findItem(R.id.menu_set_channel).setEnabled(false);
            menu.findItem(R.id.menu_scan).setEnabled(false);
           
        }
        /*if (mToggleMute){
        	menu.findItem(R.id.menu_mute).setVisible(false);
        	menu.findItem(R.id.menu_unmute).setVisible(true);
        } else {
        	menu.findItem(R.id.menu_mute).setVisible(true);
        	menu.findItem(R.id.menu_unmute).setVisible(false);
        }*/
        return super.onPrepareOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
        case R.id.menu_set_channel:
            showDialog(DIALOG_SET_CHANNEL);
            return true;
        case R.id.menu_scan:
            if (mChannelHolder.getIsCancel())
                mChannelHolder.setIsCancel(false);
            createScanDialog();
            startServiceByAction(Constants.START_SCAN_ALL);
            return true;
        case R.id.menu_exit:
            disableFM();
            return true;
        case R.id.set_time:
            showDialog(DIALOG_SET_TIME);
            return true;
       /* case R.id.menu_mute:
        	startServiceByAction(Constants.SET_MUTE);
        	return true;
        case R.id.menu_unmute:
        	startServiceByAction(Constants.SET_UNMUTE);
        	return true;*/
        case R.id.configure:
        	/* Start the configuration window */
        	LogUtils.d(TAG, "startActivityForResult");
			Intent irds = new Intent(INTENT_RDS_CONFIG);
			startActivityForResult(irds, ACTIVITY_CONFIG);
        	break;	
     /*   case R.id.menu_trun_on_speaker:
        	enableSpeaker(true);
        	return true;
        case R.id.menu_trun_off_speaker:
        	enableSpeaker(false);
        	return true;*/
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
        case DIALOG_SET_CHANNEL:
            return createSetChannelDialog();
        case DIALOG_POWER_ON:
            return createPowerOnDialog();
        case DIALOG_POWER_OFF:
            return createPowerOffDialog();
        case DIALOG_SCAN:
            return createScanDialog();
        case DIALOG_SET_TIME:
            return createSetTimeDialog();
        }
        return null;
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		LogUtils.d(TAG, "onActivityResult  requestCode = " + requestCode + " resultCode = " + resultCode);
		if (ACTIVITY_CONFIG == requestCode) {
			if (resultCode == Activity.RESULT_OK) {
				LogUtils.d(TAG, "ActivityFmRdsConfig configurationState "
						+ configurationState);
			if(configurationState == CONFIGURATION_STATE_IDLE)
			{


					setRdsConfig();
					configPd = ProgressDialog.show(this, null,
							this.getString(R.string.reset_config), true, false);
							// The delay is inserted to make sure all the configurations
					// have been completed.
					insertDelayThread();
				}
			}

		}
    }
    
	/** Adds Delay of 3 seconds */
	private void insertDelayThread() {

		new Thread() {
			public void run() {
				try {
					// Add some delay to make sure all configuration has been
					// completed.
					sleep(3000);
				} catch (Exception e) {
					LogUtils.e(TAG, "InsertDelayThread()-- Exception !!");
				}
				// Dismiss the Dialog
				configPd.dismiss();
				configPd = null;
			}
		}.start();

	}
	private void setRdsConfig() {
		LogUtils.d(TAG, "setRdsConfig()");
		startServiceByAction(Constants.UPDATE_CONFIGURE);
		return;
	}

    private void setBtnEnable(){
        btnList.setEnabled(true);
        btnForward.setEnabled(true);
        btnRew.setEnabled(true);
    }

	@Override
	public void onBackPressed() {
		LogUtils.d(TAG, "onBackPressed ... ");
		moveTaskToBack(true);
		return;
	}
        
    private void setBtnDisable(){
        btnList.setEnabled(false);
        btnForward.setEnabled(false);
        btnRew.setEnabled(false);
    }

    private Dialog createScanDialog() {
        setBtnDisable();
        mScanDialog = new ProgressDialog(FMRadioActivity.this);
//        mScanDialog.setTitle(R.string.scan_title);
//        mScanDialog.setButton(FMRadioActivity.this.getString(R.string.cancel_scan), new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int which) {
//                createCancelScanDialog();
//                startServiceByAction(Constants.STOP_SCAN);
//                mChannelHolder.setIsCancel(true);
//            }
//        });
        mScanDialog.setMessage(FMRadioActivity.this.getString(R.string.scan_info));
        mScanDialog.setCancelable(true);
        mScanDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
			
			@Override
			public void onCancel(DialogInterface dialog) {
              createCancelScanDialog();
              startServiceByAction(Constants.STOP_SCAN);
              mChannelHolder.setIsCancel(true);
				
			}
		});
        mScanDialog.show();
        return mScanDialog;

    }

    private Dialog createSeekDialog() {
        setBtnDisable();
        mScanDialog = new ProgressDialog(FMRadioActivity.this);
        mScanDialog.setMessage(FMRadioActivity.this.getString(R.string.scan_info));
        mScanDialog.setCancelable(true);
        mScanDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
			
			@Override
			public void onCancel(DialogInterface dialog) {
              createCancelScanDialog();
              startServiceByAction(Constants.STOP_SEEK);
              mChannelHolder.setIsCancel(true);
              isClickSingleScanBtn = false;
              setBtnEnable();
				
			}
		});
        mScanDialog.show();
        return mScanDialog;

    }
    private void createCancelScanDialog(){
		if (null == cancelScanDialog) {
			cancelScanDialog = new ProgressDialog(FMRadioActivity.this);
			cancelScanDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			cancelScanDialog.setTitle(R.string.stop_scan_success);
			cancelScanDialog.setMessage(FMRadioActivity.this
					.getString(R.string.cancel_scanning));
			cancelScanDialog.setCancelable(false);
		}
        cancelScanDialog.show();
        mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_STOP_SCAN),5000);
    }        

    private Dialog createPowerOffDialog() {

        mPowerOffDialog = new ProgressDialog(FMRadioActivity.this);
        mPowerOffDialog.setTitle(R.string.dialog_radio_close);
        mPowerOffDialog.setMessage(FMRadioActivity.this.getString(R.string.dialog_radio_close));
        mPowerOffDialog.setCancelable(false);
        return mPowerOffDialog;
    }
    
    private Dialog createPowerOnDialog() {
        mPowerOnDialog = new ProgressDialog(FMRadioActivity.this);
        mPowerOnDialog.setTitle(R.string.dialog_radio_open);
        mPowerOnDialog.setMessage(FMRadioActivity.this.getString(R.string.dialog_radio_open));
        mPowerOnDialog.setCancelable(false);
        return mPowerOnDialog;
    }
    
    protected void onPrepareDialog(int id, Dialog dialog) {
        super.onPrepareDialog(id, dialog);
        final EditText et = (EditText)dialog.findViewById(R.id.channel);
        if (et != null && !TextUtils.isEmpty(et.getText().toString())) {
            et.setText("");
        }
    }
    
    private Dialog createSetChannelDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        View v = inflater.inflate(R.layout.dialog_set_channel, null);
        final EditText et = (EditText)v.findViewById(R.id.channel);
        alertDialog.setView(v);
        alertDialog.setTitle(R.string.dialog_set_channel);
        final Context context = this;
        alertDialog.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            
            public void onClick(DialogInterface dialog, int which) {
                boolean isPlugin = am.isWiredHeadsetOn();
                if (!isPlugin){
                    Toast.makeText(context, R.string.no_headset, Toast.LENGTH_LONG).show();
                    return;
                }
                String tem = et.getText().toString();
                double mTem;
                try {
                    mTem = Double.valueOf(tem);
                    if ((mTem * 1000 % 100) > 0) {
                        Toast.makeText(context, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                        return;
                    }
                    
                    SharedPreferences fmConfigPreferences  = getSharedPreferences("fmConfigPreferences",
            				MODE_PRIVATE); 
                    int bandFlag = fmConfigPreferences.getInt(Constants.BAND, 0);
                    int mIc = (int)(mTem * 1000);
                    
                    if(bandFlag == Constants.EUROPE_BAND) {
                    	if (mIc > Constants.EUROPE_MAX_FREQ || mIc < Constants.EUROPE_MIN_FREQ){
                            Toast.makeText(context, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                            return;
                        }
                    } else if(bandFlag == Constants.JAPAN_BAND) {
                    	if (mIc > Constants.JAPAN_MAX_FREQ || mIc < Constants.JAPAN_MIN_FREQ){
                            Toast.makeText(context, R.string.channel_wrong_value, Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                    
                    Intent intent = new Intent(context, FMService.class);
                    intent.setAction(Constants.SET_CHANNEL);
                    intent.putExtra("channel", mTem);
                    context.startService(intent);
                } catch (NumberFormatException e) {
                    Toast.makeText(context, R.string.channel_wrong_format, Toast.LENGTH_LONG).show();
                    return;
                }

                
            }
        });
        alertDialog.setNegativeButton(R.string.cancel, null);
        return alertDialog.create();
    }

    private Dialog createSetTimeDialog() {
    	int time = getTimeFromSharedPreferences();
    	int item = 0;
    	if (0 != time || time < 60) {
    		item = time /15;
    	}
    	LogUtils.d(TAG, "createSetTimeDialog time : " + time + ", item: " + item);
        return mSetTimeDialog = new AlertDialog.Builder(this)
               .setTitle(R.string.dialog_set_time)
               .setSingleChoiceItems(R.array.times, item, new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int whichButton) {
//                       mChannelHolder.setItem(whichButton);
                       int time = 15 * whichButton;
                       saveTimeToSharedPreferences(time);
                       Intent intent = new Intent(Constants.SET_TIME);
                       intent.putExtra("time", time);
                       FMRadioActivity.this.sendBroadcast(intent);
                       if (mSetTimeDialog != null && mSetTimeDialog.isShowing()) {
                           mSetTimeDialog.dismiss();
                       }
                   }
               }).create();
    }

	private void saveTimeToSharedPreferences(int time) {
		mSharedpreference = getSharedPreferences("fmConfigPreferences",MODE_PRIVATE);
		SharedPreferences.Editor editor = mSharedpreference.edit();
		editor.putInt("set_time", time);
		editor.commit();
	}
	private int getTimeFromSharedPreferences(){
		mSharedpreference = getSharedPreferences("fmConfigPreferences",MODE_PRIVATE);
		return mSharedpreference.getInt("set_time", 0);
	}
    private void createWaitDialog(){
    	pd = ProgressDialog.show(this, this.getString(R.string.pleasewait),
    			this.getString(R.string.enableRadio), true, false);
    }
    class ScrolGestureListener extends GestureDetector.SimpleOnGestureListener {
        
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
        {    
             if (e1 == null || e2 == null || vScale == null) {
                return true;
            }
            doTranslate((int)(-(lastX +e2.getX()-e1.getX())), vScale.getScrollY());
            return true;
        }
    }
    
    private void doTranslate(int x, int y) {
        vScale.scrollTo(x, 0);
    }
    
    private void doTranslateAnimation(float x1, float x2, float y1, float y2) {
        doTranslate((int)-(lastX + x2 - x1),0);
        lastX += x2 - x1;
    }
    class FMOnTouchListener implements OnTouchListener {
        public boolean onTouch(View v, MotionEvent event) {
            if (!isHeadsetOn) return true;
            if (mGestureDetector != null) {
                mGestureDetector.onTouchEvent(event);
            }
            int action = event.getAction();
            switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                break;
            case MotionEvent.ACTION_UP:
                endX = event.getX();
                float moveX = endX - startX;
                float target = caculateXFromFling(lastX + moveX);
                doTranslate((int)(-target),vScale.getScrollY());
                lastX = target;
                LogUtils.d(TAG,"lastX value = " + lastX);
                double channel = caculateXToChannel(lastX);
                LogUtils.d(TAG,"channel value = " + channel);
                Intent intent = new Intent(FMRadioActivity.this, FMService.class);
                intent.setAction(Constants.SET_CHANNEL);
                intent.putExtra("channel", channel/1000);
                FMRadioActivity.this.startService(intent);
                break;
            }
            return true;
        }
    }
    
    private float freqCaculateX() {
        int freq = mChannelHolder.getWorkFreq();
        float len = (freq - ((mBand ==0)?Constants.EUROPE_MIN_FREQ:Constants.JAPAN_MIN_FREQ))/100f;
        float currentX = (float) (MIN_CHANNEL-len * UNITDIP);
        return currentX;
    }
    
    private float caculateXFromFling(float x) {
        float value = x;
        if (x > MIN_CHANNEL) value = MIN_CHANNEL;
        if (x < MAX_CHANNEL) value = MAX_CHANNEL;
        int len = (int)(MIN_CHANNEL - value)/UNITDIP;
        float cur = (float)(MIN_CHANNEL - len * UNITDIP);
        return cur;
    }
    
    private int caculateXToChannel(float x) {
        float relateX = caculateXFromFling(x);
        int channel = (int) ((100 *(MIN_CHANNEL - relateX)/UNITDIP + Constants.EUROPE_MIN_FREQ));
        if (channel >= Constants.EUROPE_MAX_FREQ) {
            channel = Constants.EUROPE_MAX_FREQ;
        } else if (channel <= Constants.EUROPE_MIN_FREQ) {
            channel = Constants.EUROPE_MIN_FREQ;
        }
        return channel;
    }
    
    /*
     * DEMO for speaker
     * */
    private void enableSpeaker(boolean enable){
    	LogUtils.d(TAG,"enableSpeaker value = " + enable);
    	boolean isSpeakerOn = isFmSpeakerOn();
    	mChannelHolder.setSpeakerOn(enable);
    	if (enable) {
    		btnSpeaker.setImageResource(R.drawable.speaker_off);
    	} else {
    		btnSpeaker.setImageResource(R.drawable.speaker_on);
    	}
    	if (isSpeakerOn == enable)
    		return;
    	setFmSpeaker(enable);
    	
    }
    
    private void setFmSpeaker(boolean status){
		try {
			LogUtils.d(TAG, "setFmSpeaker: " + status);
			Method setSpeakerfmOn = am.getClass().getMethod("setSpeakerfmOn",
					boolean.class);
			setSpeakerfmOn.invoke(am, status);
		} catch (Exception e) {
			LogUtils.d(TAG, "Exception e: " + e);
		}
    }
    
    private boolean isFmSpeakerOn(){
    	boolean ret = false;
    	try {
			Method isSpeakerfmOn = am.getClass().getMethod("isSpeakerfmOn");
			ret = (Boolean)isSpeakerfmOn.invoke(am);
		} catch (Exception e) {
			LogUtils.d(TAG, "Exception e: " + e);
		}
    	return ret;
    }
    
    private void updateSoundView(int volumn){
    	if (volumn == 0){
    		soundView.setImageDrawable(mSoundDraws[0]);
    	} else if (volumn == 15){
    		soundView.setImageDrawable(mSoundDraws[8]);
    	} else {
			int volumn_value = (int) volumn / 2;
			LogUtils.d(TAG, "volumn_value  " + volumn_value);
			soundView.setImageDrawable(mSoundDraws[volumn_value + 1]);
    	}
    	
    }
    private void updateSignalView(int rssi){
    	if(rssi == 0){
    		signalView.setImageDrawable(mSignalDraws[0]);
    	} else if (rssi > 100) {
    		signalView.setImageDrawable(mSignalDraws[5]);
    	} else {
    		int signal_value = (int) rssi / 20;
			LogUtils.d(TAG, "volumn_value  " + signal_value);
			signalView.setImageDrawable(mSignalDraws[signal_value + 1]);
    	}
    }
    private void showErrorDialog(String errorInfo){
    	new AlertDialog.Builder(this).setTitle(R.string.app_name).setIcon(
				android.R.drawable.ic_dialog_alert).setMessage(errorInfo)
				.setNegativeButton(R.string.cancel,
						new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog,
							int which) {
						handleDisableFMResult();
					}
				}).setOnCancelListener(new OnCancelListener() {
			public void onCancel(DialogInterface dialog) {
				handleDisableFMResult();
			}
		}).show();
    }
}
