package com.borqs.fmradio;
/*
 *
 * Copyright 2001-2010 Texas Instruments, Inc. - http://www.ti.com/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



import java.lang.reflect.Method;
import java.util.ArrayList;

import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.service.FMService;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.ti.fm.FmRadio;
import com.ti.fm.FmRadioIntent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.widget.CompoundButton;

public class FmConfig extends Activity implements View.OnKeyListener,
		View.OnClickListener, CompoundButton.OnCheckedChangeListener
		 {

	public static final String TAG = "FmConfig";

	/********************************************
	 * Widgets
	 ********************************************/
	private Button btnCancel, btnOk;
	private Spinner spnBand, spnRdsSystem, spnChannelSpacing;
	private EditText textRssi;
	private CheckBox chbRdsMode;
	private CheckBox chbSetRdsAf;
	private ArrayAdapter<String> bandAdapter;
	private ArrayAdapter<String> channelSpaceAdapter;
	private ArrayAdapter<String> rdsSystemAdapter;
	private ArrayAdapter<String> modeAdapter;
	private ArrayAdapter<String> emptyAdapter;
	private ArrayList<String> channelSpaceString = new ArrayList<String>();

	private ArrayList<String> bandString = new ArrayList<String>();
	private ArrayList<String> rdsSystemStrings = new ArrayList<String>();
	private ArrayList<String> emptyStrings = new ArrayList<String>();
	private ArrayList<String> modeStrings = new ArrayList<String>();

	/********************************************
	 * private variables
	 ********************************************/
	private Context mContext;
	
	private AlertDialog mDialog = null;
	private ChannelHolder mChannelHolder = null;

	/********************************************
	 * public variables
	 ********************************************/
	public SharedPreferences fmConfigPreferences;
	
	private static final int EVENT_DISABLE_FM = 0;

	/** Called when the activity is first created. */

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		String language = systemProperties_get("persist.sys.language","en");
		if ("ar".equalsIgnoreCase(language)){
			setContentView(R.layout.fmconfig_ar);
		} else {			
			setContentView(R.layout.fmconfig);
		}
		
		mChannelHolder = ChannelHolder.getInstance();
		initControl();
		setSpinners();
		setRdsSystemSpinner();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_HEADSET_PLUG);
        filter.addAction(FmRadioIntent.FM_DISABLED_ACTION);
        registerReceiver(mReceiver,filter);
        mChannelHolder.setIsForegroundActivity(true);

	}

	
    BroadcastReceiver mReceiver = new BroadcastReceiver(){

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if (Intent.ACTION_HEADSET_PLUG.equals(intent.getAction())) {
				int state = intent.getIntExtra("state", 0);
				if (state != 0) {
					if (null != mDialog) {
						mDialog.dismiss();
					}
				} else {
					mDialog = new AlertDialog.Builder(FmConfig.this)
					.setTitle(R.string.no_headset)
					.setIcon(R.drawable.art_dialog_notice)
					.setMessage(R.string.no_headset)
					.setNegativeButton(R.string.cancel,
							new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog,
								int which) {
							// TODO Auto-generated method stub
							noHeadsetDisableFM();
						}
					}).setOnCancelListener(new OnCancelListener() {
						public void onCancel(DialogInterface dialog) {
							noHeadsetDisableFM();
						}
					}).show();
				}
			} else if (FmRadioIntent.FM_DISABLED_ACTION.equals(intent.getAction())){
			     Message result = Message.obtain(mHandler,EVENT_DISABLE_FM);
				 mHandler.sendMessageDelayed(result, 2000);
			} else {
				if (null != mDialog) {
					mDialog.dismiss();
				}
			}
			
		}
    	
    };
    
	private void noHeadsetDisableFM() {
		if (FMService.sFmRadio.rxGetFMState() == FmRadio.STATE_ENABLED){
			Intent intent = new Intent(this, FMService.class);
			intent.setAction(Constants.DISABLE_FM);
			this.startService(intent);
			if (mChannelHolder.getSpeakerOn()) {
				setFmSpeaker(false);
			}
		} else {
			if (null == mChannelHolder) {
				mChannelHolder = ChannelHolder.getInstance();
			}
			
			mChannelHolder.setIsAudioFocus(false);
			FMService.getHandler().sendMessage(Message.obtain(FMService.getHandler(), Constants.MSG_FINISH_ACTIVITY));
			Intent intent = new Intent(this, FMService.class);
			this.stopService(intent);
			mChannelHolder.flush();
		}
	     Message result = Message.obtain(mHandler,EVENT_DISABLE_FM);
		 mHandler.sendMessageDelayed(result, 2000);
	    LogUtils.d(TAG,"ChannelListActivity noHeadsetDisableFM...");
	}
	
	
	Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case EVENT_DISABLE_FM:
				finish();
				break;
			}
		}
	};
	private void setFmSpeaker(boolean status) {
		try {
			LogUtils.d(TAG, "setFmSpeaker: " + status);
			AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
			Method setSpeakerfmOn = am.getClass().getMethod("setSpeakerfmOn",
					boolean.class);
			setSpeakerfmOn.invoke(am, status);
		} catch (Exception e) {
			LogUtils.d(TAG, "Exception e: " + e);
		}
	}
	/** Initialise the Widget controls of the Activity */
	private void initControl() {
		btnCancel = (Button) findViewById(R.id.btnCancel);
		btnCancel.setOnKeyListener(this);
		btnCancel.setOnClickListener(this);

		btnOk = (Button) findViewById(R.id.btnOk);
		btnOk.setOnKeyListener(this);
		btnOk.setOnClickListener(this);

		spnRdsSystem = (Spinner) findViewById(R.id.spnRdsSystem);
		spnBand = (Spinner) findViewById(R.id.spnBand);

		spnChannelSpacing = (Spinner) findViewById(R.id.spnChannelSpace);

		textRssi = (EditText) findViewById(R.id.Rssi);

		chbRdsMode = (CheckBox) findViewById(R.id.chbRdsmode);
		chbRdsMode.setOnCheckedChangeListener(this);

		chbSetRdsAf = (CheckBox) findViewById(R.id.chbSetRdsAf);
		chbSetRdsAf.setOnCheckedChangeListener(this);
	}

	/**
	 * sets the Band , De-Emp Filter and Mode option selections Spinner for the
	 * User
	 */
	private void setSpinners() {
		// BAnd Spinner
		bandAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, bandString);

		bandAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnBand.setAdapter(bandAdapter);
		String str_Eurp = getResources().getText(R.string.band_European).toString();
		String str_Japan = getResources().getText(R.string.band_Japanese).toString();
		bandAdapter.add(str_Eurp);
		bandAdapter.add(str_Japan);
		spnBand.setOnItemSelectedListener(gItemSelectedHandler);

		// ChannelSpace Spinner
		channelSpaceAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, channelSpaceString);

		channelSpaceAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnChannelSpacing.setAdapter(channelSpaceAdapter);
		channelSpaceAdapter.add("50 KHZ");
		channelSpaceAdapter.add("100 KHZ");
		channelSpaceAdapter.add("200 KHZ");
		spnChannelSpacing.setOnItemSelectedListener(gItemSelectedHandler);

		// Mode(Mono/Stereo) Spinner
		modeAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, modeStrings);

		modeAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

	}

	/** spinner to select Rds System option */
	private void setRdsSystemSpinner() {

		rdsSystemAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, rdsSystemStrings);

		rdsSystemAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnRdsSystem.setAdapter(rdsSystemAdapter);
		rdsSystemAdapter.clear();
		rdsSystemAdapter.add("RDS");
		rdsSystemAdapter.add("RBDS");
		spnRdsSystem.setOnItemSelectedListener(gItemSelectedHandler);

	}

	/** Spinner with no options */
	private void setEmptySpinner() {
		emptyAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, emptyStrings);

		emptyAdapter
				.setDropDownViewResource(android.R.layout.select_dialog_item);
		spnRdsSystem.setAdapter(emptyAdapter);
		emptyAdapter.clear();
		String disabled = getResources().getText(R.string.disable_rds).toString();
		emptyAdapter.add(disabled);
		spnRdsSystem.setOnItemSelectedListener(gItemSelectedHandler);

	}

	public OnItemSelectedListener gItemSelectedHandler = new OnItemSelectedListener() {
		public void onItemSelected(AdapterView<?> arg0, View view, int arg2,
				long arg3) {

		}

		public void onNothingSelected(AdapterView<?> arg0) {
		}

	};

	/** Pops up the alert Dialog */
	public void showAlert(Context context, String title, String msg) {

		new AlertDialog.Builder(context).setTitle(title).setIcon(
				android.R.drawable.ic_dialog_alert).setMessage(msg)
				.setNegativeButton(android.R.string.ok, null).show();

	}

	public void onClick(View view) {
		LogUtils.i(TAG, "onClick()");
		int id = view.getId();
		switch (id) {
		case R.id.btnCancel:
			finish();
			break;
		case R.id.btnOk:
			AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
			boolean isHeadsetOn = am.isWiredHeadsetOn();
			LogUtils.d(TAG,"scanAllChannel isHeadsetOn " + isHeadsetOn);
			if (!isHeadsetOn)
				return;
			if (FMRadioActivity.isAirplaneMode(getApplicationContext())) {
				return;
			} 
			savePrefernces();
			break;

		default:
			break;
		}
	}

	/** Send the Intent to Parent Activity */
	private void sendRdsIntent() {

		LogUtils.i(TAG, "sendRdsIntent()");
		Intent rdsIntent = new Intent();
		setResult(RESULT_OK, rdsIntent);
		finish();

	}

	public void onCheckedChanged(CompoundButton view, boolean isChecked) {
		LogUtils.i(TAG, "onCheckedChanged()");
		int id = view.getId();
		switch (id) {
		case R.id.chbSetRdsAf:
			break;

		case R.id.chbRdsmode:

			if (isChecked) {
				chbSetRdsAf.setEnabled(true);
				setRdsSystemSpinner();
			} else {
				chbSetRdsAf.setChecked(false);
				chbSetRdsAf.setEnabled(false);
				setEmptySpinner();
			}
			break;

		default:
			break;
		}

	}

	public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
		int action = keyEvent.getAction();

		if (keyCode == KeyEvent.KEYCODE_SOFT_RIGHT) {
			LogUtils.d(TAG, "KEYCODE_SOFT_RIGHT ");
			finish();
			return true;
		}

		if (keyCode == KeyEvent.KEYCODE_SOFT_LEFT) {
			LogUtils.d(TAG, "KEYCODE_SOFT_LEFT ");
			savePrefernces();
			// finish();
			return true;
		}

		if (keyCode != KeyEvent.KEYCODE_DPAD_CENTER
				&& keyCode != KeyEvent.KEYCODE_DPAD_UP
				&& keyCode != KeyEvent.KEYCODE_DPAD_DOWN
				&& keyCode != KeyEvent.KEYCODE_ENTER) {
			return false;
		}

		if (action == KeyEvent.ACTION_UP) {
			switch (keyCode) {
			case KeyEvent.KEYCODE_ENTER:
			case KeyEvent.KEYCODE_DPAD_CENTER:

				break;

			case KeyEvent.KEYCODE_DPAD_UP:

				break;

			case KeyEvent.KEYCODE_DPAD_DOWN:

				break;
			}
		}
		return true;
	}

	public void onResume() {
		super.onResume();
		LogUtils.i(TAG, "onResume()-Entered");
		if(!mChannelHolder.getIsForegroundActivity()){
	       	 mChannelHolder.setIsForegroundActivity(true);
	       }
		updateUiFromPreference();
	}

	public void onPause() {
		super.onPause();
		if(mChannelHolder.getIsForegroundActivity()){
	       	 mChannelHolder.setIsForegroundActivity(false);
	       }
		LogUtils.i(TAG, "onPause()-Entered");

	}

	public void onStop() {
		LogUtils.i(TAG, "onStop()-Entered");
		super.onStop();
	}

	public void onRestart() {
		LogUtils.i(TAG, "onRestart()-Entered");
		super.onRestart();

	}
	
	public void onDestroy() {
		LogUtils.i(TAG, "onDestroy-Entered");
		super.onDestroy();
		unregisterReceiver(mReceiver);
		if (null != mDialog) {
			mDialog.dismiss();
		}
		mChannelHolder = null;
	}

	/** Updates the UI with Default/last saved values */
	private void updateUiFromPreference() {
		fmConfigPreferences = getSharedPreferences("fmConfigPreferences",
				MODE_PRIVATE);
		LogUtils.i(TAG, "updateUiFromPreference()");

		chbRdsMode.setChecked(fmConfigPreferences.getBoolean(Constants.RDS, Constants.DEFAULT_RDS));
		boolean rdsON = fmConfigPreferences.getBoolean(Constants.RDS, Constants.DEFAULT_RDS);

		if (!rdsON) // Rds is Disabled
		{
			chbSetRdsAf.setChecked(false); // When the RDS is Disabled uncheck
			// Rds Af checkbox
			chbSetRdsAf.setEnabled(false); // When the RDS is Disabled disable
			// Rds Af checkbox
			setEmptySpinner(); // When the RDS is Disabled, disable RDS System
			// spinner
		} else// Rds Is Enable
		{
			chbSetRdsAf.setChecked(fmConfigPreferences.getBoolean(Constants.RDSAF,
					Constants.DEFAULT_RDS_AF));
			spnRdsSystem.setSelection(fmConfigPreferences.getInt(Constants.RDSSYSTEM,
					Constants.DEFAULT_RDS_SYSTEM));
		}

		textRssi.setText(fmConfigPreferences.getString(Constants.RSSI_STRING,
				Constants.DEF_RSSI_STRING));

		spnBand.setSelection(fmConfigPreferences.getInt(Constants.BAND, Constants.DEFAULT_BAND));

		int pos = 1;
		switch (fmConfigPreferences.getInt(Constants.CHANNELSPACE, Constants.DEFAULT_CHANNELSPACE)) {

		case 1:
			pos = 0;
			break;

		case 2:
			pos = 1;
			break;

		case 4:
			pos = 2;
			break;

		}
		spnChannelSpacing.setSelection(pos);

	}

	/** Saves Configuration settings in the Shared Preference */
	private void savePrefernces() {
		LogUtils.i(TAG, "savePrefernces()");

		int mChannelSpacePos = 2;

		fmConfigPreferences = getSharedPreferences("fmConfigPreferences",
				MODE_PRIVATE);

		SharedPreferences.Editor editor = fmConfigPreferences.edit();

		if (chbRdsMode.isChecked()) {
			editor.putBoolean(Constants.RDSAF, chbSetRdsAf.isChecked());
			editor.putBoolean(Constants.RDS, chbRdsMode.isChecked());
			editor.putInt(Constants.RDSSYSTEM, spnRdsSystem.getSelectedItemPosition());
		} else {
			editor.putBoolean(Constants.RDSAF, Constants.DEFAULT_RDS_AF);
			editor.putBoolean(Constants.RDS, chbRdsMode.isChecked());
			editor.putInt(Constants.RDSSYSTEM, Constants.DEFAULT_RDS_SYSTEM);
		}

		editor.putInt(Constants.BAND, spnBand.getSelectedItemPosition());

		switch (spnChannelSpacing.getSelectedItemPosition()) {
		case 0:
			mChannelSpacePos = 1;
			break;

		case 1:
			mChannelSpacePos = 2;
			break;

		case 2:
			mChannelSpacePos = 4;
			break;
		}

		editor.putInt(Constants.CHANNELSPACE, mChannelSpacePos);

		try {
			int rssiValue = Integer.parseInt(textRssi.getText().toString());
			boolean valid = rssiValid(rssiValue);
			if (valid || (textRssi.getText().toString() == null)) {
				editor.putString(Constants.RSSI_STRING, textRssi.getText().toString());
				if (textRssi.getText().toString() == null)
					editor.putInt(Constants.RSSI, Constants.DEFAULT_RSSI);
				else {
					editor.putInt(Constants.RSSI, rssiValue);
				}
				editor.commit();
				sendRdsIntent();
			} else {
				new AlertDialog.Builder(this).setIcon(
						android.R.drawable.ic_dialog_alert).setMessage(
						getString(R.string.rssi_value))
						.setNegativeButton(android.R.string.ok, null).show();
				textRssi.setText(null);
			}
		} catch (NumberFormatException nfe) {
			LogUtils.d(TAG, "NumberFormatException:" + nfe.getMessage());
			new AlertDialog.Builder(this).setIcon(
					android.R.drawable.ic_dialog_alert).setMessage(
							getString(R.string.rssi_value))
					.setNegativeButton(android.R.string.ok, null).show();
			textRssi.setText(null);
		}

	}

	/** Checks the RSSI value for validity */
	private boolean rssiValid(int value) {
		LogUtils.d(TAG, "rssiValid %d." + value);
		if (value < Constants.RSSI_MIN || value > Constants.RSSI_MAX) {
			LogUtils.d(TAG, "TAG,rssiValid %d." + value);

			return false;
		} else
			return true;

	}
    public static String systemProperties_get(String key, String defValue) {
    	String ret = defValue;
    	try {
	    	Class<?> c = Class.forName("android.os.SystemProperties");
	    	Method method = c.getMethod("get", String.class, String.class);
	    	ret = (String)method.invoke(null, key, defValue);
    	} catch (Exception ex) {
    		LogUtils.d(TAG,"systemProperties_get, " + ex);
    	}
    	return ret;
    }
	
}
