/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.service;

import java.lang.reflect.Method;
import java.util.List;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.borqs.fmradio.FMRadioActivity;
import com.borqs.fmradio.R;
import com.borqs.fmradio.model.ChannelHolder;
import com.borqs.fmradio.model.Station;
import com.borqs.fmradio.util.Constants;
import com.borqs.fmradio.util.LogUtils;
import com.ti.fm.FmRadio;
import com.ti.fm.FmRadioIntent;
import com.ti.fm.IFmConstants;

/*TI FMradio start up process:
 * sFmRadio.rxEnable()
 * Once  the callback for sFmRadio.rxEnable() is received (EVENT_FM_ENABLED),
 * sFmRadio.rxEnableAudioHAL() will be called
 *  Once the callback for  sFmRadio.rxEnableAudioHAL() is received(EVENT_VOLUME_CHANGE),
 *	sFmRadio.rxSetBand() with default band will be called.
 *	Once the callback for  sFmRadio.rxSetBand() is received(EVENT_BAND_CHANGE),
 *  sFmRadio.rxTune_nb will be called
 * 
 * 
 * */
public class FMService extends Service implements
				IFmConstants, FmRadio.ServiceListener{
    
    private static final String TAG = FMService.class.getSimpleName();
    private static final int FM_NOTIFICATION_ID = 1;
    private static final String FM_LOCK_TAG = "FMService";
    private static final int VOLUME_STATUS_NORMAL = 0;
    private static final int VOLUME_STATUS_ZERO = 1;
    private static int volumeStatus = VOLUME_STATUS_NORMAL;
    private static boolean status = false;
    
    private static Handler mHandler = null;
    
    private ChannelHolder mChannelHolder= null;
    boolean isHeadsetOn;
//    private FMHeadsetObserver mHeadsetObserver = null;
    private boolean isNotifyEnable = false;
    private boolean isDisableNotify = false;
    private boolean isDummy = false;
    private AudioManager am = null;
    private AlarmManager mAlarmManager = null;
    private PendingIntent mFinishIntent = null;
//    private FMCallback mCallback = null;
    private boolean isStopScan = false;
    private boolean isDisable = false;
    private boolean isRestartFM = false;
    
    public static FmRadio sFmRadio;
	/*Flag to check if service is connected*/
	boolean mFmServiceConnected = false;
	private boolean mStatus;
	// variable to make sure that the next seek happens after the current seek
	// request has been completed.
	private boolean mSeekState = Constants.SEEK_REQ_STATE_IDLE;
    private boolean sdefaultSettingOn = false;
	public static int sBand = Constants.DEFAULT_BAND;
	private int mMode = Constants.DEFAULT_MODE;
	public static int sChannelSpace = Constants.DEFAULT_CHANNELSPACE;
	private boolean mRds = Constants.DEFAULT_RDS;
	public static int mRdsSystem = Constants.INITIAL_VAL;
	private boolean mRdsAf = Constants.DEFAULT_RDS_AF;
	private int mRssi = Constants.INITIAL_RSSI;
    private boolean mRdsState = true;

    private static final int BT_ENABLED = 1;
    private static final int BT_DISABLED = 0;
	private boolean isBTStateChangedSuccess = false;
    public static enum scanState {SCANNING,SCAN_FINISHED};
	public static scanState mScanState = scanState.SCAN_FINISHED;
	
	public static Float lastTunedFrequency = (float) Constants.DEFAULT_FREQ_EUROPE;
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) {
                return;
            }
            if (null == mHandler){
            	 LogUtils.d(TAG, "enter onReceive mHandler is null ,reutrn");
            	 return;
            }
            	
            String action = intent.getAction();
            LogUtils.d(TAG, "enter onReceive" + action);
            if (Constants.ADD_CHANNEL_FROM_CALLBACK.equals(action)) {
                LogUtils.d(TAG,"onFound channel,add channel from callback to channelHolder");
                addChannelFromCallback(intent);
            }  else if(Constants.HEADSET_PLUG_FAST.equals(action)){
                LogUtils.d(TAG,"ACTION_HEADSET_PLUG#state : " + intent.getIntExtra("state", 0));
                int state = intent.getIntExtra("state", 0);
//                if (state == 0) return;
                handleHeadsetState(state);
            } else if (Constants.FM_HEADSET_STATE_CHANGED.equals(action)) {
                int state = intent.getIntExtra("state", 0);
                handleHeadsetState(state);
            } else if (Constants.SET_TIME.equals(action)) {
                int time = intent.getIntExtra("time",0);
                LogUtils.d(TAG, "on receive set time is: " + time);
                mAlarmManager.cancel(mFinishIntent);
                if (time ==0) {
                    return;
                }
                long triggerTime = System.currentTimeMillis() + time * 60 * 1000;
                LogUtils.d(TAG, "AlarmManager..........");
                mAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, mFinishIntent);
            } else if (Constants.FINISH_FM.equals(action)) {
            	LogUtils.d(TAG, "finish FM..");
                isDisableNotify = true;
                disable();
            } else if (Constants.PRESS_VOLUMEKEY_ENABLE_FM.equals(action)) {
                if (volumeStatus == VOLUME_STATUS_ZERO && !status) {
                    enableFMRadio();
                    int volumeValue = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                    LogUtils.d(TAG,"current volume is "+ volumeValue);
                    if (volumeValue == 0) {
                       am.setStreamVolume(AudioManager.STREAM_MUSIC,1,0);
                    }
                    volumeStatus = VOLUME_STATUS_NORMAL;
                }

			} else if (Constants.MUSIC_SERVICE_COMMAND.equals(action)){
				String command = intent.getStringExtra("command");
				LogUtils.d(TAG, "music service command: " + command);
				if ("pause".equals(command)) {
		            isDisableNotify = true;
					disable();
				}
			} else if (Intent.ACTION_SHUTDOWN.equals(action)){
				//when user power off phone and exit FM abnormally,
				//we save user data to xml file.
				if (null != mChannelHolder){
					mChannelHolder.flush();
				}
			}
            
            if (action.equals(FmRadioIntent.FM_ENABLED_ACTION)) {
				LogUtils.d(TAG, "enter onReceive FM_ENABLED_ACTION isHeadsetOn = " + isHeadsetOn);
				if (isHeadsetOn){
					enableAudio(true);
					loadDefaultConfiguration();
				}
            }
            if (action.equals(FmRadioIntent.FM_DISABLED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive FM_DISABLED_ACTION " + action);
                sdefaultSettingOn = false;
                enableAudio(false);
                
                if (!FMRadioActivity.isClickPowerBtn ){
                	showFinishNotification();
                	if (mChannelHolder.getIsForegroundActivity())
                	    mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DISABLE_SUCCESSFUL), 1500);
                	else
                		mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DISABLE_SUCCESSFUL), 0);
                	
                } else
                	mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DISABLE_SUCCESSFUL), 0);
            }

            if (action.equals(FmRadioIntent.SET_MODE_MONO_STEREO_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_MODE_MONO_STEREO_ACTION " + action);
                
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_MONO_STEREO_CHANGE, 0));
            }
            if (action.equals(FmRadioIntent.DISPLAY_MODE_MONO_STEREO_ACTION)) {
            	int modeDisplay = intent.getIntExtra(FmRadioIntent.MODE_MONO_STEREO, 0);
                LogUtils.d(TAG, "onMonoStereoChanged#monoStero:" + modeDisplay);
                Intent sIntent = new Intent(Constants.STEREO_CHANGED);
                sIntent.putExtra("stereo", modeDisplay);
                sendBroadcast(sIntent);
//                Integer modeDisplay = intent.getIntExtra(FmRadioIntent.MODE_MONO_STEREO, 0);
//                LogUtils.d(TAG, "enter onReceive DISPLAY_MODE_MONO_STEREO_ACTION  modeDisplay " + modeDisplay);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_MONO_STEREO_DISPLAY, modeDisplay));
            }

            if (action.equals(FmRadioIntent.RDS_TEXT_CHANGED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive RDS_TEXT_CHANGED_ACTION " + action);
                if (FM_SEND_RDS_IN_BYTEARRAY == true) {
                    Bundle extras = intent.getExtras();

                    byte[] rdsText = extras.getByteArray(FmRadioIntent.RDS);
                    int status = extras.getInt(FmRadioIntent.STATUS, 0);
                    LogUtils.d(TAG, "RDS_TEXT_CHANGED_ACTION rdsName = " + rdsText.toString());   
                    Intent sIntent = new Intent(Constants.RT_CHANGED);
                    sIntent.putExtra("rt", rdsText.toString());
                    sendBroadcast(sIntent);
                    mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_RDS_TEXT, status, 0, rdsText));
                } else {
                    String rdstext = intent.getStringExtra(FmRadioIntent.RADIOTEXT_CONVERTED);
                    LogUtils.d(TAG, "RDS_TEXT_CHANGED_ACTION rdsName = " + rdstext);   
                    Intent sIntent = new Intent(Constants.RT_CHANGED);
                    sIntent.putExtra("rt", rdstext);
                    sendBroadcast(sIntent);
                    mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_RDS_TEXT, rdstext));
                }
            }
            if (action.equals(FmRadioIntent.PI_CODE_CHANGED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive PI_CODE_CHANGED_ACTION " + action);

                Integer pi = intent.getIntExtra(FmRadioIntent.PI, 0);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_PI_CODE, pi.toString()));
            }

            if (action.equals(FmRadioIntent.PTY_CODE_CHANGED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive PTY_CODE_CHANGED_ACTION " + action);

                Integer pty = intent.getIntExtra(FmRadioIntent.PTY, 0);

                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_PTY_CODE, pty.toString()));
            }

            if (action.equals(FmRadioIntent.TUNE_COMPLETE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive TUNE_COMPLETE_ACTION " + action);

                int tuneFreq = intent.getIntExtra(FmRadioIntent.TUNED_FREQUENCY, 0);

                LogUtils.d(TAG, "enter handleMessage ----EVENT_TUNE_COMPLETE");
				LogUtils.d(TAG, "enter handleMessage ----EVENT_TUNE_COMPLETE tuneFreq" + tuneFreq);
				lastTunedFrequency = (float) tuneFreq / 1000;
				mChannelHolder.setWorkFreq(tuneFreq);
				if (mRdsState) {
					mStatus = sFmRadio.rxEnableRds_nb();
					if (mStatus == false) {
						LogUtils.e(TAG, "setRDS()-- enableRds() ->Erorr");
						showAlert(FMService.this, "FmRadio","Cannot enable RDS.", false);
					}
					mStatus = sFmRadio.rxSetRdsAfSwitchMode_nb(mRdsAf ? 1 : 0);
					if (mStatus == false) {
						showAlert(FMService.this, "FmRadio","Cannot set RDS AF Mode ON.", false);
					}
					mStatus = sFmRadio.rxSetRssiThreshold_nb(mRssi);
					if (mStatus == false) {
						showAlert(FMService.this, "FmRadio","Not able to setRssiThreshold.", false);
					}
				}
				if (sdefaultSettingOn == false) {
					mStatus = sFmRadio.rxEnableAudioRouting();
					if (mStatus == false) {
						showAlert(FMService.this, "FmRadio", "Not able to enable audio.", false);
					}
					if (mRdsState) {
						mStatus = sFmRadio.rxEnableRds_nb();
						if (mStatus == false) {
							LogUtils.e(TAG, "setRDS()-- enableRds() ->Erorr");
							showAlert(FMService.this, "FmRadio", "Cannot enable RDS.", false);
						}
					}
	//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_TUNE_COMPLETE, tuneFreq));
					enable(true);
					sdefaultSettingOn = true;
				}
				sFmRadio.rxGetMonoStereoMode_nb();
	            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_CHANNEL));
	            sFmRadio.rxGetRssi_nb();
            }

            if (action.equals(FmRadioIntent.COMPLETE_SCAN_PROGRESS_ACTION)) {
                LogUtils.d(TAG, "enter onReceive COMPLETE_SCAN_PROGRESS_ACTION " + action);

                int progress = intent.getIntExtra(FmRadioIntent.SCAN_PROGRESS, 0);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_COMPLETE_SCAN_PROGRESS, progress));

            }

            if (action.equals(FmRadioIntent.VOLUME_CHANGED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive VOLUME_CHANGED_ACTION " + action);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_VOLUME_CHANGE, 0));
                if (sdefaultSettingOn == false) {
					mStatus = sFmRadio.rxSetBand_nb(sBand);
					if (mStatus == false) {
						showAlert(FMService.this, "FmRadio", "Not able to setband.", false);
					}
                }
//                getMute();
            }

            if (action.equals(FmRadioIntent.MUTE_CHANGE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive MUTE_CHANGE_ACTION " + action);
                Bundle extras = intent.getExtras();
                int status = extras.getInt(FmRadioIntent.STATUS, 0);
                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_MUTE_CHANGE, status));
            }

            if (action.equals(FmRadioIntent.SEEK_STOP_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SEEK_STOP_ACTION " + action);

                long freq = intent.getLongExtra(FmRadioIntent.SEEK_FREQUENCY, 0);
                LogUtils.d(TAG, "SEEK_STOP_ACTION freq = " + freq);
                mChannelHolder.setWorkFreq((int)freq);
                setChannel((int)freq);
                sentScanStopIntent();
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SEEK_STOPPED, freq));
            }

            if (action.equals(FmRadioIntent.SEEK_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SEEK_ACTION " + action);

                int freq = intent.getIntExtra(FmRadioIntent.SEEK_FREQUENCY, 0);
                LogUtils.d(TAG, "enter handleMessage ----EVENT_SEEK_STARTED freq" + freq);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SEEK_STARTED, freq));
                lastTunedFrequency = (float) freq / 1000;
                mChannelHolder.setWorkFreq(freq);
                FMService.mScanState = scanState.SCAN_FINISHED;
                mSeekState = Constants.SEEK_REQ_STATE_IDLE;
                LogUtils.d(TAG,"onScanFinished#workfreq : " + mChannelHolder.getWorkFreq());
                Intent sIntent = new Intent();
                sIntent.setAction(Constants.SCAN_FINISH);
                FMService.this.sendBroadcast(sIntent);
                sFmRadio.rxGetRssi_nb();
            }

            if (action.equals(FmRadioIntent.BAND_CHANGE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive BAND_CHANGE_ACTION " + action);

                if (sdefaultSettingOn == true) {
                	lastTunedFrequency = (sBand == FM_BAND_EUROPE_US) ?
							(float) Constants.DEFAULT_FREQ_EUROPE : (float) Constants.DEFAULT_FREQ_JAPAN;
                	mChannelHolder.setWorkFreq((int)(lastTunedFrequency * 1000));
                }
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_BAND_CHANGE, 0));
                int wFreq = mChannelHolder.getWorkFreq();
                if (sBand == FM_BAND_EUROPE_US){
                	wFreq = parseEuropeFreq(wFreq);
                } else {
                	wFreq = parseJapanFreq(wFreq);
                }
                mStatus = sFmRadio.rxTune_nb(wFreq);
				if (mStatus == false) {
					showAlert(FMService.this, "FmRadio", "Not able to tune.", false);
				}
            }

            if (action.equals(FmRadioIntent.GET_CHANNEL_SPACE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_CHANNEL_SPACE_ACTION " + action);

                Long chSpace = intent.getLongExtra(FmRadioIntent.GET_CHANNEL_SPACE, 0);
//                mHandler.sendMessage(mHandler
//                        .obtainMessage(Constants.EVENT_GET_CHANNEL_SPACE_CHANGE, chSpace));
            }

            if (action.equals(FmRadioIntent.SET_CHANNEL_SPACE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_CHANNEL_SPACE_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_CHANNELSPACE, 0));
            }

            if (action.equals(FmRadioIntent.GET_RDS_AF_SWITCH_MODE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_RDS_AF_SWITCH_MODE_ACTION " + action);

                Long switchMode = intent.getLongExtra(FmRadioIntent.GET_RDS_AF_SWITCHMODE, 0);
//                mHandler.sendMessage(mHandler
//                        .obtainMessage(Constants.EVENT_GET_RDS_AF_SWITCHMODE, switchMode));
            }

            if (action.equals(FmRadioIntent.GET_VOLUME_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_VOLUME_ACTION " + action);

                Long gVolume = intent.getLongExtra(FmRadioIntent.GET_VOLUME, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_VOLUME, gVolume));
            }

            if (action.equals(FmRadioIntent.GET_MONO_STEREO_MODE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_MONO_STEREO_MODE_ACTION " + action);

                int gMode = (int)intent.getLongExtra(FmRadioIntent.GET_MODE, 0);
                LogUtils.d(TAG, "onMonoStereoChanged#monoStero:" + gMode);
                Intent sIntent = new Intent(Constants.STEREO_CHANGED);
                sIntent.putExtra("stereo", gMode);
                sendBroadcast(sIntent);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_MODE, gMode));
            }

            if (action.equals(FmRadioIntent.GET_MUTE_MODE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_MUTE_MODE_ACTION " + action);

                int gMuteMode = (int)intent.getLongExtra(FmRadioIntent.GET_MUTE_MODE, 1);
                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_MUTE_MODE, gMuteMode));
            }

            if (action.equals(FmRadioIntent.GET_BAND_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_BAND_ACTION " + action);

                Long gBand = intent.getLongExtra(FmRadioIntent.GET_BAND, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_BAND, gBand));
            }

            if (action.equals(FmRadioIntent.GET_FREQUENCY_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_FREQUENCY_ACTION " + action);

                int gFreq = intent.getIntExtra(FmRadioIntent.TUNED_FREQUENCY, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_FREQUENCY, gFreq));
            }

            if (action.equals(FmRadioIntent.GET_RF_MUTE_MODE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_RF_MUTE_MODE_ACTION " + action);

                Long gRfMuteMode = intent.getLongExtra(FmRadioIntent.GET_RF_MUTE_MODE, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_RF_MUTE_MODE, gRfMuteMode));
            }

            if (action.equals(FmRadioIntent.GET_RSSI_THRESHHOLD_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_RSSI_THRESHHOLD_ACTION " + action);

                Long gRssiThreshhold = intent.getLongExtra(FmRadioIntent.GET_RSSI_THRESHHOLD, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_RSSI_THRESHHOLD,
//                        gRssiThreshhold));
            }

            if (action.equals(FmRadioIntent.GET_DEEMPHASIS_FILTER_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_DEEMPHASIS_FILTER_ACTION " + action);

                Long gFilter = intent.getLongExtra(FmRadioIntent.GET_DEEMPHASIS_FILTER, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_DEEMPHASIS_FILTER, gFilter));
            }

            if (action.equals(FmRadioIntent.GET_RSSI_ACTION)) {

                int gRssi = intent.getIntExtra(FmRadioIntent.GET_RSSI, 0);
                LogUtils.d(TAG, "enter onReceive GET_RSSI_ACTION  gRssi =" + gRssi);
                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_RSSI, gRssi));
            }

            if (action.equals(FmRadioIntent.GET_RDS_SYSTEM_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_RDS_SYSTEM_ACTION " + action);

                Long gRdsSystem = intent.getLongExtra(FmRadioIntent.GET_RDS_SYSTEM, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_RDS_SYSTEM, gRdsSystem));
            }

            if (action.equals(FmRadioIntent.GET_RDS_GROUPMASK_ACTION)) {
                LogUtils.d(TAG, "enter onReceive GET_RDS_GROUPMASK_ACTION " + action);

                Long gRdsMask = intent.getLongExtra(FmRadioIntent.GET_RDS_GROUPMASK, 0);
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_GET_RDS_GROUPMASK, gRdsMask));
            }

            if (action.equals(FmRadioIntent.ENABLE_RDS_ACTION)) {
                LogUtils.d(TAG, "enter onReceive ENABLE_RDS_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_ENABLE_RDS, 0));
            }

            if (action.equals(FmRadioIntent.DISABLE_RDS_ACTION)) {
                LogUtils.d(TAG, "enter onReceive DISABLE_RDS_ACTION " + action);

                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_DISABLE_RDS, 0));
            }

            if (action.equals(FmRadioIntent.SET_RDS_AF_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_RDS_AF_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_RDS_AF, 0));
            }

            if (action.equals(FmRadioIntent.SET_RDS_SYSTEM_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_RDS_SYSTEM_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_RDS_SYSTEM, 0));
            }

            if (action.equals(FmRadioIntent.SET_DEEMP_FILTER_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_DEEMP_FILTER_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_DEEMP_FILTER, 0));
            }

            if (action.equals(FmRadioIntent.PS_CHANGED_ACTION)) {
                LogUtils.d(TAG, "enter onReceive PS_CHANGED_ACTION " + action);

                if (FM_SEND_RDS_IN_BYTEARRAY == true) {
                    Bundle extras = intent.getExtras();
                    byte[] psName = extras.getByteArray(FmRadioIntent.PS);
                    int status = extras.getInt(FmRadioIntent.STATUS, 0);

//                    mHandler.sendMessage(mHandler
//                            .obtainMessage(Constants.EVENT_PS_CHANGED, status, 0, psName));
                    LogUtils.d(TAG, "PS_CHANGED_ACTION psName = " + psName.toString());   
                    Intent sIntent = new Intent(Constants.PS_CHANGED);
                    sIntent.putExtra("ps", psName.toString());
                    sendBroadcast(sIntent);
                } else {

                    String name = intent.getStringExtra(FmRadioIntent.PS_CONVERTED);
                    LogUtils.d(TAG, "PS_CHANGED_ACTION psName = " + name.toString());   
                    Intent sIntent = new Intent(Constants.PS_CHANGED);
                    sIntent.putExtra("ps", name.toString());
                    sendBroadcast(sIntent);
//                    mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_PS_CHANGED, name));
                }
            }

            if (action.equals(FmRadioIntent.SET_RSSI_THRESHHOLD_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_RSSI_THRESHHOLD_ACTION " + action);

                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_RSSI_THRESHHOLD, 0));
            }

            if (action.equals(FmRadioIntent.SET_RF_DEPENDENT_MUTE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive SET_RF_DEPENDENT_MUTE_ACTION " + action);

//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_SET_RF_DEPENDENT_MUTE, 0));
            }

            if (action.equals(FmRadioIntent.COMPLETE_SCAN_DONE_ACTION)) {
                LogUtils.d(TAG, "enter onReceive COMPLETE_SCAN_DONE_ACTION " + action);

                Bundle extras = intent.getExtras();

                int[] channelList = extras.getIntArray(FmRadioIntent.SCAN_LIST);

                int noOfChannels = extras.getInt(FmRadioIntent.SCAN_LIST_COUNT, 0);

                int status = extras.getInt(FmRadioIntent.STATUS, 0);

                LogUtils.d(TAG, "noOfChannels" + noOfChannels);

                for (int i = 0; i < noOfChannels; i++){
                    LogUtils.d(TAG, "channelList" + channelList[i]);
                    mChannelHolder.add(new Station(String.valueOf(channelList[i])));
                   
                }
//                if (noOfChannels > 0) {
//	                int freq = channelList[noOfChannels-1];
//	                lastTunedFrequency = (float) freq / 1000;
//	                mChannelHolder.setWorkFreq(freq);
//                }
                setChannel(mChannelHolder.getWorkFreq());
                FMService.mScanState = scanState.SCAN_FINISHED;
                mSeekState = Constants.SEEK_REQ_STATE_IDLE;
//                FMService.this.sendBroadcast(new Intent(Constants.REFRESH_LISTVIEW));
                FMService.this.sendBroadcast(new Intent(Constants.SCAN_FINISH));
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_COMPLETE_SCAN_DONE, status,
//                        noOfChannels, channelList));
            }

            if (action.equals(FmRadioIntent.COMPLETE_SCAN_STOP_ACTION)) {
                LogUtils.d(TAG, "enter onReceive COMPLETE_SCAN_STOP_ACTION " + action);
                Bundle extras = intent.getExtras();
                int status = extras.getInt(FmRadioIntent.STATUS, 0);
                int channelValue = extras.getInt(FmRadioIntent.LAST_SCAN_CHANNEL, 0);
                Log.i(TAG, "Last Scanned Channel Frequency before calling Stop Scan"
                                + channelValue);
//                mChannelHolder.setWorkFreq(channelValue);
//                setChannel(channelValue);
                setChannel(mChannelHolder.getWorkFreq());
                sentScanStopIntent();
                LogUtils.d(TAG,"scan channel already stop");
//                mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_COMPLETE_SCAN_STOP, status,
//                        channelValue));
            }

            if (action.equals(FmRadioIntent.MASTER_VOLUME_CHANGED_ACTION)) {
                
                int mVolume = intent.getIntExtra(FmRadioIntent.MASTER_VOLUME, 0);
                LogUtils.d(TAG, "enter onReceive MASTER_VOLUME_CHANGED_ACTION " + action + " volumn " + mVolume);
                if (null != mHandler){
                	mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_MASTER_VOLUME_CHANGED, mVolume));
                }
            }

        }
        
    };

	private void exitFMonAirPlaneMode() {
		if (null != mHandler) {
			Toast.makeText(this, R.string.on_airplane_mode, Toast.LENGTH_SHORT)
					.show();
			LogUtils.d(TAG, "exitFMRadio in airplane mode");
			mHandler.sendMessage(Message.obtain(mHandler,
					Constants.MSG_CHANGE_POWER_BTN));
			if (sFmRadio.rxGetFMState() == FmRadio.STATE_ENABLED){
				disable();
			} else {
				mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DISABLE_SUCCESSFUL), 0);
			}
		}
	}
    private void exitFMRadio(){
    	Toast.makeText(this, R.string.bluetooth_disable, Toast.LENGTH_SHORT).show();
    	LogUtils.d(TAG,"exitFMRadio:" + status);
    	if (status){
    		disable();
    	}
      mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_FINISH_ACTIVITY));
    }
    private void addChannelFromCallback(Intent intent) {
        int freq = intent.getIntExtra("freq",0);
        if (freq == 0 || isStopScan) {
            return;
        }
        mChannelHolder.add(new Station(String.valueOf(freq)));
        sendBroadcast(new Intent(Constants.REFRESH_LISTVIEW));
    }
    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        LogUtils.d(TAG, "oncreate: start ti service.");
        this.startService(new Intent("com.ti.server.FmService"));
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        isHeadsetOn = am.isWiredHeadsetOn();
//        am.requestAudioFocus(mAudioFocusChangeListener, AudioManager.STREAM_MUSIC,
//        AudioManager.AUDIOFOCUS_GAIN);
        mChannelHolder = ChannelHolder.getInstance();
        LogUtils.d(TAG,"onCreate, mHandler is " + mHandler);
//        waitFor();
        HandlerThread fmThread = new HandlerThread("ServiceThread");
        fmThread.start();
//        mHeadsetObserver = new FMHeadsetObserver(this);
//        mHeadsetObserver.startObserving();
//        if (!isHeadsetOn) {
//            mHeadsetObserver.releaseWakeLock();
//        }
        //IntentFilter intentFilter = new IntentFilter();
        //intentFilter.addAction(Intent.ACTION_HEADSET_PLUG);
        //this.registerReceiver(mReceiver, intentFilter);
        mAlarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        Intent idleIntent = new Intent(Constants.FINISH_FM, null);
        mFinishIntent = PendingIntent.getBroadcast(this, 0, idleIntent, 0);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constants.ADD_CHANNEL_FROM_CALLBACK);
        intentFilter.addAction(Constants.FM_HEADSET_STATE_CHANGED);
        intentFilter.addAction(Constants.SET_TIME);
        intentFilter.addAction(Constants.FINISH_FM);
        intentFilter.addAction(Constants.PRESS_VOLUMEKEY_ENABLE_FM);
        intentFilter.addAction(FmRadioIntent.FM_ENABLED_ACTION);
		intentFilter.addAction(FmRadioIntent.FM_DISABLED_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_FREQUENCY_ACTION);
		intentFilter.addAction(FmRadioIntent.SEEK_ACTION);
		intentFilter.addAction(FmRadioIntent.BAND_CHANGE_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_CHANNEL_SPACE_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_MODE_MONO_STEREO_ACTION);
		intentFilter.addAction(FmRadioIntent.VOLUME_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.RDS_TEXT_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.PS_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.AUDIO_PATH_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.TUNE_COMPLETE_ACTION);
		intentFilter.addAction(FmRadioIntent.SEEK_STOP_ACTION);
		intentFilter.addAction(FmRadioIntent.MUTE_CHANGE_ACTION);
		intentFilter.addAction(FmRadioIntent.DISPLAY_MODE_MONO_STEREO_ACTION);
		intentFilter.addAction(FmRadioIntent.ENABLE_RDS_ACTION);
		intentFilter.addAction(FmRadioIntent.DISABLE_RDS_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RDS_AF_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RDS_SYSTEM_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_DEEMP_FILTER_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RSSI_THRESHHOLD_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RF_DEPENDENT_MUTE_ACTION);
		intentFilter.addAction(FmRadioIntent.PI_CODE_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.PTY_CODE_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.MASTER_VOLUME_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.CHANNEL_SPACING_CHANGED_ACTION);
		intentFilter.addAction(FmRadioIntent.COMPLETE_SCAN_DONE_ACTION);
		intentFilter.addAction(FmRadioIntent.COMPLETE_SCAN_STOP_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_BAND_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_MONO_STEREO_MODE_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_MUTE_MODE_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RF_MUTE_MODE_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RSSI_THRESHHOLD_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_DEEMPHASIS_FILTER_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_VOLUME_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RDS_SYSTEM_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RDS_GROUPMASK_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RDS_AF_SWITCH_MODE_ACTION);
		intentFilter.addAction(FmRadioIntent.GET_RSSI_ACTION);
		intentFilter.addAction(FmRadioIntent.COMPLETE_SCAN_PROGRESS_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RDS_AF_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_RF_DEPENDENT_MUTE_ACTION);
		intentFilter.addAction(FmRadioIntent.SET_CHANNEL_SPACE_ACTION);
//		intentFilter.addAction(Intent.ACTION_HEADSET_PLUG);
		intentFilter.addAction(Intent.ACTION_SHUTDOWN);
		intentFilter.addAction(Constants.HEADSET_PLUG_FAST);
        intentFilter.addAction(Constants.MUSIC_SERVICE_COMMAND);
        this.registerReceiver(mReceiver, intentFilter);
        this.getContentResolver().registerContentObserver(
                Settings.System.getUriFor(Settings.System.AIRPLANE_MODE_ON), true,
                mAirPlaneModeObserver);
        if (!isNotifyEnable) {
            showNotification();
            isNotifyEnable = true;
        }
		/*
		 * Need to enable the FM if it is not enabled earlier
		 */
		sFmRadio = new FmRadio(this.getApplicationContext(), this);
        
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtils.d(TAG,"onDestroy....");
        if (status == true){
        }
        if (null !=sFmRadio && sFmRadio.rxGetFMState() == FmRadio.STATE_ENABLED) {
        	 mStatus = sFmRadio.rxDisable();
     		if (mStatus) {	
     			mStatus = sFmRadio.rxDisableAudioRouting();
     		}
     		LogUtils.d(TAG, "onDestory,rxDisableAudioRouting mStatus is : " + mStatus );
        }
        LogUtils.d(TAG, "onDestroy..isNotifyEnable: " + isNotifyEnable + ",isDisableNotify: " + isDisableNotify);
        if (isNotifyEnable && isDisableNotify) {
            NotificationManager mNotificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.cancel(FM_NOTIFICATION_ID);
            LogUtils.d(TAG, "send cancel fmradio icon to notification manager...");
            isNotifyEnable = false;
            isDisableNotify = false;
        }
        this.unregisterReceiver(mReceiver);
        this.getContentResolver().unregisterContentObserver(mAirPlaneModeObserver);
        
//        mHeadsetObserver.freezeObserving();
        status = false;
        mChannelHolder.setRun(false);
//        am.abandonAudioFocus(mAudioFocusChangeListener);
        mHandler = null;
        if(sFmRadio!=null && mFmServiceConnected){
          sFmRadio.close();
          sFmRadio = null;
        }
        LogUtils.d(TAG, "on destory: stop ti service.");
        this.stopService(new Intent("com.ti.server.FmService"));
//        Process.killProcess(Process.myPid());
    }

	private void enableFMRadio() {
		LogUtils.d(TAG,"enableFMRadio.....isHeadsetOn: " + isHeadsetOn);
		if (!isHeadsetOn) {
			if (null != mHandler) {
				mHandler.sendMessage(Message.obtain(mHandler,
						Constants.MSG_ENABLE_SUCCESSFUL));	
			}		
			LogUtils.d(TAG,
					"status is true,enable return,enable() isHeadsetOn is "
							+ isHeadsetOn);
			mChannelHolder.setRun(true);
			return;
		} else {
			if (mFmServiceConnected)
				startup();
		}
	}
	
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        LogUtils.d(TAG,"action is " + action);
        if (Constants.GET_FM_STATUS.equals(action)) {
            LogUtils.d(TAG,"status is " + (status ? 1 : 0));
            if (mHandler == null) return START_NOT_STICKY;
//            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_FM_STATUS, status ? 1 : 0, 0));
        } else if (Constants.ENABLE_FM.equals(action)) {
        	LogUtils.d(TAG, "enableFMRadio");
//        	if(!status) {
        		enableFMRadio();
//        	}
        } else if (Constants.DISABLE_FM.equals(action)) {
            isDisableNotify = true;
            isDummy = false;
            disable();
        } else if (Constants.FM_FORWARD.equals(action)) {
            forward();
        } else if (Constants.FM_NEXT.equals(action)) {
            next();
        } else if (Constants.FM_PREV.equals(action)) {
            prev();
        } else if (Constants.FM_REW.equals(action)) {
            rew();
        } else if (Constants.START_SCAN_ALL.equals(action)) {
            scanAll();
        } else if (Constants.SET_CHANNEL.equals(action)) {
            double dc = intent.getDoubleExtra("channel", 87.6);
            LogUtils.d(TAG,"service get channel is " + dc);
            int channel = (int) (dc*1000);
            setChannel(channel);
        } else if (Constants.MUTE_PHONE.equals(action)) {
            mute(true);
        } else if (Constants.ALARM_PHONE.equals(action)) {
            mute(false);
        } else if (Constants.GET_CHANNEL.equals(action)) {
            getChannel();
        } else if (Constants.ADD_STATION.equals(action)) {
            addStation();
        } else if (Constants.STOP_SCAN.equals(action)) {
            stopScan();
        } else if (Constants.SET_SPEAKER.equals(action)) {
            setSpeaker();
        } else if (Constants.FM_AUDIOFOCUS.equals(action)) {
            requestEnableFM();
        } else if (Constants.STOP_SEEK.equals(action)){
        	stopSeek();
        } else if (Constants.SET_MUTE.equals(action)){
        	setMute(0);
        } else if (Constants.SET_UNMUTE.equals(action)){
        	setMute(1);
        } else if (Constants.SET_MONO.equals(action)){
        	setMonoStereo(1);
        } else if (Constants.SET_STEREO.equals(action)){
        	setMonoStereo(0);
        } else if (Constants.UPDATE_CONFIGURE.equals(action)){
        	setRdsConfig();
        }
        return START_NOT_STICKY;
    }

    private void handleHeadsetState(int headsetState) {
        isHeadsetOn = (headsetState == 0) ? false : true;
        LogUtils.d(TAG,"handleHeadsetState Headset is " + (isHeadsetOn ? "pluged in" : "pluged out"));
        if (mHandler != null) {
            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_HEADSET_STATE, headsetState, 0));
        }
        TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        int telState = tm.getCallState();
        if (telState != TelephonyManager.CALL_STATE_IDLE || mChannelHolder.getIsAudioFocus()) {
            return;
        }
        if (isDisableNotify){
        	LogUtils.d(TAG," FM is going to exit, do not handle headset event");
        	return;
        }
        LogUtils.d(TAG,"handleHeadsetState sdefaultSettingOn " + sdefaultSettingOn);
		if (isHeadsetOn) {
			if (!sdefaultSettingOn) {
				enableFMRadio();
			} else {
				enableAudio(true);
			}
		} else {
            isDummy = true;
        	Intent intent = new Intent(Constants.NO_HEADSET_PLUG);
			sendBroadcast(intent);
//			setFmSpeaker(false);
			enableAudio(false);
        }
    }
    private void setFmSpeaker(boolean status){
		try {
			LogUtils.d(TAG, "setFmSpeaker: " + status);
			Method setSpeakerfmOn = am.getClass().getMethod("setSpeakerfmOn",
					boolean.class);
			setSpeakerfmOn.invoke(am, status);
		} catch (Exception e) {
			LogUtils.d(TAG, "Exception e: " + e);
		}
    }
    private void requestEnableFM() {
//       int result =  am.requestAudioFocus(mAudioFocusChangeListener, AudioManager.STREAM_MUSIC,
//        AudioManager.AUDIOFOCUS_GAIN);
//       LogUtils.d(TAG,"AUDIOFOCUS_REQUEST_GRANTED result: " + result + ", state: " + status);
//       if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED && !status){  
//    	   mChannelHolder.setIsAudioFocus(false);
    	   enableFMRadio();
//       }
    }

    private void setSpeaker() {
//        boolean speakOn = mChannelHolder.getSpeakerOn();
//        FMNative.setSpeakerOn(!speakOn);
//        mChannelHolder.setSpeakerOn(!speakOn);
//        Intent intent = new Intent(Constants.SPEAKER_CHANGE_ACTION);
//        sendStickyBroadcast(intent);
    }

    private void setSpeaker(boolean isSpeakerOn){
//        FMNative.setSpeakerOn(isSpeakerOn);
//        Intent intent = new Intent(Constants.SPEAKER_CHANGE_ACTION);
//        sendStickyBroadcast(intent);
    }

    private void stopScan() {
    	LogUtils.d(TAG,"stopScan mSeekState = " + mSeekState);
    	if (mSeekState == Constants.SEEK_REQ_STATE_PENDING)
    		mStatus = sFmRadio.rxStopCompleteScan_nb();
    	else {
    		sentScanStopIntent();
    	}
    	
    }
	private void sentScanStopIntent() {
		Intent aIntent = new Intent();
		aIntent.setAction(Constants.SCAN_ALREADY_STOP);
		FMService.this.sendBroadcast(aIntent);
		isStopScan = true;
		mScanState = scanState.SCAN_FINISHED;
		mSeekState = Constants.SEEK_REQ_STATE_IDLE;
	}
    private void stopSeek() {
    	LogUtils.d(TAG,"stopScan mSeekState = " + mSeekState);

		if (mSeekState == Constants.SEEK_REQ_STATE_PENDING){
			mStatus = sFmRadio.rxStopSeek_nb();
		}else{
        	sentScanStopIntent();
		}
   
    }
    
    private void addStation() {
        int response = mChannelHolder.getWorkFreq();
        LogUtils.d(TAG,"add station " + response + "into favorite list");
        List<Station> list = mChannelHolder.getFavoriteStationList();
        int pos = mChannelHolder.binarySearch(list, String.valueOf(response));
        Station sta = new Station(String.valueOf(response));
        boolean flag = false;
        if (pos <= list.size() - 1 && list.get(pos).getFreq().equals(sta.getFreq())) {
            sta.setFavorStatus(String.valueOf(false));
            flag = false;
        } else {
            sta.setFavorStatus(String.valueOf(true));
            flag = true;
        }
        mChannelHolder.add(sta);
        sendBroadcast(new Intent(Constants.REFRESH_LISTVIEW));
        if (mChannelHolder.getWorkFreq() != response) {
            mChannelHolder.setWorkFreq(response);
        }
        if (mHandler == null) return;
        if (flag) {
            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_ADD_STATION, 1, 0));
        } else {
            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_ADD_STATION, 0, 0));
        }
    }
    
    private void getChannel() {
        int response = sFmRadio.rxGetBand();
        LogUtils.d(TAG,"getChannel # channel : " + response );
        if(mChannelHolder.getWorkFreq() != response) {
            mChannelHolder.setWorkFreq(response);
        } 
        if (mHandler != null) {
            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_CHANNEL));
        }
    }
    
    private boolean mute(boolean enable) {
        mStatus = sFmRadio.rxSetMuteMode_nb(enable?1:0);
        LogUtils.d(TAG,"mute # " + enable + " response : " + mStatus );
        return mStatus;
    }
    
    private void setChannel(final int channel) {
    	int tFreq;
    	lastTunedFrequency = (float) channel / 1000;
    	if (sBand == FM_BAND_EUROPE_US){
    		tFreq = parseEuropeFreq(channel);
        } else {
        	tFreq = parseJapanFreq(channel);
        }
    	mStatus = sFmRadio.rxTune_nb(tFreq);
    	 LogUtils.d(TAG,"set channel: " + tFreq + ", mSmStatus:" + mStatus);
//    	mChannelHolder.setWorkFreq(tFreq);
		if (mStatus == false) {
			showAlert(this, "FmRadio", "Not able to tune.", false);
		}
    }

    private void handleSetChannel(final int channel) {
//        if (status == false){
//            LogUtils.d(TAG,"fm is disable,can not set channel");
//            return;
//        }
//        if (mHandler == null) return;
//        final int response = FMNative.setChannel(channel);
//        if (response == 0) {
//            LogUtils.d(TAG,"set channel return: "+response+", set channel successful");
//            mChannelHolder.setWorkFreq(channel);
//            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_CHANNEL));
//        } else {
//            mChannelHolder.setWorkFreq(FMNative.getChannel());
//            LogUtils.d(TAG,"set channel failed");
//            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_CHANNEL));
//        }
    }
    
    private void scanAll() {
        if (isStopScan) isStopScan = false;
        mScanState = scanState.SCANNING;
        mChannelHolder.deleteAll();
        if (mSeekState == Constants.SEEK_REQ_STATE_IDLE) {
        	 mStatus = sFmRadio.rxCompleteScan_nb();
			if (mStatus == false) {
				showAlert(this, "FmRadio", "Not able to scan all.", false);
			} else {
				mSeekState = Constants.SEEK_REQ_STATE_PENDING;
			}
    		
    	}
       
    }
    
    private void forward() {
    	LogUtils.d(TAG,"forward : " );
        if (isStopScan) isStopScan = false;
        mScanState = scanState.SCANNING;
        if (mSeekState == Constants.SEEK_REQ_STATE_IDLE) {
    		mStatus = sFmRadio.rxSeek_nb(Constants.FM_SEEK_DOWN);
			if (mStatus == false) {
				showAlert(this, "FmRadio", "Not able to seek down.", false);
			} else {
				mSeekState = Constants.SEEK_REQ_STATE_PENDING;
			}
    		
    	}
    }
    
    private void next() {
    	int req ;
    	if (sBand == FM_BAND_EUROPE_US)
    		req = (mChannelHolder.getWorkFreq() + 100) > Constants.EUROPE_MAX_FREQ ? Constants.EUROPE_MIN_FREQ : (mChannelHolder.getWorkFreq() + 100);
    	else
    		req	= (mChannelHolder.getWorkFreq() + 100) > Constants.JAPAN_MAX_FREQ ? Constants.JAPAN_MIN_FREQ : (mChannelHolder.getWorkFreq() + 100);
        setChannel(req);
        LogUtils.d(TAG, "next req: " + req);
    	 if (mHandler != null) {
             mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_FAVORITE_BTN, req, 0));
         }
    }
    
    private void prev() {
    	int req ;
    	if (sBand == FM_BAND_EUROPE_US)
    		req = (mChannelHolder.getWorkFreq() - 100) < Constants.EUROPE_MIN_FREQ ? Constants.EUROPE_MAX_FREQ : (mChannelHolder.getWorkFreq() - 100);
    	else
    		req = (mChannelHolder.getWorkFreq() - 100) < Constants.JAPAN_MIN_FREQ ? Constants.JAPAN_MAX_FREQ : (mChannelHolder.getWorkFreq() - 100);
        setChannel(req);
        LogUtils.d(TAG, "prev req: " + req);
        if (mHandler != null) {
            mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_SET_FAVORITE_BTN, req, 0));
        }
    }
    
    private void rew() {
    	LogUtils.d(TAG,"rew : " );
        if (isStopScan) isStopScan = false;
        mScanState = scanState.SCANNING;
        if (mSeekState == Constants.SEEK_REQ_STATE_IDLE) {
    		mStatus = sFmRadio.rxSeek_nb(Constants.FM_SEEK_UP);
			if (mStatus == false) {
				showAlert(this, "FmRadio", "Not able to seek down.", false);
			} else {
				mSeekState = Constants.SEEK_REQ_STATE_PENDING;
			}
    		
    	}
    }
    
    private void enable(boolean isEnable) {

        LogUtils.d(TAG,"enable return : " + isEnable);
        if (isEnable) {
            status = true;
            mChannelHolder.setRun(true);
            long ident = Binder.clearCallingIdentity();
            Binder.restoreCallingIdentity(ident);
            if (mHandler != null ) {
                mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_ENABLE_SUCCESSFUL));
            }
//            sFmRadio.rxEnableAudioHAL(true);
//            sFmRadio.rxSetBand(mChannelHolder.getWorkFreq());
        } else {
            status = false;
            mChannelHolder.setRun(false);
            if (null != mHandler) {      	
            	mHandler.sendMessage(Message.obtain(mHandler, Constants.MSG_ENABLE_FAILED));
            }
            LogUtils.d(TAG,"enable failed, exit FMRadio  " );
            Toast.makeText(this, R.string.enable_fm_failed, Toast.LENGTH_SHORT)
    		.show();
        }
    }
    
    private void disable() {
        if (mHandler == null) return;
        LogUtils.d(TAG, "disable()");
        if (!sdefaultSettingOn){
        	showAlert(this, "FMRadio","FM turn on not yet completed. Please wait.", true);
        	return;
        }
        if (mScanState == scanState.SCANNING) {
        	mStatus = sFmRadio.rxStopCompleteScan_nb();
        	LogUtils.d(TAG,"stopScan return : " + mStatus);
		}
        
		//as BZ 54492 request, we need disable FM by following sequence:
		//1.Disable HAL
		//2.Disable audio routing
        mStatus = sFmRadio.rxDisable();
		if (mStatus)
			mStatus = sFmRadio.rxDisableAudioRouting();
		LogUtils.d(TAG, "rxDisableAudioRouting mStatus is : " + mStatus );
        if (!mStatus)
        	mHandler.sendMessageDelayed(Message.obtain(mHandler, Constants.MSG_DISABLE_SUCCESSFUL), 0);

        if (!isDummy) {
            mChannelHolder.setRun(false);
        }
        LogUtils.d(TAG,"disable return : " + mStatus);
    }
    
    public static void setHandler(Handler handler) {
        mHandler = handler;
    }

    public static Handler getHandler() {
        return mHandler;
    }
    
    private void showNotification() {
        Intent intent = new Intent(getApplicationContext(), FMRadioActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(),0,intent, 0); 
        Notification mNotification = new Notification( R.drawable.fm_app_icon,  getString(R.string.notification_on), 
        System.currentTimeMillis());
        mNotification.flags = Notification.FLAG_ONGOING_EVENT;
        mNotification.setLatestEventInfo(getApplicationContext(),getString(R.string.app_name),getString(R.string.notification_bar_text),contentIntent);
    //     mNotificationManager.notify(FM_NOTIFICATION_ID, mNotification);
        startForeground(FM_NOTIFICATION_ID, mNotification);
    }
    
    private void showFinishNotification() {
    	Toast.makeText(this, R.string.dialog_radio_close, Toast.LENGTH_SHORT)
		.show();
    	return;
    }
    
	public void onServiceConnected() {
		LogUtils.d(TAG, "onServiceConnected isHeadsetOn " + isHeadsetOn);
		mFmServiceConnected = true;
		if (isHeadsetOn)
			startup();
	}

	public void onServiceDisconnected() {
		LogUtils.d(TAG, "Lost connection to service");
		mFmServiceConnected = false ;
	}
	private void startup() {
		LogUtils.d(TAG, "startup");

        switch (sFmRadio.rxGetFMState()) {
            case FmRadio.STATE_ENABLED:
            	LogUtils.d(TAG, "FmRadio.STATE_ENABLED ");
                // Fm app is on and we are entering from the other screens

			if (sFmRadio.rxIsFMPaused()) {

				LogUtils.d(TAG, "FmRadio.STATE_PAUSE ");
				mStatus = sFmRadio.resumeFm();
				if (mStatus == false) {
					showAlert(this, "FmRadio", "Cannot resume Radio.", false);
				}

			}

			break;

		case FmRadio.STATE_DISABLED:
			LogUtils.d(TAG, "FmRadio.STATE_DISABLED ");
			sdefaultSettingOn = false;
			mStatus = sFmRadio.rxEnable();
			if (mStatus == false) {
				enable(false);
			}
			else { /* Display the dialog till FM is enabled */
//				pd = ProgressDialog.show(this, "Please wait..",
//						"Powering on Radio", true, false);
				if (null != mHandler) {
					mHandler.sendMessage(mHandler.obtainMessage(
							Constants.EVENT_RADIO_ENABLE_BEGIN, 0));
				}
			}

			break;
		/* FM has not been started. Start the FM */
		case FmRadio.STATE_DEFAULT:

			LogUtils.d(TAG, "FmRadio.STATE_DEFAULT ");
			sdefaultSettingOn = false;
			/*
			 * Make sure not to start the FM_Enable() again, if it has been
			 * already called before orientation change
			 */

			mStatus = sFmRadio.rxEnable();
			if (mStatus == false) {
				enable(false);
			} else { /* Display the dialog till FM is enabled */
				// pd = ProgressDialog.show(this, "Please wait..",
				// "Powering on Radio", true, false);
				if (null != mHandler) {
				    mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_RADIO_ENABLE_BEGIN, 0));
				}
			}
			break;
		}
	}
	/* Display alert dialog */
	public void showAlert(Context context, String title, String msg, boolean isShown) {

		LogUtils.d(TAG,"show alert: " + msg );
		if (isShown) {
			if (null != mHandler) {
				mHandler.sendMessage(mHandler.obtainMessage(Constants.FM_ERROR, msg));
			}
		}
//		AlertDialog ad = new AlertDialog.Builder(context).setTitle(title).setIcon(
//				android.R.drawable.ic_dialog_alert).setMessage(msg)
//				.setNegativeButton(android.R.string.cancel, null).show();
//		return ad;
	}
	
	/*
	 * 0 mute
	 * 1 unmute
	 * */
	private void setMute(int mute){
		LogUtils.d(TAG,"setMute  " + mute );
		mStatus = sFmRadio.rxSetMuteMode_nb(mute);
	}
	/*
	 * 0 stereo
	 * 1 mono
	 * */
	private void setMonoStereo(int mono){
		LogUtils.d(TAG,"setMonoStereo  " + mono );
		mStatus = sFmRadio.rxSetMonoStereoMode_nb(mono);
		if (mStatus){
            Intent sIntent = new Intent(Constants.STEREO_CHANGED);
            sIntent.putExtra("stereo", mono);
            sendBroadcast(sIntent);
		}
	}
	
	private void getMute(){
		mStatus = sFmRadio.rxGetMuteMode_nb();
		LogUtils.d(TAG,"getMute  " + mStatus );
	}
	
	/**
	 * This function enables/disables audio for FM application.
	 * Activation/deactivation depends on parameter's value
	 */
	private void enableAudio(boolean on){
		final boolean isEnabled = on;
		new Thread(new Runnable() {
            public void run() {
        		LogUtils.d(TAG, "Entering into enableAudio function");

        		if (sFmRadio == null)
        			return;
        		if(isEnabled == true){
        			mStatus = sFmRadio.resumeFm();
        			if(mStatus == true){
        				LogUtils.d(TAG, "resumeFm ok !!");
        			}
        		}else{
        			mStatus = sFmRadio.pauseFm();
        			if(mStatus == true){
        				LogUtils.d(TAG, "pauseFm ok !!");
        			}
        		}
            }
        }).start();

	}
	private ContentObserver mAirPlaneModeObserver = new ContentObserver(new Handler()) {
        @Override
        public void onChange(boolean selfChange) {
        	boolean apm = FMRadioActivity.isAirplaneMode(getApplicationContext());
        	LogUtils.d(TAG, "Air Plane Mode state changed apm = " + apm);
        	if (!apm){//off
        		enableAudio(true);
        	} else {//on
        		FMRadioActivity.isClickPowerBtn = true;
        		exitFMonAirPlaneMode();
        	}
        }
    };
private void setRdsConfig() {
		
		LogUtils.d(TAG, "setRdsConfig()-entered");
		FMRadioActivity.configurationState = FMRadioActivity.CONFIGURATION_STATE_PENDING;
		SharedPreferences fmConfigPreferences = getSharedPreferences(
				"fmConfigPreferences", MODE_PRIVATE);

			// Set Band
		int band = fmConfigPreferences.getInt(Constants.BAND,Constants.DEFAULT_BAND);
		LogUtils.d(TAG, "setRdsConfig()--- band= " + band);
		if (band != sBand) // If Band is same as the one set already donot set
		// it again
		{
			mStatus = sFmRadio.rxSetBand_nb(band);
			if (mStatus == false) {
				LogUtils.e(TAG, "setRdsConfig()-- setBand ->Erorr");
				showAlert(this, "FmRadio",
						"Cannot  setBand to selected Value.", false);
			} else {
				sBand = band;
				if (sdefaultSettingOn == true) {
					/* Set the default frequency */
					if (sBand == FM_BAND_EUROPE_US)
						lastTunedFrequency = (float) Constants.DEFAULT_FREQ_EUROPE;
					else
						lastTunedFrequency = (float) Constants.DEFAULT_FREQ_JAPAN;
				}

			}
			if (null != mHandler) {
				mHandler.sendMessage(mHandler.obtainMessage(Constants.EVENT_RADIO_CHANGE_FREQ, sBand));	
			}
		}

		/** Set channel spacing to the one selected by the user */
		int channelSpace = fmConfigPreferences.getInt(Constants.CHANNELSPACE,
				Constants.DEFAULT_CHANNELSPACE);
		LogUtils.d(TAG, "setChannelSpacing()--- channelSpace= " + channelSpace);
		if (channelSpace != sChannelSpace) // If channelSpace is same as the one
		// set already donot set
		// it again
		{
						mStatus = sFmRadio.rxSetChannelSpacing_nb(channelSpace);

			if (mStatus == false) {
				LogUtils.e(TAG, "setChannelSpacing()-- setChannelSpacing ->Erorr");
				showAlert(this, "FmRadio",
						"Cannot  setChannelSpacing to selected Value.", false);
			}
			sChannelSpace = channelSpace;
		}

		// set RDS related configuration
		boolean rdsEnable = fmConfigPreferences.getBoolean(Constants.RDS, Constants.DEFAULT_RDS);
		LogUtils.d(TAG, "setRDS()--- rdsEnable= " + rdsEnable);
		if (mRds != rdsEnable) {

			if (rdsEnable) {
						mStatus = sFmRadio.rxEnableRds_nb();
				if (mStatus == false) {
					LogUtils.e(TAG, "setRDS()-- enableRds() ->Erorr");
					showAlert(this, "FmRadio", "Cannot enable RDS.", false);
				}

			} else {
					mStatus = sFmRadio.rxDisableRds_nb();

				if (mStatus == false) {
					LogUtils.e(TAG, "setRDS()-- disableRds() ->Erorr");
					showAlert(this, "FmRadio", "Cannot disable RDS.", false);
				} else {
					LogUtils.e(TAG, "setRDS()-- disableRds() ->success");
				}
			}
			mRds = rdsEnable;
			mRdsState = rdsEnable;
		}

		// setRdssystem
		int rdsSystem = fmConfigPreferences.getInt(Constants.RDSSYSTEM,
				Constants.DEFAULT_RDS_SYSTEM);
		LogUtils.d(TAG, "setRdsSystem()--- rdsSystem= " + rdsSystem);
		if (mRdsSystem != rdsSystem) {
			// Set RDS-SYSTEM if a new choice is made by the user

			mStatus = sFmRadio.rxSetRdsSystem_nb(fmConfigPreferences.getInt(
					Constants.RDSSYSTEM, Constants.DEFAULT_RDS_SYSTEM));

			if (mStatus == false) {
				LogUtils.e(TAG, " setRdsSystem()-- setRdsSystem ->Erorr");
				showAlert(this, "FmRadio",
						"Cannot set Rds System to selected Value.", false);
			}
			mRdsSystem = rdsSystem;
		}

		boolean rdsAfSwitch = fmConfigPreferences.getBoolean(Constants.RDSAF,
				Constants.DEFAULT_RDS_AF);
			int rdsAf = 0;
			rdsAf = rdsAfSwitch ? 1 : 0;
			LogUtils.d(TAG, "setRdsAf()--- rdsAfSwitch= " + rdsAf);
			if (mRdsAf != rdsAfSwitch) {
				// Set RDS-AF if a new choice is made by the user

				mStatus = sFmRadio.rxSetRdsAfSwitchMode_nb(rdsAf);
				if (mStatus == false) {
					LogUtils.e(TAG, "setRdsAf()-- setRdsAfSwitchMode(1) ->Erorr");
					showAlert(this, "FmRadio", "Cannot set RDS AF Mode ON.", false);
				}
				mRdsAf = rdsAfSwitch;
			}
		// Set Rssi
		int rssiThreshHold = fmConfigPreferences.getInt(Constants.RSSI, Constants.DEFAULT_RSSI);
		LogUtils.d(TAG, "setRssi()-ENTER --- rssiThreshHold= " + rssiThreshHold);

			// Set RSSI if a new value is entered by the user

						mStatus = sFmRadio.rxSetRssiThreshold_nb(rssiThreshHold);

			if (mStatus == false) {
				showAlert(this, "FmRadio", "Not able to setRssiThreshold.", false);
			}

			mRssi = rssiThreshHold;


			LogUtils.d(TAG, "setRdsConfig()-exit");

	}

	/* Load the Default values from the preference when the application starts */
	private void loadDefaultConfiguration() {

		LogUtils.d(TAG, "loadDefaultConfiguration()-entered");
		SharedPreferences fmConfigPreferences = getSharedPreferences(
				"fmConfigPreferences", MODE_PRIVATE);
		sBand = fmConfigPreferences.getInt(Constants.BAND, Constants.DEFAULT_BAND);
		lastTunedFrequency = fmConfigPreferences.getFloat(Constants.FREQUENCY,
				(sBand == FM_BAND_EUROPE_US ? Constants.DEFAULT_FREQ_EUROPE
						: Constants.DEFAULT_FREQ_JAPAN));
		mMode = fmConfigPreferences.getInt(Constants.MODE, Constants.DEFAULT_MODE);
		mRdsState = fmConfigPreferences.getBoolean(Constants.RDS, true);
		mRdsSystem = fmConfigPreferences.getInt(Constants.RDSSYSTEM, Constants.DEFAULT_RDS_SYSTEM);
		mRdsAf = fmConfigPreferences.getBoolean(Constants.RDSAF, Constants.DEFAULT_RDS_AF);
		mRssi = fmConfigPreferences.getInt(Constants.RSSI, Constants.DEFAULT_RSSI);

		LogUtils.d(TAG, " Load default band " + sBand + " last fre " + lastTunedFrequency + " mode "
					+ mMode + " mRdsState "
					+ mRdsState + " mRdsAf " + mRdsAf + " mRssi " + mRssi);

	}
	private int parseJapanFreq(int jFreq){
		if (jFreq < Constants.JAPAN_MIN_FREQ)
			jFreq = Constants.JAPAN_MIN_FREQ;
		else if (jFreq > Constants.JAPAN_MAX_FREQ)
			jFreq = Constants.JAPAN_MAX_FREQ;
		return jFreq;
	}
	private int parseEuropeFreq(int eFreq){
		if (eFreq < Constants.EUROPE_MIN_FREQ)
			eFreq = Constants.EUROPE_MIN_FREQ;
		else if (eFreq > Constants.EUROPE_MAX_FREQ)
			eFreq = Constants.EUROPE_MAX_FREQ;
		return eFreq;
	}
}
