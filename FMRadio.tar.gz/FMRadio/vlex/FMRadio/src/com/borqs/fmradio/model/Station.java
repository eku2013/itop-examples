/*
 * Copyright © 2012 Borqs Ltd.  All rights reserved.

 * This document is Borqs Confidential Proprietary and shall not be used, 
 * of published, or disclosed, or disseminated outside of Borqs in whole 
 * or in part without Borqs 's permission. 
 */
package com.borqs.fmradio.model;

public class Station {
    private String mFreq;
    private String isFavor;
    private String mName;
    private int mPosition = 0;

    public Station() {
        mFreq = null;
        mName = null;
        isFavor = String.valueOf(false);
        mPosition = 0;
    }
    
    public Station(Station sta) {
        mFreq = sta.mFreq;
        mName = sta.mName;
        isFavor = String.valueOf(false);
        mPosition = sta.mPosition;
    }
    
    public Station(String freq) {
        mFreq = freq;
        isFavor = String.valueOf(false);
    }
    
    public Station(String freq, String favor) {
        this.mFreq = freq;
        this.isFavor = favor;
    }
    
    public Station(String freq, String name, String favor) {
        this.mFreq = freq;
        this.mName = name;
        this.isFavor = favor;
    }
    
    public Station(String freq, String name, String favor, int position) {
    	this.mFreq = freq;
        this.mName = name;
        this.isFavor = favor;
        this.mPosition = position;
    	
    }
    
    public int getPosition () {
    	
    	return mPosition;
    }
    
    public void setPosition (int position) {
    	this.mPosition = position;
    }
    
    public String getFreq() {
        return mFreq;
    }

    public void setFreq(String freq) {
        this.mFreq = freq;
    }
    
    
    public String getName(){
    	return mName;
    }
    
    public void setName(String name){
    	this.mName = name;
    }
    public String getFavorStatus() {
        return isFavor;
    }
    
    public void setFavorStatus(String favor) {
        this.isFavor = favor;
    }

}
